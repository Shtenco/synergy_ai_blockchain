from __future__ import annotations

import argparse
import json
from pathlib import Path

from macro_economy.dual_contour_engine import DualContourConfig, DualContourEconomy


def main() -> int:
    p = argparse.ArgumentParser(description="Run SYNERGY dual-contour v5 simulation")
    p.add_argument("--blocks", type=int, default=500)
    p.add_argument("--seed", type=int, default=77)
    p.add_argument("--output", type=Path, default=Path("reports/v5_dual_contour_seed77.json"))
    p.add_argument("--no-delta", action="store_true", help="disable external AI delta control")
    p.add_argument("--no-shadow-mm", action="store_true", help="disable internal exact-target AI MM")
    args = p.parse_args()

    cfg = DualContourConfig(
        blocks=args.blocks,
        seed=args.seed,
        enable_external_delta_control=not args.no_delta,
        enable_shadow_mm=not args.no_shadow_mm,
    )
    report = DualContourEconomy(cfg).run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    print(
        f"blocks={report.blocks} alpha={report.system_alpha_vs_hodl} "
        f"drawdown={report.max_adjusted_drawdown_pct}% "
        f"bridge_pnl={report.external_realized_inventory_pnl_usdc}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
