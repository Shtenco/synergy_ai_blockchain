from __future__ import annotations

import argparse
import base64
import csv
import io
import json
from pathlib import Path
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import matplotlib.pyplot as plt

from macro_economy.assets import default_base_assets


def _save_line(out: Path, x, series, title: str, xlabel: str, ylabel: str) -> None:
    fig = plt.figure(figsize=(10, 5.5))
    ax = fig.add_subplot(111)
    for label, values in series:
        ax.plot(x, values, label=label)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.25)
    if len(series) > 1:
        ax.legend()
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)


def _save_bar(out: Path, labels, values, title: str, ylabel: str) -> None:
    fig = plt.figure(figsize=(10, 5.5))
    ax = fig.add_subplot(111)
    ax.bar(labels, values)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=45)
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out, dpi=160)
    plt.close(fig)


def _embed_png(path: Path) -> str:
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{data}"


def _pct_change(a: float, b: float) -> float:
    return (b / a - 1.0) * 100.0 if a else 0.0


def render_report(report_json: Path, output_dir: Path, robustness_csv: Path | None = None) -> Path:
    payload = json.loads(Path(report_json).read_text(encoding="utf-8"))
    snaps = payload["snapshots"]
    out = Path(output_dir)
    charts = out / "charts"
    charts.mkdir(parents=True, exist_ok=True)

    blocks = [r["block"] for r in snaps]
    seconds = [r["time_seconds"] for r in snaps]

    chart_paths: list[Path] = []

    p = charts / "01_system_wealth.png"
    _save_line(
        p,
        blocks,
        [
            ("Raw real wealth", [r["system_real_wealth"] for r in snaps]),
            ("Capital-adjusted wealth", [r["capital_adjusted_wealth"] for r in snaps]),
            ("HODL benchmark", [r["hodl_benchmark"] for r in snaps]),
        ],
        "SYNERGY real wealth vs capital-adjusted wealth vs HODL",
        "Block",
        "USDC-equivalent",
    )
    chart_paths.append(p)

    p = charts / "02_protocol_hard_nav.png"
    _save_line(
        p, blocks,
        [("Protocol HardNAV", [r["protocol_hard_nav"] for r in snaps])],
        "Protocol HardNAV", "Block", "USDC-equivalent",
    )
    chart_paths.append(p)

    p = charts / "03_founder_treasury.png"
    _save_line(
        p, blocks,
        [("Founder Treasury", [r["founder_usdc"] for r in snaps])],
        "Founder Treasury from externally attributable fees", "Block", "USDC",
    )
    chart_paths.append(p)

    p = charts / "04_triangle_prices.png"
    _save_line(
        p, blocks,
        [
            ("RUBX market", [r["rubx_price"] for r in snaps]),
            ("RUBZ market", [r["rubz_price"] for r in snaps]),
            ("RUBZ fair equity value", [r["rubz_fair_value"] for r in snaps]),
        ],
        "RUBX–RUBZ–USDC triangle pricing", "Block", "USDC per token",
    )
    chart_paths.append(p)

    p = charts / "05_rubx_coverage.png"
    _save_line(
        p, blocks,
        [("RUBX coverage", [r["rubx_coverage"] for r in snaps])],
        "RUBX senior-liability coverage ratio", "Block", "Coverage ×",
    )
    chart_paths.append(p)

    p = charts / "06_gross_tvl.png"
    _save_line(
        p, blocks,
        [("Gross TVL", [r["gross_tvl"] for r in snaps])],
        "Gross TVL (not a profit metric)", "Block", "USDC-equivalent",
    )
    chart_paths.append(p)

    first_prices = snaps[0]["prices"]
    price_series = []
    for symbol in first_prices:
        p0 = first_prices[symbol]
        price_series.append((symbol, [100.0 * r["prices"][symbol] / p0 for r in snaps]))
    p = charts / "07_base_prices_normalized.png"
    _save_line(
        p, blocks, price_series,
        "Ten Base assets — normalized external prices", "Block", "Index (first block = 100)",
    )
    chart_paths.append(p)

    p = charts / "08_market_deviation_bps.png"
    _save_line(
        p, blocks,
        [
            ("Mean absolute deviation", [r["mean_abs_deviation_bps"] for r in snaps]),
            ("Max absolute deviation", [r["max_abs_deviation_bps"] for r in snaps]),
        ],
        "Internal Base AMMs vs external reference markets", "Block", "Deviation (bps)",
    )
    chart_paths.append(p)

    p = charts / "09_fee_capture.png"
    _save_line(
        p, blocks,
        [
            ("External fee value captured by protocol", [r["external_fee_value"] for r in snaps]),
            ("Founder externally attributed revenue", [r["founder_external_revenue"] for r in snaps]),
            ("Agent fees paid to external venues", [r["agent_external_fees"] for r in snaps]),
        ],
        "Fee flows", "Block", "USDC-equivalent",
    )
    chart_paths.append(p)

    p = charts / "10_alpha_vs_hodl.png"
    _save_line(
        p, blocks,
        [("Alpha vs HODL", [r["alpha_vs_hodl"] for r in snaps])],
        "Capital-adjusted alpha vs passive initial portfolio", "Block", "USDC",
    )
    chart_paths.append(p)

    peak = None
    drawdowns = []
    for r in snaps:
        w = r["capital_adjusted_wealth"]
        peak = w if peak is None else max(peak, w)
        drawdowns.append((peak - w) / peak * 100.0 if peak else 0.0)
    p = charts / "11_adjusted_drawdown.png"
    _save_line(
        p, blocks,
        [("Drawdown", drawdowns)],
        "Capital-adjusted wealth drawdown", "Block", "Drawdown (%)",
    )
    chart_paths.append(p)

    volumes = {k: float(v) for k, v in payload["volume_by_symbol"].items()}
    p = charts / "12_volume_by_asset.png"
    _save_bar(p, list(volumes), list(volumes.values()), "External Base market volume by asset", "USDC-equivalent")
    chart_paths.append(p)

    initial = {a.symbol: a.initial_price for a in default_base_assets()}
    final = {k: float(v) for k, v in payload["final_prices"].items()}
    returns = {s: _pct_change(initial[s], final[s]) for s in initial}
    p = charts / "13_final_asset_returns.png"
    _save_bar(p, list(returns), list(returns.values()), "Base asset price change during 100-minute scenario", "Return (%)")
    chart_paths.append(p)

    p = charts / "14_yield_curve_evolution.png"
    _save_line(
        p, blocks,
        [
            ("1D", [r["yield_1d"] * 100.0 for r in snaps]),
            ("7D", [r["yield_7d"] * 100.0 for r in snaps]),
            ("30D", [r["yield_30d"] * 100.0 for r in snaps]),
            ("90D", [r["yield_90d"] * 100.0 for r in snaps]),
            ("365D", [r["yield_365d"] * 100.0 for r in snaps]),
        ],
        "SYNERGY yield curve evolution", "Block", "Annualized yield (%)",
    )
    chart_paths.append(p)

    p = charts / "15_agent_allocation_core.png"
    base_assets = list(first_prices)
    _save_line(
        p, blocks,
        [
            ("USDC", [r["allocation"].get("USDC", 0.0) * 100.0 for r in snaps]),
            ("RUBX", [r["allocation"].get("RUBX", 0.0) * 100.0 for r in snaps]),
            ("RUBZ", [r["allocation"].get("RUBZ", 0.0) * 100.0 for r in snaps]),
            ("Base basket", [sum(r["allocation"].get(sym, 0.0) for sym in base_assets) * 100.0 for r in snaps]),
        ],
        "Autonomous agent liquid allocation", "Block", "Portfolio weight (%)",
    )
    chart_paths.append(p)

    final_alloc = payload.get("allocation_by_asset_end", {})
    p = charts / "16_final_agent_allocation.png"
    _save_bar(
        p, list(final_alloc), [float(v) * 100.0 for v in final_alloc.values()],
        "Final autonomous agent allocation", "Portfolio weight (%)",
    )
    chart_paths.append(p)

    p = charts / "17_company_nav_and_agent_claims.png"
    _save_line(
        p, blocks,
        [
            ("Company real NAV", [r["company_real_wealth"] for r in snaps]),
            ("Agent financial claims", [r["agent_financial_claims_value"] for r in snaps]),
        ],
        "Agent-company capital formation", "Block", "USDC-equivalent",
    )
    chart_paths.append(p)

    p = charts / "18_credit_utilization.png"
    _save_line(
        p, blocks,
        [("Credit utilization", [r["credit_utilization"] * 100.0 for r in snaps])],
        "Portfolio-backed credit utilization", "Block", "Utilization (%)",
    )
    chart_paths.append(p)

    p = charts / "19_credit_balance_sheet.png"
    _save_line(
        p, blocks,
        [
            ("Credit reserve", [r["credit_reserve_usdc"] for r in snaps]),
            ("Portfolio debt", [r["portfolio_debt"] for r in snaps]),
        ],
        "SYNERGY credit reserve and outstanding debt", "Block", "USDC",
    )
    chart_paths.append(p)

    p = charts / "20_margin_and_liquidations.png"
    _save_line(
        p, blocks,
        [
            ("Margin calls", [r["portfolio_margin_calls"] for r in snaps]),
            ("Liquidations", [r["portfolio_liquidations"] for r in snaps]),
        ],
        "Portfolio credit risk events", "Block", "Cumulative count",
    )
    chart_paths.append(p)

    p = charts / "21_capital_issuance.png"
    _save_line(
        p, blocks,
        [
            ("Equity issuance", [r["equity_issuance_usdc"] for r in snaps]),
            ("Bond issuance", [r["bond_issuance_usdc"] for r in snaps]),
        ],
        "Primary capital issuance", "Block", "USDC",
    )
    chart_paths.append(p)

    p = charts / "22_company_deployment_volume.png"
    _save_line(
        p, blocks,
        [("Company internal market volume", [r["company_trade_volume_usdc"] for r in snaps])],
        "Company deployment into Base markets", "Block", "USDC",
    )
    chart_paths.append(p)

    tenors = [1, 7, 30, 90, 365]
    start_curve = payload.get("yield_curve_start", {})
    end_curve = payload.get("yield_curve_end", {})
    def _curve_val(obj, tenor):
        return float(obj.get(str(tenor), obj.get(tenor, 0.0))) * 100.0
    p = charts / "23_yield_curve_start_end.png"
    _save_line(
        p, tenors,
        [
            ("Opening", [_curve_val(start_curve, t) for t in tenors]),
            ("Closing", [_curve_val(end_curve, t) for t in tenors]),
        ],
        "Yield curve: opening vs closing", "Tenor (days)", "Annualized yield (%)",
    )
    chart_paths.append(p)

    if robustness_csv is not None and Path(robustness_csv).exists():
        rows = list(csv.DictReader(Path(robustness_csv).open(encoding="utf-8")))
        seeds = [r["seed"] for r in rows]
        alphas = [float(r["alpha_vs_hodl"]) for r in rows]
        p = charts / "24_robustness_alpha_20_seeds.png"
        _save_bar(p, seeds, alphas, "Alpha vs HODL across 20 deterministic seeds", "USDC")
        chart_paths.append(p)

        changes = [float(r["capital_adjusted_wealth_change"]) for r in rows]
        p = charts / "25_robustness_adjusted_change_20_seeds.png"
        _save_bar(p, seeds, changes, "Capital-adjusted wealth change across 20 seeds", "USDC")
        chart_paths.append(p)

    metrics = [
        ("Opening real wealth", payload["opening_system_real_wealth"]),
        ("Closing real wealth", payload["closing_system_real_wealth"]),
        ("Net external capital flow", payload["net_external_capital_flow"]),
        ("Capital-adjusted closing wealth", payload["capital_adjusted_closing_wealth"]),
        ("HODL benchmark", payload["closing_hodl_benchmark"]),
        ("Alpha vs HODL", payload["system_alpha_vs_hodl"]),
        ("Founder external revenue", payload["founder_external_revenue"]),
        ("Max adjusted drawdown %", payload["max_adjusted_drawdown_pct"]),
        ("RUBX end coverage", payload["rubx_end_coverage"]),
        ("Companies", payload.get("company_count", 0)),
        ("Equity issuance", payload.get("equity_issuance_usdc", "0")),
        ("Bond issuance", payload.get("bond_issuance_usdc", "0")),
        ("Portfolio loans", payload.get("portfolio_loans_originated", 0)),
        ("Credit utilization", payload.get("credit_utilization_end", "0")),
        ("Credit bad debt", payload.get("credit_bad_debt_usdc", "0")),
        ("Agent financial claims", payload.get("agent_financial_claims_value_end", "0")),
    ]
    rows_html = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in metrics)
    imgs = "\n".join(
        f'<section><h2>{path.stem.replace("_", " ").title()}</h2><img src="{_embed_png(path)}" alt="{path.stem}"></section>'
        for path in chart_paths
    )
    html = f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SYNERGY Agent Capital Markets v4 — 500 blocks</title>
<style>
body{{font-family:Arial,sans-serif;margin:0;background:#111;color:#eee}}main{{max-width:1200px;margin:auto;padding:28px}}
h1{{font-size:34px}}p{{line-height:1.55;color:#ccc}}table{{border-collapse:collapse;width:100%;margin:20px 0 36px}}
td{{border-bottom:1px solid #333;padding:10px}}td:last-child{{text-align:right;font-family:monospace}}
section{{margin:38px 0;padding:18px;background:#181818;border:1px solid #2b2b2b;border-radius:12px}}img{{width:100%;height:auto;background:white;border-radius:8px}}
.note{{padding:14px;border-left:4px solid #777;background:#171717}}
</style></head><body><main>
<h1>SYNERGY Agent Capital Markets v4</h1>
<p>RUBX–RUBZ–USDC monetary triangle + 10 Base internal/external markets + autonomous allocation, equities, bonds, portfolio credit and a SYNERGY Yield curve. Reference scenario: {payload['blocks']} blocks × {payload['block_seconds']} seconds = {payload['elapsed_seconds']} seconds.</p>
<div class="note">HardNAV excludes RUBX/RUBZ and all internal securities. Equity, bonds and loans are claims, not extra wealth. Capital-adjusted wealth subtracts net outside capital subscriptions/redemptions; alpha compares that result with passive HODL of the opening real-asset inventory.</div>
<table>{rows_html}</table>
{imgs}
</main></body></html>"""
    html_path = out / "macro_500_blocks_report.html"
    html_path.write_text(html, encoding="utf-8")
    return html_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("report_json", type=Path)
    ap.add_argument("output_dir", type=Path)
    ap.add_argument("--robustness-csv", type=Path)
    args = ap.parse_args()
    html = render_report(args.report_json, args.output_dir, args.robustness_csv)
    print(html)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
