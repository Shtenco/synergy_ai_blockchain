from __future__ import annotations

import argparse
import json
import statistics
from decimal import Decimal as D
from pathlib import Path

from macro_economy.stability_engine import StabilityConfig, StabilityEconomyV8

CANDIDATES = [
    {'name': 'fast', 'interval': 4, 'safety': '1.25', 'benefit': '3.0'},
    {'name': 'balanced', 'interval': 8, 'safety': '1.50', 'benefit': '3.0'},
    {'name': 'patient', 'interval': 14, 'safety': '1.75', 'benefit': '3.5'},
]


def evaluate(seed: int, candidate: dict, capital: D, blocks: int) -> dict:
    cfg = StabilityConfig(
        blocks=blocks,
        seed=seed,
        capital_scale=capital / D('8700'),
        enable_gas_aware_execution=True,
        gas_min_interval_blocks=candidate['interval'],
        gas_safety_multiple=D(candidate['safety']),
        gas_risk_benefit_multiplier=D(candidate['benefit']),
    )
    r = StabilityEconomyV8(cfg).run()
    return {
        'seed': seed,
        'net_after_gas': float(r.capital_adjusted_closing_wealth - capital),
        'alpha_vs_hodl': float(r.system_alpha_vs_hodl),
        'max_drawdown_pct': float(r.max_adjusted_drawdown_pct),
        'gas_usdc': float(r.hedge_gas_cost_usdc),
        'batch_executions': r.hedge_batch_executions,
        'execution_skips': r.hedge_execution_skips,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--capital', default='1000')
    ap.add_argument('--blocks', type=int, default=1000)
    ap.add_argument('--train-seeds', default='1,2,3')
    ap.add_argument('--holdout-seeds', default='4,5,6,7,8')
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    capital = D(args.capital)
    train = [int(x) for x in args.train_seeds.split(',') if x]
    holdout = [int(x) for x in args.holdout_seeds.split(',') if x]
    candidates = []
    for c in CANDIDATES:
        rows = [evaluate(seed, c, capital, args.blocks) for seed in train]
        mean_net = statistics.mean(r['net_after_gas'] for r in rows)
        worst_net = min(r['net_after_gas'] for r in rows)
        mean_dd = statistics.mean(r['max_drawdown_pct'] for r in rows)
        score = mean_net + 0.35 * worst_net - 15 * mean_dd
        candidates.append({**c, 'score': score, 'train': rows})
    best = max(candidates, key=lambda x: x['score'])
    holdout_rows = [evaluate(seed, best, capital, args.blocks) for seed in holdout]
    result = {
        'capital': str(capital),
        'blocks': args.blocks,
        'objective': 'mean_net + 0.35*worst_net - 15*mean_drawdown_pct',
        'candidates': candidates,
        'best_policy': {k: best[k] for k in ('name','interval','safety','benefit','score')},
        'holdout': holdout_rows,
        'holdout_positive_net_count': sum(r['net_after_gas'] > 0 for r in holdout_rows),
        'holdout_count': len(holdout_rows),
        'holdout_mean_net_after_gas': statistics.mean(r['net_after_gas'] for r in holdout_rows),
        'holdout_worst_net_after_gas': min(r['net_after_gas'] for r in holdout_rows),
        'holdout_mean_gas_usdc': statistics.mean(r['gas_usdc'] for r in holdout_rows),
    }
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
