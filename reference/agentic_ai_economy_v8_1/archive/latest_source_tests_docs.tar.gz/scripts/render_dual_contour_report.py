from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.render_macro_report import _save_line, _save_bar, _embed_png


def _drawdown(values: list[float]) -> list[float]:
    peak = None
    out = []
    for v in values:
        peak = v if peak is None else max(peak, v)
        out.append((peak - v) / peak * 100 if peak else 0.0)
    return out


def render_dual_contour_report(report_json: Path, output_dir: Path) -> Path:
    payload = json.loads(Path(report_json).read_text(encoding="utf-8"))
    snaps = payload["snapshots"]
    out = Path(output_dir)
    charts = out / "charts"
    charts.mkdir(parents=True, exist_ok=True)
    blocks = [r["block"] for r in snaps]
    paths: list[Path] = []

    def line(name, series, title, ylabel):
        p = charts / name
        _save_line(p, blocks, series, title, "Block", ylabel)
        paths.append(p)

    line("01_system_wealth.png", [
        ("Raw real wealth", [r["system_real_wealth"] for r in snaps]),
        ("Capital-adjusted", [r["capital_adjusted_wealth"] for r in snaps]),
        ("HODL", [r["hodl_benchmark"] for r in snaps]),
    ], "SYNERGY v5 real wealth", "USDC-equivalent")

    line("02_protocol_hard_nav.png", [("HardNAV", [r["protocol_hard_nav"] for r in snaps])],
         "Protocol HardNAV including real bridge inventory", "USDC-equivalent")
    line("03_alpha_vs_hodl.png", [("Alpha", [r["alpha_vs_hodl"] for r in snaps])],
         "Capital-adjusted alpha vs HODL", "USDC")
    adjusted = [r["capital_adjusted_wealth"] for r in snaps]
    line("04_adjusted_drawdown.png", [("Drawdown", _drawdown(adjusted))],
         "Capital-adjusted drawdown", "Percent")
    line("05_bridge_balance_sheet.png", [
        ("Bridge real NAV", [r["bridge_real_nav"] for r in snaps]),
        ("Bridge USDC", [r["bridge_usdc"] for r in snaps]),
    ], "Inventory bridge real balance sheet", "USDC-equivalent")
    line("06_bridge_real_asset_share.png", [("Real asset share", [r["bridge_real_asset_share"] * 100 for r in snaps])],
         "AI-controlled external delta", "Percent of bridge NAV")
    line("07_bridge_realized_pnl_and_fees.png", [
        ("Realized inventory PnL", [r["bridge_realized_pnl"] for r in snaps]),
        ("External execution fees", [r["bridge_external_fees"] for r in snaps]),
    ], "External inventory execution", "USDC")
    line("08_shadow_supply_value.png", [("Synthetic supply value", [r["shadow_supply_value"] for r in snaps])],
         "SYNERGY CHAIN synthetic supply (not HardNAV)", "Synthetic USDC-equivalent")
    line("09_shadow_mint_burn.png", [
        ("Policy minted", [r["shadow_minted_value"] for r in snaps]),
        ("Policy burned", [r["shadow_burned_value"] for r in snaps]),
    ], "AI market-maker mint / buyback-burn", "Synthetic USDC-equivalent")
    line("10_shadow_spread_error.png", [
        ("Mean abs error", [r["shadow_mean_spread_error_bps"] for r in snaps]),
        ("Max abs error", [r["shadow_max_spread_error_bps"] for r in snaps]),
    ], "Controlled internal-vs-external spread error", "Basis points")
    line("11_shadow_target_spread.png", [("Target spread", [r["shadow_target_spread_bps"] for r in snaps])],
         "Adaptive target spread", "Basis points")
    line("12_ai_actions.png", [
        ("Mint/sell", [r["shadow_mint_sell_actions"] for r in snaps]),
        ("Buy/burn", [r["shadow_buy_burn_actions"] for r in snaps]),
    ], "Cumulative AI market-maker actions", "Count")
    line("13_shadow_fee_value.png", [("Synthetic fees", [r["shadow_fee_value"] for r in snaps])],
         "Internal synthetic fee capture (not HardNAV)", "sUSDC-equivalent")
    line("14_founder_treasury.png", [("Founder treasury", [r["founder_usdc"] for r in snaps])],
         "Founder treasury from real external activity", "USDC")
    line("15_yield_curve_short_long.png", [
        ("1D", [r["yield_1d"] * 100 for r in snaps]),
        ("30D", [r["yield_30d"] * 100 for r in snaps]),
        ("365D", [r["yield_365d"] * 100 for r in snaps]),
    ], "SYNERGY capital-market yield curve", "Annualized percent")
    line("16_credit_utilization.png", [("Credit utilization", [r["credit_utilization"] * 100 for r in snaps])],
         "Portfolio-backed credit utilization", "Percent")
    line("17_rubx_rubz_prices.png", [
        ("RUBX", [r["rubx_price"] for r in snaps]),
        ("RUBZ", [r["rubz_price"] for r in snaps]),
        ("RUBZ fair", [r["rubz_fair_value"] for r in snaps]),
    ], "Canonical RUBX–RUBZ–USDC triangle", "USDC per token")

    bridge_values = {k: float(v) for k, v in payload["bridge_asset_values_end"].items()}
    p = charts / "18_bridge_asset_values_end.png"
    _save_bar(p, list(bridge_values), list(bridge_values.values()), "Closing real inventory by Base asset", "USDC-equivalent")
    paths.append(p)

    last = snaps[-1]
    marks = {"RUBX": last["rubx_price"], "RUBZ": last["rubz_price"], **last["prices"]}
    supply_values = {}
    for synth, qty in payload["shadow_supply_end"].items():
        if synth == "sUSDC":
            supply_values[synth] = float(qty)
        else:
            sym = synth[1:]
            supply_values[synth] = float(qty) * marks[sym]
    p = charts / "19_shadow_supply_by_asset_end.png"
    _save_bar(p, list(supply_values), list(supply_values.values()), "Closing shadow supply by asset", "Synthetic USDC-equivalent")
    paths.append(p)

    selected = [s for s in ("RUBX", "RUBZ", "WETH", "cbBTC", "AERO", "VIRTUAL") if s in last["shadow_prices"]]
    premium_series = []
    for sym in selected:
        vals = []
        for r in snaps:
            ext = r["rubx_price"] if sym == "RUBX" else r["rubz_price"] if sym == "RUBZ" else r["prices"][sym]
            vals.append((r["shadow_prices"][sym] / ext - 1.0) * 10000.0)
        premium_series.append((sym, vals))
    line("20_internal_premiums_selected.png", premium_series,
         "Selected SYNERGY CHAIN premiums vs external marks", "Basis points")

    cards = "\n".join(
        f'<section class="chart"><h3>{p.stem.replace("_", " ").title()}</h3><img src="{_embed_png(p)}"></section>'
        for p in paths
    )
    summary = [
        ("Closing real wealth", payload["closing_system_real_wealth"]),
        ("Capital-adjusted wealth", payload["capital_adjusted_closing_wealth"]),
        ("Alpha vs HODL", payload["system_alpha_vs_hodl"]),
        ("Max drawdown %", payload["max_adjusted_drawdown_pct"]),
        ("Realized inventory PnL", payload["external_realized_inventory_pnl_usdc"]),
        ("Mean spread error bps", payload["internal_mean_abs_spread_error_bps"]),
        ("AI actions", payload["ai_actions"]),
    ]
    summary_html = "".join(f'<div class="metric"><b>{k}</b><span>{v}</span></div>' for k, v in summary)
    html = f'''<!doctype html><html><head><meta charset="utf-8"><title>SYNERGY Dual Contour v5</title>
<style>body{{font-family:Arial,sans-serif;margin:0;background:#0e1116;color:#edf2f7}}main{{max-width:1200px;margin:auto;padding:32px}}h1{{font-size:38px}}.lead{{color:#b8c2cf;max-width:900px;line-height:1.5}}.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:24px 0}}.metric,.chart{{background:#171c24;border:1px solid #28313d;border-radius:14px;padding:16px}}.metric span{{display:block;font-size:20px;margin-top:8px}}.charts{{display:grid;grid-template-columns:repeat(auto-fit,minmax(480px,1fr));gap:18px}}img{{width:100%;background:white;border-radius:10px}}h3{{font-weight:600}}small{{color:#9aa7b5}}</style></head><body><main>
<h1>SYNERGY CHAIN — Dual Contour v5</h1><p class="lead">Two-contour simulation: real Base inventory remains the only source of HardNAV, while non-redeemable shadow assets can be minted and burned on SYNERGY CHAIN to manage internal liquidity and spread. Synthetic market capitalization is deliberately excluded from real wealth.</p>
<div class="metrics">{summary_html}</div><div class="charts">{cards}</div>
<p><small>Simulation/shadow environment. Synthetic issuance is not counted as profit or external collateral.</small></p></main></body></html>'''
    html_path = out / "dual_contour_500_blocks_report.html"
    html_path.write_text(html, encoding="utf-8")
    return html_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("report", type=Path)
    ap.add_argument("output_dir", type=Path)
    args = ap.parse_args()
    print(render_dual_contour_report(args.report, args.output_dir))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
