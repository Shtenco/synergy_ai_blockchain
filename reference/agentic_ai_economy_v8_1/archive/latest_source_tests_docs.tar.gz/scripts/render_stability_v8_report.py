from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt


def _line(path: Path, x, series, title: str, ylabel: str) -> None:
    fig = plt.figure(figsize=(11, 6))
    ax = fig.add_subplot(111)
    for label, values in series:
        ax.plot(x, values, label=label)
    ax.set_title(title)
    ax.set_xlabel('Block')
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def render(source: Path, outdir: Path) -> Path:
    data = json.loads(Path(source).read_text(encoding='utf-8'))
    snaps = data['snapshots']
    outdir = Path(outdir)
    charts = outdir / 'charts'
    charts.mkdir(parents=True, exist_ok=True)
    x = [s['block'] for s in snaps]

    _line(
        charts / '01_total_system_wealth.png', x,
        [
            ('Economic Net Worth', [s['economic_net_worth'] for s in snaps]),
            ('Protected Wealth', [s['protected_wealth'] for s in snaps]),
            ('Risk Capital', [s['risk_capital'] for s in snaps]),
            ('High-Water Mark', [s['high_water_mark'] for s in snaps]),
            ('Wealth Floor', [s['wealth_floor'] for s in snaps]),
            ('HODL', [s['hodl_benchmark'] for s in snaps]),
        ],
        'SYNERGY v8 — total system wealth and protection floor', 'USDC-equivalent'
    )
    _line(charts / '02_hedged_vs_unhedged.png', x, [
        ('v8 hedged', [s['economic_net_worth'] for s in snaps]),
        ('unhedged v5 path', [s['unhedged_capital_adjusted_wealth'] for s in snaps]),
        ('HODL', [s['hodl_benchmark'] for s in snaps]),
    ], 'Hedged vs unhedged capital-adjusted wealth', 'USDC-equivalent')
    _line(charts / '03_fund_nav.png', x, [
        ('Stability Fund NAV', [s['stability_fund_nav'] for s in snaps]),
        ('Allocated capital', [float(data['stability_fund_initial_allocation'])] * len(x)),
    ], 'Global Stability Fund NAV', 'USDC-equivalent')
    _line(charts / '04_floor_buffer.png', x, [('Floor buffer', [s['floor_buffer_pct'] for s in snaps])], 'Distance to Wealth Floor', 'Percent')
    _line(charts / '05_hedge_pnl_costs.png', x, [
        ('Hedge PnL', [s['hedge_pnl'] for s in snaps]),
        ('Execution fees', [s['hedge_fees'] for s in snaps]),
        ('Funding cost', [s['hedge_funding_cost'] for s in snaps]),
    ], 'External hedge PnL and insurance costs', 'USDC')
    _line(charts / '06_balance_sheet_layers.png', x, [
        ('Economic Net Worth', [s['economic_net_worth'] for s in snaps]),
        ('Collateral NAV', [s['collateral_nav'] for s in snaps]),
        ('Gross TVL', [s['gross_tvl'] for s in snaps]),
    ], 'Hard wealth vs collateral NAV vs Gross TVL', 'USDC-equivalent')
    _line(charts / '07_banking_ratios.png', x, [
        ('CCR', [s['ccr'] for s in snaps]),
        ('LCR', [s['lcr'] for s in snaps]),
    ], 'SYNERGY internal banking ratios', 'Ratio')
    _line(charts / '08_recursive_claims.png', x, [('Internal claims', [s['internal_claims'] for s in snaps])], 'Recursive collateral claims', 'USDC-equivalent')
    _line(charts / '09_target_hedge_ratio.png', x, [('Hedge ratio', [s['target_hedge_ratio'] * 100 for s in snaps])], 'Global hedge target', 'Percent of real Base exposure')
    _line(charts / '10_bridge_real_nav.png', x, [('Bridge real NAV', [s['bridge_real_nav'] for s in snaps])], 'Real inventory bridge NAV', 'USDC-equivalent')

    cards = []
    for p in sorted(charts.glob('*.png')):
        cards.append(f'<section><h2>{p.stem.replace("_", " ").title()}</h2><img src="charts/{p.name}"></section>')
    summary = f"""
    <section><h2>Reference summary</h2>
      <p>Opening wealth: {data['opening_system_real_wealth']}</p>
      <p>Capital-adjusted close: {data['capital_adjusted_closing_wealth']}</p>
      <p>Alpha vs HODL: {data['system_alpha_vs_hodl']}</p>
      <p>Max drawdown: {data['max_adjusted_drawdown_pct']}%</p>
      <p>Initial Stability Fund allocation: {data['stability_fund_initial_allocation']}</p>
      <p>Stability Fund NAV end: {data['stability_fund_nav_end']}</p>
      <p>Floor breaches: {data['floor_breaches']}</p>
      <p>Protection drag vs unhedged: {data['protection_drag_vs_unhedged']}</p>
    </section>
    """
    html = f'''<!doctype html><html><head><meta charset="utf-8"><title>SYNERGY v8 Stability Report</title>
    <style>body{{font-family:Arial,sans-serif;background:#0e1116;color:#eef2f7;margin:0}}main{{max-width:1200px;margin:auto;padding:28px}}section{{background:#171c24;border:1px solid #28313d;border-radius:14px;padding:16px;margin:18px 0}}img{{width:100%;border-radius:10px;background:white}}p{{color:#c0cad6}}</style></head><body><main>
    <h1>SYNERGY Global Stability Fund v8</h1>{summary}{''.join(cards)}</main></body></html>'''
    target = outdir / 'stability_v8_report.html'
    target.write_text(html, encoding='utf-8')
    return target


def main() -> int:
    if len(sys.argv) != 3:
        print('usage: render_stability_v8_report.py <source.json> <outdir>', file=sys.stderr)
        return 2
    target = render(Path(sys.argv[1]), Path(sys.argv[2]))
    print(target)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
