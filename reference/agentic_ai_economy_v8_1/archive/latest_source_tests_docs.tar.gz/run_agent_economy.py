#!/usr/bin/env python3
from __future__ import annotations

import argparse
from decimal import Decimal
import json
from pathlib import Path

from agent_economy.engine import AgentEconomy, EconomyConfig


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run SYNERGY Autonomous Agent Economy v2")
    parser.add_argument("--agents", type=int, default=24, help="number of autonomous agents")
    parser.add_argument("--steps", type=int, default=365, help="simulation ticks")
    parser.add_argument("--seed", type=int, default=42, help="deterministic random seed")
    parser.add_argument("--initial-cash", default="30", help="opening USDC cash per agent")
    parser.add_argument("--shadow", action="store_true", help="label execution mode as shadow instead of simulation")
    parser.add_argument("--json", type=Path, help="optional path for a JSON report")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = EconomyConfig(
        agent_count=args.agents,
        steps=args.steps,
        seed=args.seed,
        initial_cash=Decimal(args.initial_cash),
        execution_mode="shadow" if args.shadow else "simulation",
    )
    economy = AgentEconomy(config)
    report = economy.run()

    print("SYNERGY Agent Economy v2")
    print(f"Mode: {config.execution_mode}")
    print(f"Agents / steps: {report.agent_count} / {report.steps}")
    print(f"Opening capital: ${report.opening_capital}")
    print(f"External income: ${report.external_income}")
    print(f"External expense: ${report.external_expense}")
    print(f"Closing system cash: ${report.closing_system_cash}")
    print(f"Founder revenue: ${report.founder_total_revenue}")
    print(f"  externally attributed: ${report.founder_external_attributed_revenue}")
    print(f"  internal fee capture: ${report.founder_internal_fee_revenue}")
    print(
        "Markets: "
        f"jobs={report.jobs_completed}/{report.jobs_posted}, "
        f"subcontracts={report.subcontracts_completed}, "
        f"loans={report.loans_originated} (defaults={report.loans_defaulted}), "
        f"deposits={report.deposits_opened} (defaults={report.deposits_defaulted}), "
        f"investments={report.investments_opened}, companies={report.companies_formed}"
    )
    print(f"Policy research reports: {report.policy_reports}")
    print(
        f"Insurance policies: {report.insurance_policies} "
        f"(claims=${report.insurance_claims_paid}, insurer_defaults={report.insurer_defaults})"
    )
    print(f"Bankruptcy cases: {report.bankruptcy_cases}")
    print(f"Strategy updates: {report.strategy_updates}")
    print(f"Bad debt loss: ${report.bad_debt_loss}")
    print(f"Accounting conservation gap: {report.conservation_gap}")

    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"JSON report: {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
