from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

D = Decimal


@dataclass(frozen=True)
class SupplyEvent:
    asset: str
    amount: Decimal
    kind: str
    reason: str


class ShadowChainLedger:
    """Supply ledger for SYNERGY CHAIN synthetic assets.

    Shadow supply is explicitly non-redeemable and never contributes to
    external HardNAV. It is accounting for the internal chain only.
    """

    def __init__(self, assets: tuple[str, ...]):
        self._supply = {a: D("0") for a in assets}
        self._minted = {a: D("0") for a in assets}
        self._burned = {a: D("0") for a in assets}
        self.events: list[SupplyEvent] = []

    def _check(self, asset: str) -> None:
        if asset not in self._supply:
            raise KeyError(asset)

    def mint(self, asset: str, amount: Decimal, *, reason: str) -> Decimal:
        self._check(asset)
        amount = D(amount)
        if amount <= 0:
            raise ValueError("mint amount must be positive")
        self._supply[asset] += amount
        self._minted[asset] += amount
        self.events.append(SupplyEvent(asset, amount, "mint", reason))
        return amount

    def burn(self, asset: str, amount: Decimal, *, reason: str) -> Decimal:
        self._check(asset)
        amount = D(amount)
        if amount <= 0:
            raise ValueError("burn amount must be positive")
        amount = min(amount, self._supply[asset])
        self._supply[asset] -= amount
        self._burned[asset] += amount
        self.events.append(SupplyEvent(asset, amount, "burn", reason))
        return amount

    def supply(self, asset: str) -> Decimal:
        self._check(asset)
        return self._supply[asset]

    def supplies(self) -> dict[str, Decimal]:
        return dict(self._supply)

    def total_minted(self, asset: str) -> Decimal:
        self._check(asset)
        return self._minted[asset]

    def total_burned(self, asset: str) -> Decimal:
        self._check(asset)
        return self._burned[asset]

    def hard_nav_effect(self) -> Decimal:
        return D("0")
