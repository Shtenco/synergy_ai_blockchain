from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
from typing import Any

DEFAULT_ASSETS = (
    "sRUBX", "sRUBZ", "sUSDC", "sWETH", "scbBTC", "sVVV", "sVIRTUAL",
    "sAERO", "scbETH", "sUSDe", "scbXRP", "sTOSHI", "sMORPHO",
)


@dataclass(frozen=True)
class SynergyChainConfig:
    name: str = "SYNERGY CHAIN"
    chain_id: int = 777_777
    parent_family: str = "Base / OP Stack compatible simulation"
    block_seconds: int = 12
    external_redemption_enabled: bool = False


@dataclass(frozen=True)
class ChainTx:
    kind: str
    payload: dict[str, Any]


@dataclass(frozen=True)
class ChainBlock:
    number: int
    timestamp_seconds: int
    parent_hash: str
    block_hash: str
    txs: tuple[ChainTx, ...]


class SynergyChain:
    """Deterministic internal-chain simulation layer.

    This intentionally models block production, linkage and event ordering but
    does not pretend to be a deployed OP Stack node. External redemption is
    disabled by configuration; inventory interaction is handled by the bridge.
    """

    def __init__(self, config: SynergyChainConfig | None = None):
        self.config = config or SynergyChainConfig()
        if self.config.block_seconds <= 0:
            raise ValueError("block_seconds must be positive")
        self.asset_registry = tuple(DEFAULT_ASSETS)
        self.blocks: list[ChainBlock] = []
        self._pending: list[ChainTx] = []
        self._genesis_hash = hashlib.sha256(
            f"{self.config.name}:{self.config.chain_id}:genesis".encode()
        ).hexdigest()

    @property
    def height(self) -> int:
        return len(self.blocks)

    @property
    def tip_hash(self) -> str:
        return self.blocks[-1].block_hash if self.blocks else self._genesis_hash

    def record(self, kind: str, payload: dict[str, Any]) -> None:
        if not kind:
            raise ValueError("transaction kind required")
        self._pending.append(ChainTx(kind, dict(payload)))

    def seal_block(self) -> ChainBlock:
        number = self.height + 1
        timestamp = number * self.config.block_seconds
        parent = self.tip_hash
        body = {
            "number": number,
            "timestamp": timestamp,
            "parent": parent,
            "txs": [asdict(tx) for tx in self._pending],
        }
        digest = hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        block = ChainBlock(number, timestamp, parent, digest, tuple(self._pending))
        self.blocks.append(block)
        self._pending = []
        return block
