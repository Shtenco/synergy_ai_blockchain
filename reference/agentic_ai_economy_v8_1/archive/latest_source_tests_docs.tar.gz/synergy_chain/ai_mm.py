from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from macro_economy.amm import CPMMPool
from .ledger import ShadowChainLedger

D = Decimal


def _clamp(x: Decimal, lo: Decimal, hi: Decimal) -> Decimal:
    return max(lo, min(hi, x))


@dataclass(frozen=True)
class MarketMakerAction:
    symbol: str
    kind: str
    target_spread_bps: Decimal
    notional_usdc: Decimal = D("0")
    synthetic_minted: Decimal = D("0")
    synthetic_burned: Decimal = D("0")


class AdaptiveAIMarketMaker:
    """Adaptive two-contour MM policy.

    The policy controls an internal premium and real external delta. Internal
    mint/burn is synthetic-only; real PnL can only arise from bridge execution.
    """

    def __init__(
        self,
        *,
        base_spread_bps: Decimal = D("20"),
        band_bps: Decimal = D("3"),
        base_delta: Decimal = D("0.50"),
    ) -> None:
        self.base_spread_bps = D(base_spread_bps)
        self.band_bps = D(band_bps)
        self.base_delta = D(base_delta)
        self.reward_ewma = D("0")
        self.actions = 0

    def target_spread(self, volatility: Decimal, inventory_skew: Decimal, momentum: Decimal = D("0")) -> Decimal:
        vol = max(D("0"), D(volatility))
        skew = D(inventory_skew)
        mom = D(momentum)
        adaptive = self.base_spread_bps + vol * D("1400") + abs(skew) * D("18")
        # Counter-cyclical spread: rising external markets receive a lower/negative
        # internal premium (mint/sell pressure); falling markets receive a higher
        # premium (buyback/burn support). This intentionally gives the shadow
        # market a beta below one to the external market.
        adaptive -= mom * D("12000")
        # modest online adaptation: positive reward can safely tighten spread;
        # negative reward widens it to demand more compensation.
        adaptive -= _clamp(self.reward_ewma, D("-2"), D("2")) * D("1.5")
        return _clamp(adaptive, D("-250"), D("250"))

    def observe_reward(self, reward_usdc: Decimal) -> None:
        r = D(reward_usdc)
        self.reward_ewma = self.reward_ewma * D("0.94") + r * D("0.06")

    def target_external_delta(self, *, momentum: Decimal, drawdown: Decimal, volatility: Decimal) -> Decimal:
        momentum, drawdown, volatility = D(momentum), max(D("0"), D(drawdown)), max(D("0"), D(volatility))
        # Sell strength (positive momentum -> lower real delta), restore on
        # weakness/drawdown. Volatility independently de-risks the book.
        target = self.base_delta - momentum * D("8.0") + drawdown * D("3.5") - volatility * D("1.4")
        return _clamp(target, D("0.15"), D("0.90"))

    @staticmethod
    def _sell_a_to_target(pool: CPMMPool, target: Decimal) -> Decimal:
        a, b = pool.reserve_a, pool.reserve_b
        f = D("1") - D(pool.fee_bps) / D("10000")
        # target = k / ((a+f*x)(a+x))
        c = a * a - pool.k / target
        bb = a * (D("1") + f)
        disc = bb * bb - D("4") * f * c
        if disc <= 0:
            return D("0")
        root = (-bb + disc.sqrt()) / (D("2") * f)
        return max(D("0"), root)

    @staticmethod
    def _buy_a_to_target(pool: CPMMPool, target: Decimal) -> Decimal:
        a, b = pool.reserve_a, pool.reserve_b
        f = D("1") - D(pool.fee_bps) / D("10000")
        # target = ((b+y)(b+f*y))/k
        c = b * b - target * pool.k
        bb = b * (D("1") + f)
        disc = bb * bb - D("4") * f * c
        if disc <= 0:
            return D("0")
        root = (-bb + disc.sqrt()) / (D("2") * f)
        return max(D("0"), root)

    def stabilize_internal_pool(
        self,
        *,
        symbol: str,
        pool: CPMMPool,
        ledger: ShadowChainLedger,
        external_price: Decimal,
        volatility: Decimal,
        inventory_skew: Decimal,
        momentum: Decimal = D("0"),
    ) -> MarketMakerAction:
        external_price = D(external_price)
        target_bps = self.target_spread(volatility, inventory_skew, momentum)
        target = external_price * (D("1") + target_bps / D("10000"))
        current = pool.price_a_in_b
        deviation_bps = (current / target - D("1")) * D("10000")
        if abs(deviation_bps) <= self.band_bps:
            return MarketMakerAction(symbol, "hold", target_bps)

        synth_asset = f"s{symbol}"
        if current > target:
            token_in = self._sell_a_to_target(pool, target)
            if token_in <= 0:
                return MarketMakerAction(symbol, "hold", target_bps)
            ledger.mint(synth_asset, token_in, reason="ai-mm:mint-sell")
            swap = pool.swap_a_for_b(token_in)
            self.actions += 1
            return MarketMakerAction(symbol, "mint_sell", target_bps, swap.amount_out, token_in, D("0"))

        usdc_in = self._buy_a_to_target(pool, target)
        if usdc_in <= 0:
            return MarketMakerAction(symbol, "hold", target_bps)
        ledger.mint("sUSDC", usdc_in, reason="ai-mm:buyback-liquidity")
        swap = pool.swap_b_for_a(usdc_in)
        burned = ledger.burn(synth_asset, swap.amount_out, reason="ai-mm:buyback-burn")
        self.actions += 1
        return MarketMakerAction(symbol, "buy_burn", target_bps, usdc_in, D("0"), burned)
