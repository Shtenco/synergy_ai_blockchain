from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

D = Decimal
Q = D("0.000000000001")


@dataclass(frozen=True)
class ExternalExecution:
    symbol: str
    side: str
    notional_usdc: Decimal
    fee_usdc: Decimal
    realized_pnl_usdc: Decimal


class InventoryBridge:
    """One-way inventory bridge between real Base inventory and SYNERGY CHAIN.

    Real inventory is custody backing/risk capital. Shadow assets are not
    redeemable back through this object. Synthetic capacity is bounded by a
    leverage multiple of marked real inventory.
    """

    def __init__(self, *, max_synthetic_leverage: Decimal = D("4"), execution_fee_bps: Decimal = D("4")):
        self.max_synthetic_leverage = D(max_synthetic_leverage)
        self.execution_fee_bps = D(execution_fee_bps)
        self.real_balances: dict[str, Decimal] = {"USDC": D("0")}
        self.cost_basis: dict[str, Decimal] = {}
        self.synthetic_value_reserved = D("0")
        self.realized_pnl_usdc = D("0")
        self.external_fees_usdc = D("0")
        self.external_volume_usdc = D("0")
        self.deposits: list[tuple[str, Decimal, str]] = []

    def deposit_real(self, symbol: str, amount: Decimal, price: Decimal, *, source: str) -> None:
        amount, price = D(amount), D(price)
        if amount <= 0 or price <= 0:
            raise ValueError("amount and price must be positive")
        old = self.real_balances.get(symbol, D("0"))
        if symbol != "USDC":
            old_cost = self.cost_basis.get(symbol, price)
            new = old + amount
            self.cost_basis[symbol] = ((old * old_cost) + amount * price) / new
        self.real_balances[symbol] = old + amount
        self.deposits.append((symbol, amount, source))

    def real_nav(self, prices: dict[str, Decimal]) -> Decimal:
        total = self.real_balances.get("USDC", D("0"))
        for symbol, amount in self.real_balances.items():
            if symbol == "USDC":
                continue
            total += amount * D(prices[symbol])
        return total.quantize(Q)

    def synthetic_capacity_usdc(self, prices: dict[str, Decimal]) -> Decimal:
        return (self.real_nav(prices) * self.max_synthetic_leverage).quantize(Q)

    def reserve_synthetic_value(self, amount: Decimal, prices: dict[str, Decimal] | None = None) -> None:
        amount = D(amount)
        if amount < 0:
            raise ValueError("reserved value cannot be negative")
        if prices is None:
            # Useful for tests immediately after deposits at their deposit marks.
            marked = self.real_balances.get("USDC", D("0"))
            for s, q in self.real_balances.items():
                if s != "USDC":
                    marked += q * self.cost_basis[s]
            cap = marked * self.max_synthetic_leverage
        else:
            cap = self.synthetic_capacity_usdc(prices)
        if self.synthetic_value_reserved + amount > cap + D("0.000000001"):
            raise ValueError("synthetic capacity exceeded")
        self.synthetic_value_reserved += amount

    def sell_real(self, symbol: str, quantity: Decimal, price: Decimal) -> ExternalExecution:
        quantity, price = D(quantity), D(price)
        held = self.real_balances.get(symbol, D("0"))
        quantity = min(quantity, held)
        if quantity <= 0:
            return ExternalExecution(symbol, "sell", D("0"), D("0"), D("0"))
        gross = quantity * price
        fee = gross * self.execution_fee_bps / D("10000")
        proceeds = gross - fee
        cost = quantity * self.cost_basis.get(symbol, price)
        pnl = proceeds - cost
        self.real_balances[symbol] = held - quantity
        self.real_balances["USDC"] = self.real_balances.get("USDC", D("0")) + proceeds
        self.realized_pnl_usdc += pnl
        self.external_fees_usdc += fee
        self.external_volume_usdc += gross
        return ExternalExecution(symbol, "sell", gross, fee, pnl)

    def buy_real(self, symbol: str, notional_usdc: Decimal, price: Decimal) -> ExternalExecution:
        notional_usdc, price = D(notional_usdc), D(price)
        cash = self.real_balances.get("USDC", D("0"))
        spend = min(notional_usdc, cash)
        if spend <= 0:
            return ExternalExecution(symbol, "buy", D("0"), D("0"), D("0"))
        fee = spend * self.execution_fee_bps / D("10000")
        net = spend - fee
        qty = net / price
        old_q = self.real_balances.get(symbol, D("0"))
        old_cost = self.cost_basis.get(symbol, price)
        new_q = old_q + qty
        self.cost_basis[symbol] = ((old_q * old_cost) + net) / new_q
        self.real_balances[symbol] = new_q
        self.real_balances["USDC"] = cash - spend
        self.external_fees_usdc += fee
        self.external_volume_usdc += spend
        # Purchases do not realize PnL; fee is reflected in NAV through lower cash.
        return ExternalExecution(symbol, "buy", spend, fee, D("0"))
