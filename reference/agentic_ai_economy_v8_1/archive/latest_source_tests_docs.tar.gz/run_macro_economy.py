#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from macro_economy.engine import MacroConfig, MacroEconomy


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run SYNERGY Agent Capital Markets v4")
    p.add_argument("--blocks", type=int, default=500)
    p.add_argument("--block-seconds", type=int, default=12)
    p.add_argument("--seed", type=int, default=77)
    p.add_argument("--json", type=Path)
    p.add_argument("--csv", type=Path)
    return p.parse_args()


def write_csv(path: Path, snapshots: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    price_keys = sorted(snapshots[0]["prices"]) if snapshots else []
    rows = []
    for snap in snapshots:
        row = {k: v for k, v in snap.items() if k not in {"prices", "allocation"}}
        for sym in price_keys:
            row[f"price_{sym}"] = snap["prices"][sym]
        for asset, weight in snap.get("allocation", {}).items():
            row[f"alloc_{asset}"] = weight
        rows.append(row)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    args = parse_args()
    report = MacroEconomy(
        MacroConfig(blocks=args.blocks, block_seconds=args.block_seconds, seed=args.seed)
    ).run()

    print("SYNERGY Agent Capital Markets v4")
    print(f"Blocks: {report.blocks} x {report.block_seconds}s = {report.elapsed_seconds}s")
    print(f"Opening real wealth: ${report.opening_system_real_wealth}")
    print(f"Closing real wealth: ${report.closing_system_real_wealth}")
    print(f"Net external capital flow: ${report.net_external_capital_flow}")
    print(f"Capital-adjusted closing wealth: ${report.capital_adjusted_closing_wealth}")
    print(f"HODL benchmark: ${report.closing_hodl_benchmark}")
    print(f"Alpha vs HODL: ${report.system_alpha_vs_hodl}")
    print(f"Founder external revenue: ${report.founder_external_revenue}")
    print(f"RUBX coverage: {report.rubx_start_coverage} -> {report.rubx_end_coverage}")
    print(f"Max adjusted drawdown: {report.max_adjusted_drawdown_pct}%")
    print(f"Companies: {report.company_count}; equity issuance: ${report.equity_issuance_usdc}; bond issuance: ${report.bond_issuance_usdc}")
    print(f"Portfolio loans: {report.portfolio_loans_originated}; utilization: {report.credit_utilization_end}; bad debt: ${report.credit_bad_debt_usdc}")
    curve = ", ".join(f"{k}d={v}" for k, v in report.yield_curve_end.items())
    print(f"SYNERGY yield curve: {curve}")

    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"JSON: {args.json}")
    if args.csv:
        write_csv(args.csv, report.snapshots)
        print(f"CSV: {args.csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
