from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .amm import CPMMPool

D = Decimal


@dataclass
class TriangleEconomy:
    treasury_usdc: Decimal
    rubx_supply: Decimal
    rubz_supply: Decimal
    xu: CPMMPool
    zu: CPMMPool
    xz: CPMMPool
    rubx_face_value: Decimal = D("1")
    reserve_floor_usdc: Decimal = D("200")
    capital_scale: Decimal = D("1")

    @classmethod
    def default(cls, scale: Decimal = D("1")) -> "TriangleEconomy":
        s = D(scale)
        return cls(
            treasury_usdc=D("1000") * s,
            rubx_supply=D("1000") * s,
            rubz_supply=D("1000") * s,
            xu=CPMMPool("RUBX", "USDC", D("500") * s, D("500") * s, fee_bps=30),
            zu=CPMMPool("RUBZ", "USDC", D("500") * s, D("500") * s, fee_bps=30),
            xz=CPMMPool("RUBX", "RUBZ", D("500") * s, D("500") * s, fee_bps=30),
            reserve_floor_usdc=D("200") * s,
            capital_scale=s,
        )

    def hard_nav(self) -> Decimal:
        # Internal RUBX/RUBZ are excluded. Only real settlement reserves count.
        return self.treasury_usdc + self.xu.reserve_b + self.zu.reserve_b

    def gross_tvl(self) -> Decimal:
        # Mark internal assets using their observable USDC markets.
        px_x = self.rubx_price()
        px_z = self.rubz_price()
        return (
            self.xu.reserve_b + self.xu.reserve_a * px_x
            + self.zu.reserve_b + self.zu.reserve_a * px_z
            + self.xz.reserve_a * px_x + self.xz.reserve_b * px_z
        )

    def rubx_price(self) -> Decimal:
        return self.xu.price_a_in_b

    def rubz_price(self) -> Decimal:
        return self.zu.price_a_in_b

    def rubx_via_z_price(self) -> Decimal:
        return self.xz.price_a_in_b * self.rubz_price()

    def rubx_liability(self) -> Decimal:
        return self.rubx_supply * self.rubx_face_value

    def residual_equity(self) -> Decimal:
        return self.hard_nav() - self.rubx_liability()

    def rubz_fair_value(self) -> Decimal:
        if self.rubz_supply <= 0:
            return D("0")
        return max(D("0"), self.residual_equity()) / self.rubz_supply

    def coverage_ratio(self) -> Decimal:
        liability = self.rubx_liability()
        if liability <= 0:
            return D("Infinity")
        return self.hard_nav() / liability

    def mint_rubx(self, amount: Decimal) -> None:
        amount = D(amount)
        if amount <= 0:
            raise ValueError("mint amount must be positive")
        self.rubx_supply += amount

    def mint_rubz(self, amount: Decimal) -> None:
        amount = D(amount)
        if amount <= 0:
            raise ValueError("mint amount must be positive")
        self.rubz_supply += amount

    def mint_sell_rubx(self, amount: Decimal) -> Decimal:
        amount = D(amount)
        self.mint_rubx(amount)
        swap = self.xu.swap_a_for_b(amount)
        self.treasury_usdc += swap.amount_out
        return swap.amount_out

    def mint_sell_rubz(self, amount: Decimal) -> Decimal:
        amount = D(amount)
        self.mint_rubz(amount)
        swap = self.zu.swap_a_for_b(amount)
        self.treasury_usdc += swap.amount_out
        return swap.amount_out

    def buy_burn_rubx(self, spend_usdc: Decimal) -> Decimal:
        spend = min(D(spend_usdc), max(D("0"), self.treasury_usdc - self.reserve_floor_usdc))
        if spend <= 0:
            return D("0")
        swap = self.xu.swap_b_for_a(spend)
        self.treasury_usdc -= spend
        burned = min(self.rubx_supply, swap.amount_out)
        self.rubx_supply -= burned
        return burned

    def buy_burn_rubz(self, spend_usdc: Decimal) -> Decimal:
        spend = min(D(spend_usdc), max(D("0"), self.treasury_usdc - self.reserve_floor_usdc))
        if spend <= 0:
            return D("0")
        swap = self.zu.swap_b_for_a(spend)
        self.treasury_usdc -= spend
        burned = min(self.rubz_supply, swap.amount_out)
        self.rubz_supply -= burned
        return burned

    def add_xz_liquidity_by_mint(self, rubx_amount: Decimal, rubz_amount: Decimal) -> None:
        x = D(rubx_amount)
        z = D(rubz_amount)
        if x <= 0 or z <= 0:
            raise ValueError("liquidity amounts must be positive")
        self.mint_rubx(x)
        self.mint_rubz(z)
        self.xz.reserve_a += x
        self.xz.reserve_b += z

    def triangular_arbitrage(self, spend_usdc: Decimal) -> dict[str, Decimal | str]:
        spend = min(D(spend_usdc), max(D("0"), self.treasury_usdc - self.reserve_floor_usdc))
        if spend <= 0:
            return {"action": "none", "input": D("0"), "output": D("0")}

        x1 = self.xu.quote_b_for_a(spend)
        z1 = self.xz.quote_a_for_b(x1)
        u1 = self.zu.quote_a_for_b(z1)

        z2 = self.zu.quote_b_for_a(spend)
        x2 = self.xz.quote_b_for_a(z2)
        u2 = self.xu.quote_a_for_b(x2)

        threshold = spend * D("1.0001")
        if max(u1, u2) <= threshold:
            return {"action": "none", "input": spend, "output": max(u1, u2)}

        self.treasury_usdc -= spend
        if u1 >= u2:
            x = self.xu.swap_b_for_a(spend).amount_out
            z = self.xz.swap_a_for_b(x).amount_out
            out = self.zu.swap_a_for_b(z).amount_out
            action = "u-x-z-u"
        else:
            z = self.zu.swap_b_for_a(spend).amount_out
            x = self.xz.swap_b_for_a(z).amount_out
            out = self.xu.swap_a_for_b(x).amount_out
            action = "u-z-x-u"
        self.treasury_usdc += out
        return {"action": action, "input": spend, "output": out}

    def controller_step(self) -> dict[str, Decimal | str]:
        """Small bounded monetary/equity controller; all actions are HardNAV-neutral."""
        px_x = self.rubx_price()
        px_z = self.rubz_price()
        fair_z = self.rubz_fair_value()
        action = "none"
        amount = D("0")
        if px_x > self.rubx_face_value * D("1.01"):
            amount = min(D("5") * self.capital_scale, self.xu.reserve_a * D("0.01"))
            self.mint_sell_rubx(amount)
            action = "issue_rubx"
        elif px_x < self.rubx_face_value * D("0.99"):
            amount = min(D("5") * self.capital_scale, max(D("0"), self.treasury_usdc - self.reserve_floor_usdc) * D("0.01"))
            self.buy_burn_rubx(amount)
            action = "buyburn_rubx"
        elif fair_z > 0 and px_z > fair_z * D("1.03"):
            amount = min(D("5") * self.capital_scale, self.zu.reserve_a * D("0.01"))
            self.mint_sell_rubz(amount)
            action = "issue_rubz"
        elif fair_z > 0 and px_z < fair_z * D("0.97"):
            amount = min(D("5") * self.capital_scale, max(D("0"), self.treasury_usdc - self.reserve_floor_usdc) * D("0.01"))
            self.buy_burn_rubz(amount)
            action = "buyburn_rubz"
        return {"action": action, "amount": amount}
