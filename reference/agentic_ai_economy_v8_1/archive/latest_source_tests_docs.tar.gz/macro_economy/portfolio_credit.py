from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .agents import MarketAgent
from .securities import SecuritiesMarket
from .yield_curve import YEAR_SECONDS

D = Decimal


@dataclass
class PortfolioLoan:
    loan_id: str
    borrower_id: str
    principal: Decimal
    annual_rate: Decimal
    start_block: int
    maturity_block: int
    block_seconds: int
    status: str = 'active'
    amount_repaid_usdc: Decimal = D('0')
    collateral_recovered_usdc: Decimal = D('0')
    bad_debt_usdc: Decimal = D('0')
    margin_calls: int = 0

    def elapsed_seconds(self, current_block: int) -> int:
        blocks = max(0, min(int(current_block), self.maturity_block) - self.start_block)
        return blocks * self.block_seconds

    def amount_due(self, current_block: int) -> Decimal:
        return self.principal * (D('1') + self.annual_rate * D(self.elapsed_seconds(current_block)) / YEAR_SECONDS)


class PortfolioCreditFacility:
    """Reserve-funded portfolio credit with mark-to-market margining.

    The reserve is real USDC. Lending moves that USDC to a borrower. Collateral
    marks determine risk capacity but are never minted or double-counted.
    """

    def __init__(
        self,
        *,
        reserve_usdc: Decimal,
        block_seconds: int = 12,
        base_haircut: Decimal = D('0.70'),
        rubx_haircut: Decimal = D('0.90'),
        rubz_haircut: Decimal = D('0.55'),
        equity_haircut: Decimal = D('0.45'),
        max_capacity_fraction: Decimal = D('0.90'),
        maintenance_health_factor: Decimal = D('1.10'),
    ) -> None:
        reserve = D(reserve_usdc)
        if reserve < 0 or block_seconds <= 0:
            raise ValueError('invalid credit facility configuration')
        self.reserve_usdc = reserve
        self.block_seconds = int(block_seconds)
        self.base_haircut = D(base_haircut)
        self.rubx_haircut = D(rubx_haircut)
        self.rubz_haircut = D(rubz_haircut)
        self.equity_haircut = D(equity_haircut)
        self.max_capacity_fraction = D(max_capacity_fraction)
        self.maintenance_health_factor = D(maintenance_health_factor)
        if self.maintenance_health_factor < D('1'):
            raise ValueError('maintenance_health_factor must be at least 1')
        self.loans: dict[str, PortfolioLoan] = {}
        self._next_loan = 1
        self.seized_assets: dict[str, Decimal] = {}
        self.seized_rubx = D('0')
        self.seized_rubz = D('0')
        self.seized_equity: dict[str, Decimal] = {}
        self.total_originated_usdc = D('0')
        self.total_bad_debt_usdc = D('0')
        self.total_interest_paid_usdc = D('0')
        self.total_margin_calls = 0
        self.total_liquidations = 0

    def collateral_value(
        self,
        borrower: MarketAgent,
        *,
        prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        securities: SecuritiesMarket,
    ) -> Decimal:
        value = D('0')
        for symbol, qty in borrower.holdings.items():
            if symbol in prices and qty > 0:
                value += qty * D(prices[symbol]) * self.base_haircut
        value += max(D('0'), borrower.rubx) * D(rubx_price) * self.rubx_haircut
        value += max(D('0'), borrower.rubz) * D(rubz_price) * self.rubz_haircut
        for company in securities.companies.values():
            shares = company.shareholders.get(borrower.agent_id, D('0'))
            if shares > 0:
                value += shares * company.equity_price(prices) * self.equity_haircut
        return max(D('0'), value)

    def available_capacity(
        self,
        borrower: MarketAgent,
        *,
        prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        securities: SecuritiesMarket,
        current_block: int,
    ) -> Decimal:
        collateral = self.collateral_value(
            borrower,
            prices=prices,
            rubx_price=rubx_price,
            rubz_price=rubz_price,
            securities=securities,
        ) * self.max_capacity_fraction
        debt = sum(
            (loan.amount_due(current_block) for loan in self.loans.values() if loan.borrower_id == borrower.agent_id and loan.status == 'active'),
            D('0'),
        )
        return max(D('0'), min(self.reserve_usdc, collateral - debt))

    def originate(
        self,
        borrower: MarketAgent,
        *,
        principal: Decimal,
        annual_rate: Decimal,
        current_block: int,
        maturity_block: int,
        prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        securities: SecuritiesMarket,
    ) -> PortfolioLoan:
        principal_d = D(principal)
        rate = D(annual_rate)
        if principal_d <= 0 or rate < 0 or maturity_block <= current_block:
            raise ValueError('invalid loan terms')
        capacity = self.available_capacity(
            borrower,
            prices=prices,
            rubx_price=rubx_price,
            rubz_price=rubz_price,
            securities=securities,
            current_block=current_block,
        )
        if principal_d > capacity:
            raise ValueError('principal exceeds collateral or reserve capacity')
        loan_id = f'portfolio-loan:{self._next_loan}'
        self._next_loan += 1
        self.reserve_usdc -= principal_d
        borrower.cash_usdc += principal_d
        loan = PortfolioLoan(
            loan_id=loan_id,
            borrower_id=borrower.agent_id,
            principal=principal_d,
            annual_rate=rate,
            start_block=int(current_block),
            maturity_block=int(maturity_block),
            block_seconds=self.block_seconds,
        )
        self.loans[loan_id] = loan
        self.total_originated_usdc += principal_d
        return loan

    def needs_margin_call(
        self,
        loan_id: str,
        borrower: MarketAgent,
        *,
        current_block: int,
        prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        securities: SecuritiesMarket,
    ) -> bool:
        loan = self.loans[loan_id]
        if loan.status != 'active':
            return False
        due = loan.amount_due(current_block)
        collateral = self.collateral_value(
            borrower,
            prices=prices,
            rubx_price=rubx_price,
            rubz_price=rubz_price,
            securities=securities,
        )
        return collateral < due * self.maintenance_health_factor

    def record_margin_call(self, loan_id: str) -> None:
        loan = self.loans[loan_id]
        if loan.status == 'active':
            loan.margin_calls += 1
            self.total_margin_calls += 1

    def repay(self, loan_id: str, borrower: MarketAgent, *, current_block: int) -> PortfolioLoan:
        loan = self.loans[loan_id]
        if loan.status != 'active':
            return loan
        due = loan.amount_due(current_block)
        paid = min(borrower.cash_usdc, due)
        borrower.cash_usdc -= paid
        self.reserve_usdc += paid
        loan.amount_repaid_usdc += paid
        interest = max(D('0'), paid - loan.principal)
        self.total_interest_paid_usdc += interest
        if paid >= due:
            loan.status = 'repaid'
        return loan

    def _seize_base_assets(self, borrower: MarketAgent, prices: dict[str, Decimal], remaining: Decimal) -> tuple[Decimal, Decimal]:
        recovered = D('0')
        left = remaining
        # Liquidate most valuable positions first to minimize number of touched assets.
        symbols = sorted(
            (s for s, q in borrower.holdings.items() if q > 0 and s in prices),
            key=lambda s: borrower.holdings[s] * D(prices[s]),
            reverse=True,
        )
        for symbol in symbols:
            if left <= 0:
                break
            price = D(prices[symbol])
            held = borrower.holdings.get(symbol, D('0'))
            value = held * price
            take_value = min(value, left)
            qty = take_value / price if price > 0 else D('0')
            borrower.holdings[symbol] = held - qty
            self.seized_assets[symbol] = self.seized_assets.get(symbol, D('0')) + qty
            recovered += take_value
            left -= take_value
        return recovered, left

    def _seize_internal_tokens(self, borrower: MarketAgent, rubx_price: Decimal, rubz_price: Decimal, remaining: Decimal) -> tuple[Decimal, Decimal]:
        recovered = D('0')
        left = remaining
        if left > 0 and borrower.rubx > 0 and rubx_price > 0:
            value = borrower.rubx * D(rubx_price)
            take_value = min(value, left)
            qty = take_value / D(rubx_price)
            borrower.rubx -= qty
            self.seized_rubx += qty
            recovered += take_value
            left -= take_value
        if left > 0 and borrower.rubz > 0 and rubz_price > 0:
            value = borrower.rubz * D(rubz_price)
            take_value = min(value, left)
            qty = take_value / D(rubz_price)
            borrower.rubz -= qty
            self.seized_rubz += qty
            recovered += take_value
            left -= take_value
        return recovered, left

    def _seize_equity(self, borrower: MarketAgent, securities: SecuritiesMarket, prices: dict[str, Decimal], remaining: Decimal) -> tuple[Decimal, Decimal]:
        recovered = D('0')
        left = remaining
        for company in securities.companies.values():
            if left <= 0:
                break
            shares = company.shareholders.get(borrower.agent_id, D('0'))
            price = company.equity_price(prices)
            if shares <= 0 or price <= 0:
                continue
            value = shares * price
            take_value = min(value, left)
            qty = take_value / price
            company.shareholders[borrower.agent_id] = shares - qty
            self.seized_equity[company.company_id] = self.seized_equity.get(company.company_id, D('0')) + qty
            recovered += take_value
            left -= take_value
        return recovered, left

    def liquidate(
        self,
        loan_id: str,
        borrower: MarketAgent,
        *,
        current_block: int,
        prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        securities: SecuritiesMarket,
    ) -> PortfolioLoan:
        loan = self.loans[loan_id]
        if loan.status != 'active':
            return loan
        due = loan.amount_due(current_block)
        cash_paid = min(borrower.cash_usdc, due)
        if cash_paid > 0:
            borrower.cash_usdc -= cash_paid
            self.reserve_usdc += cash_paid
            loan.amount_repaid_usdc += cash_paid
        remaining = due - cash_paid
        recovered = D('0')
        if remaining > 0:
            x, remaining = self._seize_base_assets(borrower, prices, remaining)
            recovered += x
        if remaining > 0:
            x, remaining = self._seize_internal_tokens(borrower, D(rubx_price), D(rubz_price), remaining)
            recovered += x
        if remaining > 0:
            x, remaining = self._seize_equity(borrower, securities, prices, remaining)
            recovered += x
        loan.collateral_recovered_usdc += recovered
        loan.bad_debt_usdc = max(D('0'), due - cash_paid - recovered)
        if loan.bad_debt_usdc > 0:
            loan.status = 'defaulted'
            self.total_bad_debt_usdc += loan.bad_debt_usdc
        else:
            loan.status = 'liquidated'
        self.total_liquidations += 1
        return loan

    def facility_real_wealth(self, prices: dict[str, Decimal]) -> Decimal:
        return self.reserve_usdc + sum(qty * D(prices[s]) for s, qty in self.seized_assets.items() if s in prices)

    def outstanding_principal(self) -> Decimal:
        return sum((l.principal for l in self.loans.values() if l.status == 'active'), D('0'))

    def utilization(self) -> Decimal:
        outstanding = self.outstanding_principal()
        denominator = self.reserve_usdc + outstanding
        if denominator <= 0:
            return D('0')
        return outstanding / denominator

    def bad_debt_ratio(self) -> Decimal:
        if self.total_originated_usdc <= 0:
            return D('0')
        return self.total_bad_debt_usdc / self.total_originated_usdc
