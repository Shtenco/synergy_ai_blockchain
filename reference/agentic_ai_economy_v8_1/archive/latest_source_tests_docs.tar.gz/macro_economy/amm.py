from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


D = Decimal


@dataclass(frozen=True)
class SwapResult:
    amount_in: Decimal
    amount_out: Decimal
    fee_amount: Decimal
    direction: str


class CPMMPool:
    """Simple constant-product AMM with fee retained in reserves."""

    def __init__(self, token_a: str, token_b: str, reserve_a: Decimal, reserve_b: Decimal, fee_bps: int = 30):
        self.token_a = token_a
        self.token_b = token_b
        self.reserve_a = D(reserve_a)
        self.reserve_b = D(reserve_b)
        self.fee_bps = int(fee_bps)
        if self.reserve_a <= 0 or self.reserve_b <= 0:
            raise ValueError("reserves must be positive")
        if not 0 <= self.fee_bps < 10_000:
            raise ValueError("invalid fee_bps")

    @property
    def k(self) -> Decimal:
        return self.reserve_a * self.reserve_b

    @property
    def price_a_in_b(self) -> Decimal:
        return self.reserve_b / self.reserve_a

    def marked_value(self, price_a_in_b: Decimal) -> Decimal:
        return self.reserve_b + self.reserve_a * D(price_a_in_b)

    def _effective(self, amount: Decimal) -> tuple[Decimal, Decimal]:
        amount = D(amount)
        if amount <= 0:
            raise ValueError("swap amount must be positive")
        fee = amount * D(self.fee_bps) / D(10_000)
        return amount - fee, fee


    def quote_b_for_a(self, amount_b: Decimal) -> Decimal:
        amount_b = D(amount_b)
        effective, _ = self._effective(amount_b)
        return self.reserve_a - (self.k / (self.reserve_b + effective))

    def quote_a_for_b(self, amount_a: Decimal) -> Decimal:
        amount_a = D(amount_a)
        effective, _ = self._effective(amount_a)
        return self.reserve_b - (self.k / (self.reserve_a + effective))

    def swap_b_for_a(self, amount_b: Decimal) -> SwapResult:
        amount_b = D(amount_b)
        effective, fee = self._effective(amount_b)
        k0 = self.k
        new_b_effective = self.reserve_b + effective
        new_a = k0 / new_b_effective
        out = self.reserve_a - new_a
        if out <= 0 or out >= self.reserve_a:
            raise ValueError("invalid swap")
        self.reserve_b += amount_b
        self.reserve_a -= out
        return SwapResult(amount_b, out, fee, f"{self.token_b}->{self.token_a}")

    def swap_a_for_b(self, amount_a: Decimal) -> SwapResult:
        amount_a = D(amount_a)
        effective, fee = self._effective(amount_a)
        k0 = self.k
        new_a_effective = self.reserve_a + effective
        new_b = k0 / new_a_effective
        out = self.reserve_b - new_b
        if out <= 0 or out >= self.reserve_b:
            raise ValueError("invalid swap")
        self.reserve_a += amount_a
        self.reserve_b -= out
        return SwapResult(amount_a, out, fee, f"{self.token_a}->{self.token_b}")
