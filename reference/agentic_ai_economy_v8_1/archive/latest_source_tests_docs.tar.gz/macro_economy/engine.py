from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from decimal import Decimal
import random
from typing import Any

from .agents import MarketAgent
from .assets import ReferenceMarket, default_base_assets
from .capital_markets import CapitalMarketsEngine
from .markets import ProtocolMarkets
from .triangle import TriangleEconomy

D = Decimal
Q = D("0.000000000001")


def q(value: Decimal) -> Decimal:
    return D(value).quantize(Q)


@dataclass(frozen=True)
class MacroConfig:
    blocks: int = 500
    block_seconds: int = 12
    seed: int = 77
    agent_count: int = 24
    initial_agent_cash: Decimal = D("50")
    base_usdc_per_pool: Decimal = D("250")
    base_treasury_usdc: Decimal = D("500")
    noise_trades_per_block: int = 2
    informed_deviation_bps: Decimal = D("30")
    founder_fee_share_bps_of_notional: Decimal = D("5")
    agent_external_fee_bps: int = 10
    credit_reserve_usdc: Decimal = D("150")
    company_count: int = 4
    portfolio_rebalance_interval: int = 12
    reference_vol_multiplier: Decimal = D("1")
    credit_principal_fraction: Decimal = D("0.25")
    credit_max_loan_usdc: Decimal = D("5")
    credit_max_capacity_fraction: Decimal = D("0.90")
    capital_scale: Decimal = D("1")

    def __post_init__(self) -> None:
        if self.blocks <= 0 or self.block_seconds <= 0:
            raise ValueError("blocks and block_seconds must be positive")
        if self.agent_count <= 0 or self.initial_agent_cash <= 0:
            raise ValueError("agent configuration must be positive")
        if self.credit_reserve_usdc < 0 or self.company_count < 0 or self.portfolio_rebalance_interval <= 0:
            raise ValueError("capital-markets configuration is invalid")
        if self.reference_vol_multiplier <= 0 or self.credit_principal_fraction <= 0 or self.credit_max_loan_usdc <= 0:
            raise ValueError("stress/credit configuration must be positive")
        if not D("0") < self.credit_max_capacity_fraction <= D("1.2"):
            raise ValueError("credit_max_capacity_fraction must be in (0, 1.2]")
        if self.capital_scale <= 0:
            raise ValueError("capital_scale must be positive")


@dataclass(frozen=True)
class MacroReport:
    blocks: int
    block_seconds: int
    elapsed_seconds: int
    opening_protocol_hard_nav: Decimal
    closing_protocol_hard_nav: Decimal
    opening_system_real_wealth: Decimal
    closing_system_real_wealth: Decimal
    net_external_capital_flow: Decimal
    capital_adjusted_closing_wealth: Decimal
    closing_hodl_benchmark: Decimal
    system_alpha_vs_hodl: Decimal
    raw_wealth_change: Decimal
    capital_adjusted_wealth_change: Decimal
    founder_treasury_usdc: Decimal
    founder_external_revenue: Decimal
    external_fee_value_usdc: Decimal
    base_external_trade_pnl_usdc: Decimal
    base_external_volume_usdc: Decimal
    triangle_external_volume_usdc: Decimal
    agent_external_fees_usdc: Decimal
    rubx_start_price: Decimal
    rubx_end_price: Decimal
    rubz_start_price: Decimal
    rubz_end_price: Decimal
    rubz_end_fair_value: Decimal
    rubx_start_coverage: Decimal
    rubx_end_coverage: Decimal
    max_adjusted_drawdown_pct: Decimal
    controller_actions: dict[str, int]
    triangle_arb_actions: dict[str, int]
    volume_by_symbol: dict[str, Decimal]
    final_prices: dict[str, Decimal]
    company_count: int
    yield_curve_start: dict[int, Decimal]
    yield_curve_end: dict[int, Decimal]
    equity_issuance_usdc: Decimal
    bond_issuance_usdc: Decimal
    active_bonds_end: int
    bond_defaults: int
    company_real_wealth_end: Decimal
    equity_market_cap_end: Decimal
    agent_financial_claims_value_end: Decimal
    portfolio_loans_originated: int
    portfolio_debt_end: Decimal
    credit_reserve_end: Decimal
    credit_utilization_end: Decimal
    margin_calls: int
    liquidations: int
    credit_bad_debt_usdc: Decimal
    company_trade_volume_usdc: Decimal
    allocation_by_asset_end: dict[str, Decimal]
    portfolio_turnover_usdc: Decimal
    snapshots: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        def cv(v: Any) -> Any:
            if isinstance(v, Decimal):
                return str(v)
            if isinstance(v, dict):
                return {k: cv(x) for k, x in v.items()}
            if isinstance(v, list):
                return [cv(x) for x in v]
            return v
        return cv(asdict(self))


class MacroEconomy:
    """RUBX/RUBZ/USDC macro core plus ten Base internal/external markets."""

    def __init__(self, config: MacroConfig | None = None) -> None:
        self.config = config or MacroConfig()
        base_assets = default_base_assets()
        vol_mult = float(self.config.reference_vol_multiplier)
        self.assets = tuple(replace(a, daily_vol=a.daily_vol * vol_mult) for a in base_assets)
        self.rng = random.Random(self.config.seed + 101)
        self.reference = ReferenceMarket(self.assets, seed=self.config.seed, block_seconds=self.config.block_seconds)
        self.prices = {s: D(str(p)) for s, p in self.reference.prices.items()}
        self.prev_prices = dict(self.prices)
        self.triangle = TriangleEconomy.default(scale=self.config.capital_scale)
        self.markets = ProtocolMarkets(
            self.assets,
            usdc_per_pool=self.config.base_usdc_per_pool * self.config.capital_scale,
            treasury_usdc=self.config.base_treasury_usdc * self.config.capital_scale,
        )
        self.agents = self._make_agents()
        self.capital = CapitalMarketsEngine(
            agents=self.agents,
            triangle=self.triangle,
            markets=self.markets,
            seed=self.config.seed,
            block_seconds=self.config.block_seconds,
            credit_reserve_usdc=self.config.credit_reserve_usdc * self.config.capital_scale,
            company_count=self.config.company_count,
            rebalance_interval=self.config.portfolio_rebalance_interval,
            credit_principal_fraction=self.config.credit_principal_fraction,
            credit_max_loan_usdc=self.config.credit_max_loan_usdc * self.config.capital_scale,
            capital_scale=self.config.capital_scale,
            credit_max_capacity_fraction=self.config.credit_max_capacity_fraction,
        )
        self.founder_usdc = D("0")
        self.founder_external_revenue = D("0")
        self.triangle_external_fee_value = D("0")
        self.triangle_external_volume = D("0")
        self.net_external_capital_flow = D("0")
        self.agent_external_fees = D("0")
        self.outside_rubx = D("0")
        self.outside_rubz = D("0")
        self.controller_actions: dict[str, int] = {}
        self.triangle_arb_actions: dict[str, int] = {}
        self.snapshots: list[dict[str, Any]] = []

        self._opening_cash, self._opening_asset_qty = self._capture_opening_real_inventory()
        self.opening_system_real_wealth = self.system_real_wealth()
        self.opening_protocol_hard_nav = self.protocol_hard_nav()
        self.rubx_start_price = q(self.triangle.rubx_price())
        self.rubz_start_price = q(self.triangle.rubz_price())
        self.rubx_start_coverage = q(self.triangle.coverage_ratio())

    def _make_agents(self) -> list[MarketAgent]:
        agents = []
        for i in range(self.config.agent_count):
            risk = self.rng.uniform(0.15, 0.95)
            trend = self.rng.uniform(-0.35, 1.0)
            mean_reversion = self.rng.uniform(0.0, 1.0)
            agents.append(
                MarketAgent(
                    f"macro-agent:{i+1}",
                    D(self.config.initial_agent_cash) * self.config.capital_scale,
                    risk=risk,
                    trend=trend,
                    mean_reversion=mean_reversion,
                )
            )
        return agents

    def _capture_opening_real_inventory(self) -> tuple[Decimal, dict[str, Decimal]]:
        cash = self.triangle.hard_nav() + self.markets.treasury_usdc
        cash += sum(pool.reserve_b for pool in self.markets.pools.values())
        cash += sum(a.cash_usdc for a in self.agents)
        cash += self.capital.credit.reserve_usdc
        cash += sum(c.cash_usdc for c in self.capital.securities.companies.values())
        qty = {}
        for symbol, pool in self.markets.pools.items():
            qty[symbol] = pool.reserve_a + self.markets.treasury_assets[symbol]
        for agent in self.agents:
            for symbol, amount in agent.holdings.items():
                qty[symbol] = qty.get(symbol, D("0")) + amount
        for company in self.capital.securities.companies.values():
            for symbol, amount in company.holdings.items():
                qty[symbol] = qty.get(symbol, D("0")) + amount
        for symbol, amount in self.capital.credit.seized_assets.items():
            qty[symbol] = qty.get(symbol, D("0")) + amount
        return q(cash), qty

    def protocol_hard_nav(self) -> Decimal:
        return q(
            self.triangle.hard_nav()
            + self.markets.hard_nav(self.prices)
            + self.capital.protocol_credit_real_wealth(self.prices)
        )

    def company_real_wealth(self) -> Decimal:
        return self.capital.company_real_wealth(self.prices)

    def agent_real_wealth(self) -> Decimal:
        return q(sum((a.real_wealth(self.prices) for a in self.agents), D("0")))

    def agent_gross_wealth(self) -> Decimal:
        liquid = sum((a.gross_wealth(self.prices, self.triangle.rubx_price(), self.triangle.rubz_price()) for a in self.agents), D("0"))
        return q(liquid + self.capital.agent_financial_claims_value(self.prices))

    def system_real_wealth(self) -> Decimal:
        return q(self.protocol_hard_nav() + self.agent_real_wealth() + self.company_real_wealth() + self.founder_usdc)

    def hodl_benchmark(self) -> Decimal:
        total = self._opening_cash
        for symbol, qty in self._opening_asset_qty.items():
            total += qty * self.prices[symbol]
        return q(total)

    def _pay_founder_from_base(self, amount: Decimal) -> Decimal:
        pay = min(D(amount), self.markets.treasury_usdc)
        if pay <= 0:
            return D("0")
        self.markets.treasury_usdc -= pay
        self.founder_usdc += pay
        self.founder_external_revenue += pay
        return pay

    def _pay_founder_from_triangle(self, amount: Decimal) -> Decimal:
        available = max(D("0"), self.triangle.treasury_usdc - self.triangle.reserve_floor_usdc)
        pay = min(D(amount), available)
        if pay <= 0:
            return D("0")
        self.triangle.treasury_usdc -= pay
        self.founder_usdc += pay
        self.founder_external_revenue += pay
        return pay

    def _founder_share_from_fee(self, fee_value: Decimal) -> Decimal:
        # pools charge 30 bps; founder receives 5 bps of notional = 1/6 of fee value
        return D(fee_value) * self.config.founder_fee_share_bps_of_notional / D("30")

    def _base_external_trade(self, symbol: str, side: str, notional: Decimal) -> None:
        price = self.prices[symbol]
        pool = self.markets.pools[symbol]
        if side == "buy":
            cap = pool.reserve_b * D("0.04")
        else:
            cap = pool.reserve_a * price * D("0.04")
        amount = min(D(notional), cap)
        if amount <= D("0.05"):
            return
        trade = self.markets.external_taker_trade(symbol, side, amount, price)
        self._pay_founder_from_base(self._founder_share_from_fee(trade.fee_value_usdc))

    def _outside_base_flows(self) -> None:
        symbols = list(self.markets.pools)
        for _ in range(self.config.noise_trades_per_block):
            symbol = self.rng.choice(symbols)
            side = "buy" if self.rng.random() < 0.5 else "sell"
            notional = D(str(round(self.rng.uniform(1.0, 6.0), 6))) * self.config.capital_scale
            self._base_external_trade(symbol, side, notional)

        # informed flow/LVR: arbitrageurs trade toward the external reference
        for symbol in symbols:
            dev = self.markets.deviation_bps(symbol, self.prices[symbol])
            if abs(dev) < self.config.informed_deviation_bps:
                continue
            side = "buy" if dev < 0 else "sell"
            notional = self.markets.arbitrage_notional(symbol, self.prices[symbol])
            self._base_external_trade(symbol, side, notional)

    def _outside_triangle_flow(self) -> None:
        if self.rng.random() > 0.32:
            return
        token = "RUBX" if self.rng.random() < 0.5 else "RUBZ"
        if token == "RUBX":
            pool = self.triangle.xu
            market_price = self.triangle.rubx_price()
            fair = self.triangle.rubx_face_value
            outside = self.outside_rubx
        else:
            pool = self.triangle.zu
            market_price = self.triangle.rubz_price()
            fair = max(D("0.05"), self.triangle.rubz_fair_value())
            outside = self.outside_rubz

        mispricing = float((fair / max(D("0.000001"), market_price)) - D("1"))
        buy_prob = max(0.20, min(0.80, 0.50 + 2.5 * mispricing))
        buy = outside <= 0 or self.rng.random() < buy_prob
        notional = D(str(round(self.rng.uniform(0.5, 3.0), 6))) * self.config.capital_scale

        if buy:
            notional = min(notional, pool.reserve_b * D("0.025"))
            if notional <= D("0.05") * self.config.capital_scale:
                return
            swap = pool.swap_b_for_a(notional)
            if token == "RUBX":
                self.outside_rubx += swap.amount_out
            else:
                self.outside_rubz += swap.amount_out
            # USDC-in fee is earned value; the rest is external capital subscription.
            real_fee = swap.fee_amount
            self.triangle_external_fee_value += real_fee
            self.net_external_capital_flow += notional - real_fee
            self.triangle_external_volume += notional
            self._pay_founder_from_triangle(self._founder_share_from_fee(real_fee))
        else:
            token_amount = min(outside * D(str(round(self.rng.uniform(0.05, 0.20), 6))), notional / max(market_price, D("0.000001")))
            if token_amount <= 0:
                return
            swap = pool.swap_a_for_b(token_amount)
            if token == "RUBX":
                self.outside_rubx -= token_amount
            else:
                self.outside_rubz -= token_amount
            # Redemption/buyback is capital leaving the system, not an expense/loss.
            self.net_external_capital_flow -= swap.amount_out
            self.triangle_external_volume += swap.amount_out

    def _agent_base_action(self, agent: MarketAgent) -> None:
        if self.rng.random() > 0.055:
            return
        symbol = self.rng.choice(list(self.markets.pools))
        p = self.prices[symbol]
        p0 = self.prev_prices[symbol]
        ret = float(p / p0 - D("1"))
        dev = float(self.markets.internal_price(symbol) / p - D("1"))
        signal = agent.trend * ret * 900.0 - agent.mean_reversion * dev * 80.0 + self.rng.gauss(0, 0.12) * agent.risk
        held = agent.holdings.get(symbol, D("0"))

        if signal > 0.08 and agent.cash_usdc > D("2") * self.config.capital_scale:
            amount = min(agent.cash_usdc * D("0.025"), D(str(round(0.5 + 2.5 * agent.risk, 6))) * self.config.capital_scale)
            if amount <= D("0.10") * self.config.capital_scale:
                return
            if self.markets.internal_price(symbol) < p * D("0.9985"):
                agent.buy_internal(self.markets, symbol, amount)
            else:
                try:
                    self.agent_external_fees += agent.buy_external(symbol, amount, p, fee_bps=self.config.agent_external_fee_bps)
                except ValueError:
                    pass
        elif signal < -0.08 and held > 0:
            amount_token = held * D(str(round(0.08 + 0.18 * agent.risk, 6)))
            if amount_token <= 0:
                return
            if self.markets.internal_price(symbol) > p * D("1.0015"):
                agent.sell_internal(self.markets, symbol, amount_token)
            else:
                try:
                    self.agent_external_fees += agent.sell_external(symbol, amount_token, p, fee_bps=self.config.agent_external_fee_bps)
                except ValueError:
                    pass

    def _agent_triangle_action(self) -> None:
        if self.rng.random() > 0.18:
            return
        agent = self.rng.choice(self.agents)
        token = "RUBX" if self.rng.random() < 0.55 else "RUBZ"
        if token == "RUBX":
            pool = self.triangle.xu
            price = self.triangle.rubx_price()
            fair = self.triangle.rubx_face_value
            held = agent.rubx
        else:
            pool = self.triangle.zu
            price = self.triangle.rubz_price()
            fair = max(D("0.05"), self.triangle.rubz_fair_value())
            held = agent.rubz

        value_gap = price / fair - D("1")
        if value_gap < D("-0.01") and agent.cash_usdc > D("1") * self.config.capital_scale:
            spend = min(D("1.5") * self.config.capital_scale, agent.cash_usdc * D("0.02"))
            if spend > D("0.05") * self.config.capital_scale:
                swap = pool.swap_b_for_a(spend)
                agent.cash_usdc -= spend
                if token == "RUBX":
                    agent.rubx += swap.amount_out
                else:
                    agent.rubz += swap.amount_out
        elif held > 0 and (value_gap > D("0.015") or self.rng.random() < 0.03):
            sell = held * D("0.15")
            swap = pool.swap_a_for_b(sell)
            agent.cash_usdc += swap.amount_out
            if token == "RUBX":
                agent.rubx -= sell
            else:
                agent.rubz -= sell

    def _controller(self) -> None:
        action = str(self.triangle.controller_step()["action"])
        self.controller_actions[action] = self.controller_actions.get(action, 0) + 1
        arb = self.triangle.triangular_arbitrage(D("2") * self.config.capital_scale)
        arb_action = str(arb["action"])
        self.triangle_arb_actions[arb_action] = self.triangle_arb_actions.get(arb_action, 0) + 1

    def _snapshot(self, block: int) -> dict[str, Any]:
        real = self.system_real_wealth()
        adjusted = q(real - self.net_external_capital_flow)
        hodl = self.hodl_benchmark()
        deviations = [abs(self.markets.deviation_bps(s, self.prices[s])) for s in self.markets.pools]
        protocol_hard = self.protocol_hard_nav()
        base_tvl = sum((pool.marked_value(self.prices[s]) for s, pool in self.markets.pools.items()), D("0"))
        allocation = self.capital.allocation_snapshot(self.prices)
        curve = self.capital.yield_curve.rates
        company_real = self.company_real_wealth()
        return {
            "block": block,
            "time_seconds": block * self.config.block_seconds,
            "protocol_hard_nav": float(protocol_hard),
            "agent_real_wealth": float(self.agent_real_wealth()),
            "agent_gross_wealth": float(self.agent_gross_wealth()),
            "founder_usdc": float(q(self.founder_usdc)),
            "system_real_wealth": float(real),
            "capital_adjusted_wealth": float(adjusted),
            "hodl_benchmark": float(hodl),
            "alpha_vs_hodl": float(q(adjusted - hodl)),
            "gross_tvl": float(q(self.triangle.gross_tvl() + base_tvl)),
            "triangle_hard_nav": float(q(self.triangle.hard_nav())),
            "rubx_price": float(q(self.triangle.rubx_price())),
            "rubz_price": float(q(self.triangle.rubz_price())),
            "rubz_fair_value": float(q(self.triangle.rubz_fair_value())),
            "rubx_coverage": float(q(self.triangle.coverage_ratio())),
            "rubx_supply": float(q(self.triangle.rubx_supply)),
            "rubz_supply": float(q(self.triangle.rubz_supply)),
            "net_external_capital_flow": float(q(self.net_external_capital_flow)),
            "external_fee_value": float(q(self.markets.external_fee_value_usdc + self.triangle_external_fee_value)),
            "founder_external_revenue": float(q(self.founder_external_revenue)),
            "base_external_volume": float(q(self.markets.external_volume_usdc)),
            "triangle_external_volume": float(q(self.triangle_external_volume)),
            "agent_external_fees": float(q(self.agent_external_fees)),
            "mean_abs_deviation_bps": float(q(sum(deviations, D("0")) / D(len(deviations)))),
            "max_abs_deviation_bps": float(q(max(deviations))),
            "yield_1d": float(q(curve[1])),
            "yield_7d": float(q(curve[7])),
            "yield_30d": float(q(curve[30])),
            "yield_90d": float(q(curve[90])),
            "yield_365d": float(q(curve[365])),
            "credit_utilization": float(q(self.capital.credit.utilization())),
            "credit_reserve_usdc": float(q(self.capital.credit.reserve_usdc)),
            "company_real_wealth": float(q(company_real)),
            "equity_market_cap": float(q(self.capital.securities.equity_market_cap(self.prices))),
            "outstanding_bond_face": float(q(self.capital.outstanding_bond_face())),
            "portfolio_debt": float(q(self.capital.portfolio_debt(block))),
            "portfolio_margin_calls": self.capital.credit.total_margin_calls,
            "portfolio_liquidations": self.capital.credit.total_liquidations,
            "credit_bad_debt_usdc": float(q(self.capital.credit.total_bad_debt_usdc)),
            "agent_financial_claims_value": float(q(self.capital.agent_financial_claims_value(self.prices, block))),
            "equity_issuance_usdc": float(q(self.capital.securities.total_equity_issuance_usdc)),
            "bond_issuance_usdc": float(q(self.capital.securities.total_bond_issuance_usdc)),
            "company_trade_volume_usdc": float(q(self.capital.company_trade_volume_usdc)),
            "allocation": {k: float(q(v)) for k, v in allocation.items()},
            "prices": {s: float(q(p)) for s, p in self.prices.items()},
        }

    def run(self) -> MacroReport:
        peak_adjusted = self.opening_system_real_wealth
        max_drawdown = D("0")
        for block in range(1, self.config.blocks + 1):
            self.prev_prices = dict(self.prices)
            stepped = self.reference.step()
            self.prices = {s: D(str(p)) for s, p in stepped.items()}

            self._outside_base_flows()
            self._outside_triangle_flow()
            for agent in self.agents:
                self._agent_base_action(agent)
            self._agent_triangle_action()
            self.capital.step(block=block, prices=self.prices, prev_prices=self.prev_prices)
            self._controller()

            snap = self._snapshot(block)
            self.snapshots.append(snap)
            adjusted = D(str(snap["capital_adjusted_wealth"]))
            if adjusted > peak_adjusted:
                peak_adjusted = adjusted
            if peak_adjusted > 0:
                dd = (peak_adjusted - adjusted) / peak_adjusted * D("100")
                max_drawdown = max(max_drawdown, dd)

        closing = self.system_real_wealth()
        adjusted_closing = q(closing - self.net_external_capital_flow)
        hodl = self.hodl_benchmark()
        protocol_closing = self.protocol_hard_nav()
        return MacroReport(
            blocks=self.config.blocks,
            block_seconds=self.config.block_seconds,
            elapsed_seconds=self.config.blocks * self.config.block_seconds,
            opening_protocol_hard_nav=self.opening_protocol_hard_nav,
            closing_protocol_hard_nav=protocol_closing,
            opening_system_real_wealth=self.opening_system_real_wealth,
            closing_system_real_wealth=closing,
            net_external_capital_flow=q(self.net_external_capital_flow),
            capital_adjusted_closing_wealth=adjusted_closing,
            closing_hodl_benchmark=hodl,
            system_alpha_vs_hodl=q(adjusted_closing - hodl),
            raw_wealth_change=q(closing - self.opening_system_real_wealth),
            capital_adjusted_wealth_change=q(adjusted_closing - self.opening_system_real_wealth),
            founder_treasury_usdc=q(self.founder_usdc),
            founder_external_revenue=q(self.founder_external_revenue),
            external_fee_value_usdc=q(self.markets.external_fee_value_usdc + self.triangle_external_fee_value),
            base_external_trade_pnl_usdc=q(self.markets.external_trade_pnl_usdc),
            base_external_volume_usdc=q(self.markets.external_volume_usdc),
            triangle_external_volume_usdc=q(self.triangle_external_volume),
            agent_external_fees_usdc=q(self.agent_external_fees),
            rubx_start_price=self.rubx_start_price,
            rubx_end_price=q(self.triangle.rubx_price()),
            rubz_start_price=self.rubz_start_price,
            rubz_end_price=q(self.triangle.rubz_price()),
            rubz_end_fair_value=q(self.triangle.rubz_fair_value()),
            rubx_start_coverage=self.rubx_start_coverage,
            rubx_end_coverage=q(self.triangle.coverage_ratio()),
            max_adjusted_drawdown_pct=q(max_drawdown),
            controller_actions=dict(self.controller_actions),
            triangle_arb_actions=dict(self.triangle_arb_actions),
            volume_by_symbol={s: q(v) for s, v in self.markets.volume_by_symbol.items()},
            final_prices={s: q(p) for s, p in self.prices.items()},
            company_count=len(self.capital.securities.companies),
            yield_curve_start={k: q(v) for k, v in self.capital.yield_curve_start.items()},
            yield_curve_end={k: q(v) for k, v in self.capital.yield_curve.rates.items()},
            equity_issuance_usdc=q(self.capital.securities.total_equity_issuance_usdc),
            bond_issuance_usdc=q(self.capital.securities.total_bond_issuance_usdc),
            active_bonds_end=len(self.capital.securities.active_bonds()),
            bond_defaults=sum(1 for b in self.capital.securities.bonds.values() if b.status == "defaulted"),
            company_real_wealth_end=q(self.company_real_wealth()),
            equity_market_cap_end=q(self.capital.securities.equity_market_cap(self.prices)),
            agent_financial_claims_value_end=q(self.capital.agent_financial_claims_value(self.prices, self.config.blocks)),
            portfolio_loans_originated=len(self.capital.credit.loans),
            portfolio_debt_end=q(self.capital.portfolio_debt(self.config.blocks)),
            credit_reserve_end=q(self.capital.credit.reserve_usdc),
            credit_utilization_end=q(self.capital.credit.utilization()),
            margin_calls=self.capital.credit.total_margin_calls,
            liquidations=self.capital.credit.total_liquidations,
            credit_bad_debt_usdc=q(self.capital.credit.total_bad_debt_usdc),
            company_trade_volume_usdc=q(self.capital.company_trade_volume_usdc),
            allocation_by_asset_end={k: q(v) for k, v in self.capital.allocation_snapshot(self.prices).items()},
            portfolio_turnover_usdc=q(sum((a.portfolio_turnover_usdc for a in self.agents), D("0"))),
            snapshots=list(self.snapshots),
        )
