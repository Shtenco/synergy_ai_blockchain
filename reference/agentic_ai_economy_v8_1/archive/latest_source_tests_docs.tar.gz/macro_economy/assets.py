from __future__ import annotations

from dataclasses import dataclass
import math
import random


@dataclass(frozen=True)
class AssetSpec:
    symbol: str
    initial_price: float
    daily_vol: float
    market_beta: float
    stable_anchor: float | None = None


def default_base_assets() -> tuple[AssetSpec, ...]:
    """Representative large/liquid Base universe seeded from 2026-09 observations.

    Volatilities are scenario assumptions, not forecasts. Prices are only the
    starting marks for the deterministic simulation.
    """
    return (
        AssetSpec("WETH", 2403.78, 0.045, 1.00),
        AssetSpec("cbBTC", 76141.13, 0.035, 0.85),
        AssetSpec("VVV", 21.32, 0.120, 1.25),
        AssetSpec("VIRTUAL", 0.585223, 0.090, 1.20),
        AssetSpec("AERO", 0.525202, 0.085, 1.15),
        AssetSpec("cbETH", 2732.23, 0.045, 1.00),
        AssetSpec("USDe", 0.9992, 0.003, 0.05, stable_anchor=1.0),
        AssetSpec("cbXRP", 1.42, 0.055, 0.80),
        AssetSpec("TOSHI", 0.00010725, 0.110, 1.30),
        AssetSpec("MORPHO", 2.08, 0.070, 1.05),
    )


class ReferenceMarket:
    def __init__(self, assets: tuple[AssetSpec, ...], seed: int, block_seconds: int = 12):
        self.assets = assets
        self.rng = random.Random(seed)
        self.block_seconds = int(block_seconds)
        self.prices = {a.symbol: float(a.initial_price) for a in assets}
        self._day_fraction = self.block_seconds / 86_400.0

    def step(self) -> dict[str, float]:
        common = self.rng.gauss(0.0, 1.0)
        for asset in self.assets:
            idio = self.rng.gauss(0.0, 1.0)
            rho = min(0.95, max(0.0, asset.market_beta / 1.5))
            shock = rho * common + math.sqrt(max(0.0, 1.0 - rho * rho)) * idio
            sigma = asset.daily_vol * math.sqrt(self._day_fraction)
            p = self.prices[asset.symbol]
            p *= math.exp(-0.5 * sigma * sigma + sigma * shock)
            if asset.stable_anchor is not None:
                # weak pull to $1 without pretending a hard peg is riskless
                p += (asset.stable_anchor - p) * 0.02
            self.prices[asset.symbol] = max(p, 1e-12)
        return dict(self.prices)
