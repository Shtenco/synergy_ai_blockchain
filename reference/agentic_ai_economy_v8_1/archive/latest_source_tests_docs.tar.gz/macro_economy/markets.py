from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .amm import CPMMPool
from .assets import AssetSpec

D = Decimal
MONEY_Q = D("0.000000000001")


@dataclass(frozen=True)
class ExternalTrade:
    symbol: str
    side: str
    volume_usdc: Decimal
    fee_value_usdc: Decimal
    nav_delta: Decimal


class ProtocolMarkets:
    """Protocol-owned Base asset/USDC AMMs.

    Outside-taker trades cross the system boundary. Internal agent trades use
    the same pools but are transfers within the Synergy economy.
    """

    def __init__(
        self,
        assets: tuple[AssetSpec, ...],
        *,
        usdc_per_pool: Decimal = D("250"),
        treasury_usdc: Decimal = D("500"),
        fee_bps: int = 30,
    ) -> None:
        self.assets = {a.symbol: a for a in assets}
        self.treasury_usdc = D(treasury_usdc)
        self.treasury_assets = {a.symbol: D("0") for a in assets}
        self.pools: dict[str, CPMMPool] = {}
        for asset in assets:
            usdc = D(usdc_per_pool)
            token = usdc / D(str(asset.initial_price))
            self.pools[asset.symbol] = CPMMPool(asset.symbol, "USDC", token, usdc, fee_bps=fee_bps)
        self.external_volume_usdc = D("0")
        self.external_fee_value_usdc = D("0")
        self.external_trade_pnl_usdc = D("0")
        self.volume_by_symbol = {a.symbol: D("0") for a in assets}

    def hard_nav(self, prices: dict[str, Decimal]) -> Decimal:
        total = self.treasury_usdc
        for symbol, amount in self.treasury_assets.items():
            total += amount * D(prices[symbol])
        for symbol, pool in self.pools.items():
            total += pool.marked_value(D(prices[symbol]))
        return total.quantize(MONEY_Q)

    def internal_price(self, symbol: str) -> Decimal:
        return self.pools[symbol].price_a_in_b

    def deviation_bps(self, symbol: str, external_price: Decimal) -> Decimal:
        ext = D(external_price)
        return (self.internal_price(symbol) / ext - D("1")) * D("10000")

    def arbitrage_notional(self, symbol: str, external_price: Decimal) -> Decimal:
        """Approximate fee-aware notional that moves CPMM spot to the external mark."""
        pool = self.pools[symbol]
        target = D(external_price)
        if target <= 0:
            raise ValueError("external price must be positive")
        fee_factor = D("1") - D(pool.fee_bps) / D("10000")
        internal = pool.price_a_in_b
        if internal < target:
            target_b = (pool.k * target).sqrt()
            effective_b = max(D("0"), target_b - pool.reserve_b)
            return (effective_b / fee_factor).quantize(MONEY_Q)
        if internal > target:
            target_a = (pool.k / target).sqrt()
            effective_a = max(D("0"), target_a - pool.reserve_a)
            token_in = effective_a / fee_factor
            return (token_in * target).quantize(MONEY_Q)
        return D("0")

    def external_taker_trade(
        self,
        symbol: str,
        side: str,
        notional_usdc: Decimal,
        external_price: Decimal,
    ) -> ExternalTrade:
        pool = self.pools[symbol]
        notional = D(notional_usdc)
        price = D(external_price)
        if notional <= 0:
            raise ValueError("notional must be positive")
        before = pool.marked_value(price)
        if side == "buy":
            swap = pool.swap_b_for_a(notional)
            fee_value = swap.fee_amount
        elif side == "sell":
            token_in = notional / price
            swap = pool.swap_a_for_b(token_in)
            fee_value = swap.fee_amount * price
        else:
            raise ValueError("side must be buy or sell")
        after = pool.marked_value(price)
        nav_delta = (after - before).quantize(MONEY_Q)
        self.external_volume_usdc += notional
        self.external_fee_value_usdc += fee_value
        self.external_trade_pnl_usdc += nav_delta
        self.volume_by_symbol[symbol] += notional
        return ExternalTrade(symbol, side, notional, fee_value, nav_delta)
