from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import IntEnum

D = Decimal
Q = D('0.000000000001')


def q(x: Decimal) -> Decimal:
    return D(x).quantize(Q)


class CollateralTier(IntEnum):
    T0 = 0  # USDC / real Base
    T1 = 1  # RUBX
    T2 = 2  # RUBZ
    T3 = 3  # agent bonds / equities
    T4 = 4  # recursive structured collateral


@dataclass(frozen=True)
class BankingMetrics:
    hard_nav: Decimal
    collateral_nav: Decimal
    gross_tvl: Decimal
    ccr: Decimal
    lcr: Decimal
    allowed_depth: int
    haircuts: dict[CollateralTier, Decimal]
    secured_liabilities: Decimal
    internal_claims: Decimal


class BankingRiskEngine:
    """Internal SYNERGY banking-risk layer.

    CCR/LCR are system-specific control ratios, not regulatory Basel metrics.
    Claims never enter HardNAV. They can increase CollateralNAV after haircuts
    and GrossTVL after rehypothecation.
    """

    BASE_HAIRCUTS = {
        CollateralTier.T0: D('0.01'),
        CollateralTier.T1: D('0.08'),
        CollateralTier.T2: D('0.16'),
        CollateralTier.T3: D('0.28'),
        CollateralTier.T4: D('0.45'),
    }

    def haircuts(
        self,
        *,
        volatility: Decimal,
        leverage: Decimal,
        liquidity_stress: Decimal,
    ) -> dict[CollateralTier, Decimal]:
        vol = max(D('0'), D(volatility))
        lev = max(D('1'), D(leverage))
        liq = max(D('0'), D(liquidity_stress))
        common = vol * D('1.30') + (lev - D('1')) * D('0.045') + liq * D('0.10')
        out: dict[CollateralTier, Decimal] = {}
        for tier in CollateralTier:
            tier_extra = D(tier) * (vol * D('0.22') + liq * D('0.025'))
            out[tier] = q(min(D('0.95'), self.BASE_HAIRCUTS[tier] + common + tier_extra))
        # preserve strict ordering even under caps
        eps = D('0.0001')
        for tier in (CollateralTier.T1, CollateralTier.T2, CollateralTier.T3, CollateralTier.T4):
            prev = out[CollateralTier(tier - 1)]
            out[tier] = min(D('0.95'), max(out[tier], prev + eps))
        return out

    def metrics(
        self,
        *,
        hard_nav: Decimal,
        liquid_assets: Decimal,
        secured_liabilities: Decimal,
        internal_claims: Decimal,
        volatility: Decimal,
        leverage: Decimal,
        liquidity_stress: Decimal,
    ) -> BankingMetrics:
        hard = max(D('0'), D(hard_nav))
        liquid = max(D('0'), D(liquid_assets))
        liabilities = max(D('0'), D(secured_liabilities))
        claims = max(D('0'), D(internal_claims))
        h = self.haircuts(volatility=D(volatility), leverage=D(leverage), liquidity_stress=D(liquidity_stress))

        # Representative claim mix across T1..T4. De-duplicated for CollateralNAV.
        mix = {
            CollateralTier.T1: D('0.20'),
            CollateralTier.T2: D('0.20'),
            CollateralTier.T3: D('0.30'),
            CollateralTier.T4: D('0.30'),
        }
        eligible_claims = sum((claims * weight * (D('1') - h[tier]) for tier, weight in mix.items()), D('0'))
        collateral_nav = q(hard + eligible_claims)

        # GrossTVL intentionally counts rehypothecation activity. It is not wealth.
        rehyp_mult = min(D('4'), D('1') + max(D('0'), D(leverage) - D('1')) * D('0.70') + D(liquidity_stress) * D('0.40'))
        gross_tvl = q(hard + claims * rehyp_mult)

        ccr = q(collateral_nav / max(D('1'), liabilities))
        stressed_outflows = liabilities * D('0.30') + claims * (D('0.05') + max(D('0'), D(liquidity_stress)) * D('0.08'))
        lcr = q(liquid / max(D('1'), stressed_outflows))

        vol = D(volatility)
        lev = D(leverage)
        if ccr >= D('1.75') and lcr >= D('1.50') and vol < D('0.03') and lev < D('2.0'):
            depth = 4
        elif ccr >= D('1.35') and lcr >= D('1.10') and vol < D('0.055') and lev < D('2.8'):
            depth = 3
        elif ccr >= D('1.05') and lcr >= D('0.85') and vol < D('0.09'):
            depth = 2
        elif ccr >= D('0.85') and lcr >= D('0.60'):
            depth = 1
        else:
            depth = 0

        return BankingMetrics(
            hard_nav=q(hard),
            collateral_nav=collateral_nav,
            gross_tvl=gross_tvl,
            ccr=ccr,
            lcr=lcr,
            allowed_depth=depth,
            haircuts=h,
            secured_liabilities=q(liabilities),
            internal_claims=q(claims),
        )
