from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from decimal import Decimal
import random
from typing import Any

from .amm import CPMMPool
from .engine import MacroConfig, MacroEconomy, q
from synergy_chain import AdaptiveAIMarketMaker, InventoryBridge, ShadowChainLedger, SynergyChain, SynergyChainConfig

D = Decimal
Q = D("0.000000000001")


@dataclass(frozen=True)
class DualContourConfig(MacroConfig):
    bridge_pool_fraction: Decimal = D("0.50")
    max_synthetic_leverage: Decimal = D("4")
    shadow_usdc_per_pool: Decimal = D("70")
    shadow_fee_bps: int = 30
    ai_base_spread_bps: Decimal = D("20")
    ai_band_bps: Decimal = D("3")
    ai_base_delta: Decimal = D("0.18")
    shadow_noise_trades_per_block: int = 3
    external_rebalance_speed: Decimal = D("0.30")
    external_rebalance_band_fraction: Decimal = D("0.012")
    external_execution_fee_bps: Decimal = D("4")
    enable_external_delta_control: bool = True
    enable_shadow_mm: bool = True

    def macro_config(self) -> MacroConfig:
        names = {f.name for f in fields(MacroConfig)}
        return MacroConfig(**{name: getattr(self, name) for name in names})


@dataclass(frozen=True)
class DualContourReport:
    blocks: int
    block_seconds: int
    elapsed_seconds: int
    opening_system_real_wealth: Decimal
    closing_system_real_wealth: Decimal
    net_external_capital_flow: Decimal
    capital_adjusted_closing_wealth: Decimal
    closing_hodl_benchmark: Decimal
    system_alpha_vs_hodl: Decimal
    capital_adjusted_wealth_change: Decimal
    max_adjusted_drawdown_pct: Decimal
    bridge_real_nav_start: Decimal
    bridge_real_nav_end: Decimal
    bridge_external_volume_usdc: Decimal
    external_realized_inventory_pnl_usdc: Decimal
    external_execution_fees_usdc: Decimal
    synthetic_minted_usdc_equivalent: Decimal
    synthetic_burned_usdc_equivalent: Decimal
    synthetic_supply_value_end: Decimal
    internal_synthetic_fee_value_susdc: Decimal
    ai_actions: int
    mint_sell_actions: int
    buy_burn_actions: int
    internal_mean_abs_spread_error_bps: Decimal
    internal_max_abs_spread_error_bps: Decimal
    target_spread_bps_end: Decimal
    bridge_real_asset_share_end: Decimal
    shadow_supply_end: dict[str, Decimal]
    bridge_asset_values_end: dict[str, Decimal]
    chain_height: int
    chain_tip_hash: str
    chain_tx_count: int
    max_synthetic_leverage_observed: Decimal
    snapshots: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        def cv(v: Any) -> Any:
            if isinstance(v, Decimal):
                return str(v)
            if isinstance(v, dict):
                return {str(k): cv(x) for k, x in v.items()}
            if isinstance(v, list):
                return [cv(x) for x in v]
            return v
        return cv(asdict(self))


class DualContourEconomy:
    """v5 two-contour economy: v4 real economy + non-redeemable shadow chain.

    External real inventory is held by InventoryBridge and actively delta-managed.
    Internal shadow supply can be minted/burned to manage spread but has zero
    direct HardNAV effect by construction.
    """

    def __init__(self, config: DualContourConfig | None = None) -> None:
        self.config = config or DualContourConfig()
        self.core = MacroEconomy(self.config.macro_config())
        self.rng = random.Random(self.config.seed + 50_001)
        self.bridge = InventoryBridge(
            max_synthetic_leverage=self.config.max_synthetic_leverage,
            execution_fee_bps=self.config.external_execution_fee_bps,
        )
        self.mm = AdaptiveAIMarketMaker(
            base_spread_bps=self.config.ai_base_spread_bps,
            band_bps=self.config.ai_band_bps,
            base_delta=self.config.ai_base_delta,
        )
        self.base_symbols = tuple(self.core.markets.pools.keys())
        self.shadow_symbols = ("RUBX", "RUBZ") + self.base_symbols
        assets = ("sUSDC",) + tuple(f"s{s}" for s in self.shadow_symbols)
        self.shadow_ledger = ShadowChainLedger(assets)
        self.chain = SynergyChain(SynergyChainConfig(block_seconds=self.config.block_seconds))
        self._chain_ledger_event_cursor = 0
        self._chain_tx_count = 0
        self.max_synthetic_leverage_observed = D("0")
        self.shadow_pools: dict[str, CPMMPool] = {}
        self.shadow_outside_usdc = D("0")
        self.shadow_outside_assets: dict[str, Decimal] = {}
        self.shadow_prev_marks: dict[str, Decimal] = {}
        self.shadow_momentum: dict[str, Decimal] = {}
        self.risk_budget_usdc: dict[str, Decimal] = {}
        self.ema_price: dict[str, Decimal] = {}
        self.peak_price: dict[str, Decimal] = {}
        self.volatility: dict[str, Decimal] = {}
        self.synthetic_fee_value = D("0")
        self.mint_sell_actions = 0
        self.buy_burn_actions = 0
        self.spread_error_sum = D("0")
        self.spread_error_count = 0
        self.max_spread_error = D("0")
        self.snapshots: list[dict[str, Any]] = []
        self._extract_real_inventory()
        self._seed_shadow_chain()
        self.shadow_prev_marks = {s: p for s, p in self.external_marks().items() if s != "USDC"}
        self.shadow_momentum = {s: D("0") for s in self.shadow_symbols}
        self._seed_minted_value = self._minted_value(self.external_marks())
        self._seed_burned_value = self._burned_value(self.external_marks())
        self.opening_system_real_wealth = self.system_real_wealth()
        self.bridge_real_nav_start = self.bridge.real_nav(self._real_prices())

    def _real_prices(self) -> dict[str, Decimal]:
        return {"USDC": D("1"), **self.core.prices}

    def external_marks(self) -> dict[str, Decimal]:
        return {
            "USDC": D("1"),
            "RUBX": self.core.triangle.rubx_price(),
            "RUBZ": max(D("0.000001"), self.core.triangle.rubz_price()),
            **self.core.prices,
        }

    def _extract_real_inventory(self) -> None:
        frac = D(self.config.bridge_pool_fraction)
        if not D("0") < frac < D("0.6"):
            raise ValueError("bridge_pool_fraction must be in (0, 0.6)")
        for symbol, pool in self.core.markets.pools.items():
            asset = pool.reserve_a * frac
            cash = pool.reserve_b * frac
            pool.reserve_a -= asset
            pool.reserve_b -= cash
            price = self.core.prices[symbol]
            self.bridge.deposit_real(symbol, asset, price, source="protocol-pool-inventory")
            self.bridge.deposit_real("USDC", cash, D("1"), source="protocol-pool-cash")
            self.risk_budget_usdc[symbol] = q(asset * price + cash)
            self.ema_price[symbol] = price
            self.peak_price[symbol] = price
            self.volatility[symbol] = D("0")

    def _seed_shadow_chain(self) -> None:
        marks = self.external_marks()
        per = D(self.config.shadow_usdc_per_pool) * self.config.capital_scale
        for symbol in self.shadow_symbols:
            target = marks[symbol] * (D("1") + self.config.ai_base_spread_bps / D("10000"))
            asset_reserve = per / target
            self.shadow_ledger.mint("sUSDC", per, reason="genesis-pool")
            self.shadow_ledger.mint(f"s{symbol}", asset_reserve, reason="genesis-pool")
            self.shadow_pools[symbol] = CPMMPool(f"s{symbol}", "sUSDC", asset_reserve, per, fee_bps=self.config.shadow_fee_bps)
            outside_asset = asset_reserve * D("0.20")
            self.shadow_ledger.mint(f"s{symbol}", outside_asset, reason="genesis-float")
            self.shadow_outside_assets[symbol] = outside_asset
        self.shadow_outside_usdc = per * D(len(self.shadow_symbols)) * D("0.35")
        self.shadow_ledger.mint("sUSDC", self.shadow_outside_usdc, reason="genesis-float")
        total_pool_tvl = per * D("2") * D(len(self.shadow_symbols))
        float_value = self.shadow_outside_usdc + per * D("0.20") * D(len(self.shadow_symbols))
        self.bridge.reserve_synthetic_value(total_pool_tvl + float_value, self._real_prices())

    def system_real_wealth(self) -> Decimal:
        return q(self.core.system_real_wealth() + self.bridge.real_nav(self._real_prices()))

    def protocol_hard_nav(self) -> Decimal:
        return q(self.core.protocol_hard_nav() + self.bridge.real_nav(self._real_prices()))

    def hodl_benchmark(self) -> Decimal:
        # core captured the pre-extraction real inventory, which is exactly the
        # combined core+bridge opening inventory after proportional transfer.
        return self.core.hodl_benchmark()

    def _minted_value(self, marks: dict[str, Decimal]) -> Decimal:
        total = self.shadow_ledger.total_minted("sUSDC")
        for s in self.shadow_symbols:
            total += self.shadow_ledger.total_minted(f"s{s}") * marks[s]
        return q(total)

    def _burned_value(self, marks: dict[str, Decimal]) -> Decimal:
        total = self.shadow_ledger.total_burned("sUSDC")
        for s in self.shadow_symbols:
            total += self.shadow_ledger.total_burned(f"s{s}") * marks[s]
        return q(total)

    def synthetic_supply_value(self, marks: dict[str, Decimal] | None = None) -> Decimal:
        marks = marks or self.external_marks()
        total = self.shadow_ledger.supply("sUSDC")
        for s in self.shadow_symbols:
            total += self.shadow_ledger.supply(f"s{s}") * marks[s]
        return q(total)

    def _shadow_noise_flow(self) -> None:
        for _ in range(self.config.shadow_noise_trades_per_block):
            symbol = self.rng.choice(self.shadow_symbols)
            pool = self.shadow_pools[symbol]
            if self.rng.random() < 0.5 and self.shadow_outside_usdc > D("0.10"):
                amount = min(self.shadow_outside_usdc * D("0.025"), D(str(self.rng.uniform(0.15, 1.2))) * self.config.capital_scale)
                if amount <= D("0.01"):
                    continue
                swap = pool.swap_b_for_a(amount)
                self.shadow_outside_usdc -= amount
                self.shadow_outside_assets[symbol] += swap.amount_out
                self.synthetic_fee_value += swap.fee_amount
            else:
                held = self.shadow_outside_assets[symbol]
                if held <= 0:
                    continue
                value = held * self.external_marks()[symbol]
                sell_value = min(value * D("0.04"), D(str(self.rng.uniform(0.15, 1.2))) * self.config.capital_scale)
                amount = min(held, sell_value / max(self.external_marks()[symbol], D("0.000001")))
                if amount <= 0:
                    continue
                swap = pool.swap_a_for_b(amount)
                self.shadow_outside_assets[symbol] -= amount
                self.shadow_outside_usdc += swap.amount_out
                self.synthetic_fee_value += swap.fee_amount * self.external_marks()[symbol]

    def _state(self, symbol: str, price: Decimal, prev_price: Decimal) -> tuple[Decimal, Decimal, Decimal]:
        ret = price / prev_price - D("1") if prev_price > 0 else D("0")
        vol = self.volatility[symbol] * D("0.94") + abs(ret) * D("0.06")
        self.volatility[symbol] = vol
        ema = self.ema_price[symbol] * D("0.97") + price * D("0.03")
        self.ema_price[symbol] = ema
        self.peak_price[symbol] = max(self.peak_price[symbol], price)
        momentum = price / ema - D("1") if ema > 0 else D("0")
        drawdown = max(D("0"), D("1") - price / self.peak_price[symbol])
        return momentum, drawdown, vol

    def _external_delta_control(self) -> None:
        for symbol in self.base_symbols:
            price = self.core.prices[symbol]
            prev = self.core.prev_prices[symbol]
            momentum, drawdown, vol = self._state(symbol, price, prev)
            target_delta = self.mm.target_external_delta(momentum=momentum, drawdown=drawdown, volatility=vol)
            budget = self.risk_budget_usdc[symbol]
            target_value = budget * target_delta
            current_qty = self.bridge.real_balances.get(symbol, D("0"))
            current_value = current_qty * price
            gap = current_value - target_value
            band = budget * self.config.external_rebalance_band_fraction
            if abs(gap) <= band:
                continue
            trade_value = abs(gap) * self.config.external_rebalance_speed
            before_pnl = self.bridge.realized_pnl_usdc
            if gap > 0:
                self.bridge.sell_real(symbol, trade_value / price, price)
            else:
                self.bridge.buy_real(symbol, trade_value, price)
            reward = self.bridge.realized_pnl_usdc - before_pnl
            self.mm.observe_reward(reward)

    def _stabilize_shadow(self) -> None:
        marks = self.external_marks()
        for symbol in self.shadow_symbols:
            prev_mark = self.shadow_prev_marks.get(symbol, marks[symbol])
            momentum = marks[symbol] / prev_mark - D("1") if prev_mark > 0 else D("0")
            self.shadow_momentum[symbol] = momentum
            if symbol in self.base_symbols:
                vol = self.volatility[symbol]
                budget = self.risk_budget_usdc[symbol]
                current = self.bridge.real_balances.get(symbol, D("0")) * marks[symbol]
                skew = (current / budget - D("0.5")) if budget > 0 else D("0")
            else:
                vol = D("0.002")
                skew = D("0")
            action = self.mm.stabilize_internal_pool(
                symbol=symbol,
                pool=self.shadow_pools[symbol],
                ledger=self.shadow_ledger,
                external_price=marks[symbol],
                volatility=vol,
                inventory_skew=skew,
                momentum=momentum,
            )
            if action.kind == "mint_sell":
                self.mint_sell_actions += 1
            elif action.kind == "buy_burn":
                self.buy_burn_actions += 1
            target = marks[symbol] * (D("1") + action.target_spread_bps / D("10000"))
            err = abs(self.shadow_pools[symbol].price_a_in_b / target - D("1")) * D("10000")
            self.spread_error_sum += err
            self.spread_error_count += 1
            self.max_spread_error = max(self.max_spread_error, err)
        self.shadow_prev_marks = {s: marks[s] for s in self.shadow_symbols}

    def _record_uncontrolled_spread_errors(self) -> None:
        marks = self.external_marks()
        for symbol, pool in self.shadow_pools.items():
            prev_mark = self.shadow_prev_marks.get(symbol, marks[symbol])
            momentum = marks[symbol] / prev_mark - D("1") if prev_mark > 0 else D("0")
            self.shadow_momentum[symbol] = momentum
            if symbol in self.base_symbols:
                vol = self.volatility[symbol]
                budget = self.risk_budget_usdc[symbol]
                current = self.bridge.real_balances.get(symbol, D("0")) * marks[symbol]
                skew = (current / budget - D("0.5")) if budget > 0 else D("0")
            else:
                vol = D("0.002")
                skew = D("0")
            target_bps = self.mm.target_spread(vol, skew, momentum)
            target = marks[symbol] * (D("1") + target_bps / D("10000"))
            err = abs(pool.price_a_in_b / target - D("1")) * D("10000")
            self.spread_error_sum += err
            self.spread_error_count += 1
            self.max_spread_error = max(self.max_spread_error, err)
        self.shadow_prev_marks = {s: marks[s] for s in self.shadow_symbols}

    def _synthetic_leverage(self) -> Decimal:
        nav = self.bridge.real_nav(self._real_prices())
        if nav <= 0:
            return D("999999")
        return self.synthetic_supply_value() / nav

    def _enforce_synthetic_capacity(self) -> None:
        lev = self._synthetic_leverage()
        self.max_synthetic_leverage_observed = max(self.max_synthetic_leverage_observed, lev)
        if lev > self.config.max_synthetic_leverage + D("0.000000001"):
            raise RuntimeError(f"shadow synthetic leverage exceeded: {lev}")

    def _bridge_asset_share(self) -> Decimal:
        nav = self.bridge.real_nav(self._real_prices())
        if nav <= 0:
            return D("0")
        asset_value = nav - self.bridge.real_balances.get("USDC", D("0"))
        return q(asset_value / nav)

    def _seal_chain_block(self, block: int) -> None:
        new_events = self.shadow_ledger.events[self._chain_ledger_event_cursor:]
        for event in new_events:
            self.chain.record(event.kind, {
                "asset": event.asset,
                "amount": str(event.amount),
                "reason": event.reason,
            })
            self._chain_tx_count += 1
        self._chain_ledger_event_cursor = len(self.shadow_ledger.events)
        self.chain.record("state_commitment", {
            "macro_block": block,
            "bridge_nav": str(self.bridge.real_nav(self._real_prices())),
            "synthetic_supply_value": str(self.synthetic_supply_value()),
            "external_redemption": False,
        })
        self._chain_tx_count += 1
        self.chain.seal_block()

    def _snapshot(self, block: int) -> dict[str, Any]:
        marks = self.external_marks()
        real = self.system_real_wealth()
        adjusted = q(real - self.core.net_external_capital_flow)
        hodl = self.hodl_benchmark()
        core_snap = self.core._snapshot(block)
        spread_errors = []
        targets = []
        for symbol, pool in self.shadow_pools.items():
            vol = self.volatility.get(symbol, D("0"))
            target_bps = self.mm.target_spread(vol, D("0"), self.shadow_momentum.get(symbol, D("0")))
            target = marks[symbol] * (D("1") + target_bps / D("10000"))
            spread_errors.append(abs(pool.price_a_in_b / target - D("1")) * D("10000"))
            targets.append(target_bps)
        core_snap.update({
            "system_real_wealth": float(real),
            "capital_adjusted_wealth": float(adjusted),
            "hodl_benchmark": float(hodl),
            "alpha_vs_hodl": float(q(adjusted - hodl)),
            "protocol_hard_nav": float(self.protocol_hard_nav()),
            "bridge_real_nav": float(self.bridge.real_nav(self._real_prices())),
            "bridge_usdc": float(q(self.bridge.real_balances.get("USDC", D("0")))),
            "bridge_real_asset_share": float(self._bridge_asset_share()),
            "bridge_realized_pnl": float(q(self.bridge.realized_pnl_usdc)),
            "bridge_external_fees": float(q(self.bridge.external_fees_usdc)),
            "shadow_supply_value": float(self.synthetic_supply_value(marks)),
            "shadow_minted_value": float(q(self._minted_value(marks) - self._seed_minted_value)),
            "shadow_burned_value": float(q(self._burned_value(marks) - self._seed_burned_value)),
            "shadow_fee_value": float(q(self.synthetic_fee_value)),
            "shadow_mean_spread_error_bps": float(q(sum(spread_errors, D("0")) / D(len(spread_errors)))),
            "shadow_max_spread_error_bps": float(q(max(spread_errors))),
            "shadow_target_spread_bps": float(q(sum(targets, D("0")) / D(len(targets)))),
            "shadow_mint_sell_actions": self.mint_sell_actions,
            "shadow_buy_burn_actions": self.buy_burn_actions,
            "shadow_prices": {s: float(q(p.price_a_in_b)) for s, p in self.shadow_pools.items()},
            "shadow_supplies": {s: float(q(v)) for s, v in self.shadow_ledger.supplies().items()},
            "bridge_asset_values": {s: float(q(qty * self.core.prices[s])) for s, qty in self.bridge.real_balances.items() if s != "USDC"},
        })
        return core_snap

    def run(self) -> DualContourReport:
        peak_adjusted = self.opening_system_real_wealth
        max_drawdown = D("0")
        for block in range(1, self.config.blocks + 1):
            self.core.prev_prices = dict(self.core.prices)
            stepped = self.core.reference.step()
            self.core.prices = {s: D(str(p)) for s, p in stepped.items()}

            self.core._outside_base_flows()
            self.core._outside_triangle_flow()
            for agent in self.core.agents:
                self.core._agent_base_action(agent)
            self.core._agent_triangle_action()
            self.core.capital.step(block=block, prices=self.core.prices, prev_prices=self.core.prev_prices)
            self.core._controller()

            self._shadow_noise_flow()
            if self.config.enable_external_delta_control:
                self._external_delta_control()
            else:
                for symbol in self.base_symbols:
                    self._state(symbol, self.core.prices[symbol], self.core.prev_prices[symbol])
            if self.config.enable_shadow_mm:
                self._stabilize_shadow()
            else:
                self._record_uncontrolled_spread_errors()
            self._enforce_synthetic_capacity()
            self._seal_chain_block(block)

            snap = self._snapshot(block)
            self.snapshots.append(snap)
            adjusted = D(str(snap["capital_adjusted_wealth"]))
            peak_adjusted = max(peak_adjusted, adjusted)
            if peak_adjusted > 0:
                max_drawdown = max(max_drawdown, (peak_adjusted - adjusted) / peak_adjusted * D("100"))

        marks = self.external_marks()
        closing = self.system_real_wealth()
        adjusted = q(closing - self.core.net_external_capital_flow)
        hodl = self.hodl_benchmark()
        mean_err = self.spread_error_sum / D(self.spread_error_count) if self.spread_error_count else D("0")
        bridge_values = {s: q(qty * self.core.prices[s]) for s, qty in self.bridge.real_balances.items() if s != "USDC"}
        return DualContourReport(
            blocks=self.config.blocks,
            block_seconds=self.config.block_seconds,
            elapsed_seconds=self.config.blocks * self.config.block_seconds,
            opening_system_real_wealth=q(self.opening_system_real_wealth),
            closing_system_real_wealth=q(closing),
            net_external_capital_flow=q(self.core.net_external_capital_flow),
            capital_adjusted_closing_wealth=adjusted,
            closing_hodl_benchmark=q(hodl),
            system_alpha_vs_hodl=q(adjusted - hodl),
            capital_adjusted_wealth_change=q(adjusted - self.opening_system_real_wealth),
            max_adjusted_drawdown_pct=q(max_drawdown),
            bridge_real_nav_start=q(self.bridge_real_nav_start),
            bridge_real_nav_end=q(self.bridge.real_nav(self._real_prices())),
            bridge_external_volume_usdc=q(self.bridge.external_volume_usdc),
            external_realized_inventory_pnl_usdc=q(self.bridge.realized_pnl_usdc),
            external_execution_fees_usdc=q(self.bridge.external_fees_usdc),
            synthetic_minted_usdc_equivalent=q(self._minted_value(marks) - self._seed_minted_value),
            synthetic_burned_usdc_equivalent=q(self._burned_value(marks) - self._seed_burned_value),
            synthetic_supply_value_end=self.synthetic_supply_value(marks),
            internal_synthetic_fee_value_susdc=q(self.synthetic_fee_value),
            ai_actions=self.mm.actions,
            mint_sell_actions=self.mint_sell_actions,
            buy_burn_actions=self.buy_burn_actions,
            internal_mean_abs_spread_error_bps=q(mean_err),
            internal_max_abs_spread_error_bps=q(self.max_spread_error),
            target_spread_bps_end=q(self.mm.target_spread(D("0"), D("0"))),
            bridge_real_asset_share_end=self._bridge_asset_share(),
            shadow_supply_end={k: q(v) for k, v in self.shadow_ledger.supplies().items()},
            bridge_asset_values_end=bridge_values,
            chain_height=self.chain.height,
            chain_tip_hash=self.chain.tip_hash,
            chain_tx_count=self._chain_tx_count,
            max_synthetic_leverage_observed=q(self.max_synthetic_leverage_observed),
            snapshots=list(self.snapshots),
        )
