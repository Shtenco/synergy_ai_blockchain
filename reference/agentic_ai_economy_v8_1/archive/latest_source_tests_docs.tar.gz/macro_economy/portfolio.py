from __future__ import annotations

from decimal import Decimal

from .agents import MarketAgent
from .yield_curve import SynergyYieldCurve

D = Decimal
WEIGHT_Q = D('0.000000000001')


def _d(value: float | Decimal) -> Decimal:
    return D(str(value))


def _clamp(value: Decimal, lo: Decimal, hi: Decimal) -> Decimal:
    return min(hi, max(lo, value))


class PortfolioAllocator:
    """Deterministic risk-aware target allocator for internal agents."""

    def __init__(self, symbols: tuple[str, ...] | list[str]) -> None:
        self.symbols = tuple(symbols)
        if not self.symbols:
            raise ValueError('at least one Base symbol is required')

    def target_weights(
        self,
        agent: MarketAgent,
        *,
        prices: dict[str, Decimal],
        prev_prices: dict[str, Decimal],
        internal_prices: dict[str, Decimal],
        rubx_price: Decimal,
        rubz_price: Decimal,
        rubz_fair_value: Decimal,
        curve: SynergyYieldCurve,
    ) -> dict[str, Decimal]:
        risk = _clamp(_d(agent.risk), D('0'), D('1'))
        safe_budget = _clamp(D('0.68') - risk * D('0.46'), D('0.18'), D('0.72'))
        risk_budget = D('1') - safe_budget

        short_rate = curve.rate_for_days(30)
        rubx_yield_bias = _clamp((short_rate - D('0.03')) * D('1.5'), D('-0.08'), D('0.16'))
        rubx_weight = _clamp(safe_budget * (D('0.52') + rubx_yield_bias), D('0.04'), safe_budget * D('0.82'))
        usdc_weight = safe_budget - rubx_weight

        rz_p = max(D('0.000001'), D(rubz_price))
        rz_fair = max(D('0.000001'), D(rubz_fair_value))
        valuation = _clamp(rz_fair / rz_p - D('1'), D('-0.35'), D('0.35'))
        rubz_share_of_risk = _clamp(D('0.18') + risk * D('0.18') + valuation * D('0.35'), D('0.08'), D('0.48'))
        rubz_weight = risk_budget * rubz_share_of_risk
        base_budget = risk_budget - rubz_weight

        scores: dict[str, Decimal] = {}
        trend = _d(agent.trend)
        mean_reversion = _d(agent.mean_reversion)
        for symbol in self.symbols:
            p = max(D('0.000000000001'), D(prices[symbol]))
            prev = max(D('0.000000000001'), D(prev_prices[symbol]))
            internal = max(D('0.000000000001'), D(internal_prices[symbol]))
            momentum = _clamp(p / prev - D('1'), D('-0.15'), D('0.15'))
            discount = _clamp(p / internal - D('1'), D('-0.15'), D('0.15'))
            score = D('1') + trend * momentum * D('18') + mean_reversion * discount * D('10')
            scores[symbol] = max(D('0.05'), score)
        total_score = sum(scores.values(), D('0'))

        weights: dict[str, Decimal] = {'USDC': usdc_weight, 'RUBX': rubx_weight, 'RUBZ': rubz_weight}
        for symbol in self.symbols:
            weights[symbol] = base_budget * scores[symbol] / total_score

        # Normalize after Decimal arithmetic. Assign rounding residual to cash.
        total = sum(weights.values(), D('0'))
        if total <= 0:
            raise ValueError('invalid zero portfolio target')
        weights = {k: (v / total).quantize(WEIGHT_Q) for k, v in weights.items()}
        residual = D('1') - sum(weights.values(), D('0'))
        weights['USDC'] += residual
        return weights
