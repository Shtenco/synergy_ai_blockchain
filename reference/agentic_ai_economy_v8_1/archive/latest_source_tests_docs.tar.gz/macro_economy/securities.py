from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
import math

from .agents import MarketAgent
from .yield_curve import SynergyYieldCurve, YEAR_SECONDS

D = Decimal


@dataclass
class AgentCompany:
    company_id: str
    founder_id: str
    cash_usdc: Decimal
    shares_outstanding: Decimal
    shareholders: dict[str, Decimal] = field(default_factory=dict)
    holdings: dict[str, Decimal] = field(default_factory=dict)
    realized_external_fees: Decimal = D('0')
    realized_pnl_usdc: Decimal = D('0')
    defaults: int = 0

    def real_nav(self, prices: dict[str, Decimal]) -> Decimal:
        return self.cash_usdc + sum(self.holdings.get(s, D('0')) * D(p) for s, p in prices.items())

    def equity_price(self, prices: dict[str, Decimal]) -> Decimal:
        if self.shares_outstanding <= 0:
            return D('0')
        return self.real_nav(prices) / self.shares_outstanding


@dataclass(frozen=True)
class EquityIssue:
    company_id: str
    investor_id: str
    cash_invested: Decimal
    shares_issued: Decimal
    price_per_share: Decimal


@dataclass
class CorporateBond:
    bond_id: str
    company_id: str
    investor_id: str
    face_value: Decimal
    coupon_rate: Decimal
    issue_price: Decimal
    issue_block: int
    maturity_block: int
    block_seconds: int
    issuer_spread: Decimal
    status: str = 'active'
    amount_paid: Decimal = D('0')
    loss_given_default: Decimal = D('0')

    @property
    def term_seconds(self) -> int:
        return max(0, self.maturity_block - self.issue_block) * self.block_seconds

    def amount_due(self) -> Decimal:
        return self.face_value * (D('1') + self.coupon_rate * D(self.term_seconds) / YEAR_SECONDS)


class SecuritiesMarket:
    """Internal company equity and corporate bond market.

    All primary subscriptions are transfers of existing agent USDC into a
    company balance. Shares and bond claims are internal claims and therefore
    must never be added to aggregate real wealth on top of company assets.
    """

    def __init__(self, *, block_seconds: int = 12) -> None:
        if block_seconds <= 0:
            raise ValueError('block_seconds must be positive')
        self.block_seconds = int(block_seconds)
        self.companies: dict[str, AgentCompany] = {}
        self.bonds: dict[str, CorporateBond] = {}
        self.agents: dict[str, MarketAgent] = {}
        self._next_company = 1
        self._next_bond = 1
        self.total_equity_issuance_usdc = D('0')
        self.total_bond_issuance_usdc = D('0')
        self.total_dividends_usdc = D('0')
        self.total_bond_losses_usdc = D('0')

    def _remember(self, agent: MarketAgent) -> None:
        self.agents[agent.agent_id] = agent

    def form_company(
        self,
        founder: MarketAgent,
        *,
        contribution_usdc: Decimal,
        initial_shares: Decimal | None = None,
    ) -> AgentCompany:
        contribution = D(contribution_usdc)
        shares = D(initial_shares if initial_shares is not None else contribution)
        if contribution <= 0 or shares <= 0:
            raise ValueError('company contribution and shares must be positive')
        if contribution > founder.cash_usdc:
            raise ValueError('insufficient founder cash')
        company_id = f'company:{self._next_company}'
        self._next_company += 1
        founder.cash_usdc -= contribution
        company = AgentCompany(
            company_id=company_id,
            founder_id=founder.agent_id,
            cash_usdc=contribution,
            shares_outstanding=shares,
            shareholders={founder.agent_id: shares},
        )
        self.companies[company_id] = company
        self._remember(founder)
        return company

    def subscribe_equity(
        self,
        company_id: str,
        investor: MarketAgent,
        cash_usdc: Decimal,
        *,
        prices: dict[str, Decimal],
    ) -> EquityIssue:
        company = self.companies[company_id]
        cash = D(cash_usdc)
        if cash <= 0 or cash > investor.cash_usdc:
            raise ValueError('invalid equity subscription')
        price = company.equity_price(prices)
        if price <= 0:
            raise ValueError('company has no positive equity value')
        shares = cash / price
        investor.cash_usdc -= cash
        company.cash_usdc += cash
        company.shares_outstanding += shares
        company.shareholders[investor.agent_id] = company.shareholders.get(investor.agent_id, D('0')) + shares
        self.total_equity_issuance_usdc += cash
        self._remember(investor)
        return EquityIssue(company_id, investor.agent_id, cash, shares, price)

    def pay_dividend(self, company_id: str, requested_usdc: Decimal) -> Decimal:
        company = self.companies[company_id]
        requested = max(D('0'), D(requested_usdc))
        paid = min(requested, company.cash_usdc)
        if paid <= 0 or company.shares_outstanding <= 0:
            return D('0')
        company.cash_usdc -= paid
        distributed = D('0')
        holders = list(company.shareholders.items())
        for idx, (agent_id, shares) in enumerate(holders):
            if agent_id not in self.agents:
                continue
            if idx == len(holders) - 1:
                amount = paid - distributed
            else:
                amount = paid * shares / company.shares_outstanding
                distributed += amount
            self.agents[agent_id].cash_usdc += amount
        self.total_dividends_usdc += paid
        return paid

    def issue_bond(
        self,
        company_id: str,
        investor: MarketAgent,
        *,
        face_value: Decimal,
        coupon_rate: Decimal,
        current_block: int,
        maturity_block: int,
        curve: SynergyYieldCurve,
        issuer_spread: Decimal = D('0.02'),
    ) -> CorporateBond:
        company = self.companies[company_id]
        face = D(face_value)
        coupon = D(coupon_rate)
        spread = D(issuer_spread)
        if face <= 0 or coupon < 0 or maturity_block <= current_block:
            raise ValueError('invalid bond terms')
        bond_id = f'bond:{self._next_bond}'
        self._next_bond += 1
        term_seconds = (maturity_block - current_block) * self.block_seconds
        days = max(1, math.ceil(term_seconds / 86400))
        market_yield = curve.rate_for_days(days) + spread
        due = face * (D('1') + coupon * D(term_seconds) / YEAR_SECONDS)
        issue_price = due * curve.discount_factor(market_yield, term_seconds)
        if issue_price > investor.cash_usdc:
            raise ValueError('insufficient investor cash for bond')
        investor.cash_usdc -= issue_price
        company.cash_usdc += issue_price
        bond = CorporateBond(
            bond_id=bond_id,
            company_id=company_id,
            investor_id=investor.agent_id,
            face_value=face,
            coupon_rate=coupon,
            issue_price=issue_price,
            issue_block=int(current_block),
            maturity_block=int(maturity_block),
            block_seconds=self.block_seconds,
            issuer_spread=spread,
        )
        self.bonds[bond_id] = bond
        self.total_bond_issuance_usdc += issue_price
        self._remember(investor)
        return bond

    def mark_bond(self, bond_id: str, *, current_block: int, annual_yield: Decimal) -> Decimal:
        bond = self.bonds[bond_id]
        if bond.status == 'repaid':
            return D('0')
        if current_block >= bond.maturity_block:
            return bond.amount_due() if bond.status == 'active' else bond.amount_paid
        remaining_seconds = (bond.maturity_block - current_block) * bond.block_seconds
        return bond.amount_due() * SynergyYieldCurve.discount_factor(D(annual_yield) + bond.issuer_spread, remaining_seconds)

    def settle_bond(self, bond_id: str, investor: MarketAgent, *, current_block: int) -> CorporateBond:
        bond = self.bonds[bond_id]
        if bond.status != 'active':
            return bond
        if current_block < bond.maturity_block:
            raise ValueError('bond has not matured')
        if investor.agent_id != bond.investor_id:
            raise ValueError('bond investor does not match')
        company = self.companies[bond.company_id]
        due = bond.amount_due()
        paid = min(company.cash_usdc, due)
        company.cash_usdc -= paid
        investor.cash_usdc += paid
        bond.amount_paid = paid
        if paid >= due:
            bond.status = 'repaid'
        else:
            bond.status = 'defaulted'
            bond.loss_given_default = due - paid
            company.defaults += 1
            self.total_bond_losses_usdc += bond.loss_given_default
        return bond

    def active_bonds(self) -> tuple[CorporateBond, ...]:
        return tuple(b for b in self.bonds.values() if b.status == 'active')

    def equity_market_cap(self, prices: dict[str, Decimal]) -> Decimal:
        return sum((c.real_nav(prices) for c in self.companies.values()), D('0'))
