from __future__ import annotations

from decimal import Decimal

D = Decimal
YEAR_SECONDS = D('31536000')
RATE_Q = D('0.000000000001')


def _clamp(value: Decimal, lo: Decimal, hi: Decimal) -> Decimal:
    return min(hi, max(lo, D(value)))


class SynergyYieldCurve:
    """Deterministic annualized internal reference curve.

    Rates are quotes for internal pricing only. Cash accrual elsewhere uses the
    literal block clock and ACT/365 seconds, so quoting a rate never creates
    money by itself.
    """

    TENORS_DAYS = (1, 7, 30, 90, 365)

    def __init__(self, policy_rate: Decimal = D('0.05')) -> None:
        self.policy_rate = _clamp(D(policy_rate), D('0'), D('1'))
        self.rates: dict[int, Decimal] = {d: self.policy_rate for d in self.TENORS_DAYS}
        self.last_inputs = {
            'coverage_ratio': D('2'),
            'realized_vol': D('0'),
            'credit_utilization': D('0'),
            'bad_debt_ratio': D('0'),
        }

    def update(
        self,
        coverage_ratio: Decimal,
        realized_vol: Decimal,
        credit_utilization: Decimal,
        bad_debt_ratio: Decimal,
    ) -> dict[int, Decimal]:
        coverage = max(D('0'), D(coverage_ratio))
        vol = _clamp(D(realized_vol), D('0'), D('2'))
        utilization = _clamp(D(credit_utilization), D('0'), D('1.5'))
        bad_debt = _clamp(D(bad_debt_ratio), D('0'), D('1'))
        coverage_penalty = max(D('0'), D('1.50') - coverage) * D('0.07')
        liquidity_penalty = max(D('0'), utilization - D('0.65')) * D('0.10')
        stress_anchor = vol * D('0.10') + bad_debt * D('0.45')
        short = _clamp(self.policy_rate + coverage_penalty + liquidity_penalty + stress_anchor, D('0.001'), D('0.75'))

        rates: dict[int, Decimal] = {}
        for days in self.TENORS_DAYS:
            t = D(days) / D('365')
            # Positive term premium increases with volatility and utilization.
            premium = (D('0.006') + vol * D('0.035') + utilization * D('0.006')) * t.sqrt()
            rates[days] = _clamp(short + premium, D('0.001'), D('0.95')).quantize(RATE_Q)
        self.rates = rates
        self.last_inputs = {
            'coverage_ratio': coverage,
            'realized_vol': vol,
            'credit_utilization': utilization,
            'bad_debt_ratio': bad_debt,
        }
        return dict(rates)

    def rate_for_days(self, days: int) -> Decimal:
        if days <= 0:
            raise ValueError('days must be positive')
        if days in self.rates:
            return self.rates[days]
        # Piecewise linear interpolation/extrapolation over published nodes.
        nodes = self.TENORS_DAYS
        if days < nodes[0]:
            return self.rates[nodes[0]]
        if days > nodes[-1]:
            return self.rates[nodes[-1]]
        left = nodes[0]
        for right in nodes[1:]:
            if days <= right:
                w = D(days - left) / D(right - left)
                return (self.rates[left] + (self.rates[right] - self.rates[left]) * w).quantize(RATE_Q)
            left = right
        return self.rates[nodes[-1]]

    @staticmethod
    def discount_factor(annual_rate: Decimal, elapsed_seconds: int | Decimal) -> Decimal:
        seconds = D(elapsed_seconds)
        if seconds < 0:
            raise ValueError('elapsed_seconds must be non-negative')
        rate = max(D('-0.99'), D(annual_rate))
        return D('1') / (D('1') + rate * seconds / YEAR_SECONDS)
