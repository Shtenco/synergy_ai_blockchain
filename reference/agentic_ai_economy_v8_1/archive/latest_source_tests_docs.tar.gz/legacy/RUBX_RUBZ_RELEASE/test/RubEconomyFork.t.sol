// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RubToken} from "../src/RubToken.sol";
import {RubPool} from "../src/RubPool.sol";
import {RubTreasury} from "../src/RubTreasury.sol";
import {RubEconomy} from "../src/RubEconomy.sol";

interface VmC {
    function deal(address who, uint256 amt) external;
}

interface IERC20F {
    function balanceOf(address) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
}

interface IWETH {
    function deposit() external payable;
}

interface IRouter {
    struct EIP {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(EIP calldata params) external payable returns (uint256);
}

interface IV3P {
    function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16, uint16, uint16, uint8, bool);
}

/// Base-fork test: real USDC/WETH (no ERC20 deal cheatcode in this build —
/// funding via real WETH.deposit + V3 swap), 5 pools, 24 investor cycles.
/// Proves: principal returned, yield <= realized, MINT/ADDLP/arb are
/// HardNAV-neutral, reserve floor kept, accounting closed.
contract RubEconomyForkTest {
    VmC constant vm = VmC(address(uint160(uint256(keccak256("hevm cheat code")))));
    address constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address constant WETH = 0x4200000000000000000000000000000000000006;
    address constant V3 = 0xd0b53D9277642d899DF5C87A3966A349A798F224;
    address constant ROUTER = 0x2626664c2603336E57B271c5C0b26F421741e481;

    event Check(string name, uint256 value);

    // NOTE: run with --fork-url https://mainnet.base.org
    function testForkEconomy() public {
        vm.deal(address(this), 2 ether);
        // real funding: wrap ETH, swap 0.15 WETH -> USDC on V3 (500)
        IWETH(WETH).deposit{value: 1 ether}();
        IERC20F(WETH).approve(ROUTER, type(uint256).max);
        IRouter(ROUTER).exactInputSingle(
            IRouter.EIP(WETH, USDC, 500, address(this), 0.15 ether, 0, 0)
        );
        uint256 uFunded = IERC20F(USDC).balanceOf(address(this));
        require(uFunded > 110_000_000, "FORK: V3 funding short");
        emit Check("fundedU", uFunded);

        RubToken rubx = new RubToken("RUBX", "RUBX", 18, address(this));
        RubToken rubz = new RubToken("RUBZ", "RUBZ", 18, address(this));
        RubTreasury tr = new RubTreasury(address(this));
        RubEconomy eco = new RubEconomy(address(rubx), address(rubz), USDC, WETH, address(tr), address(this));
        RubPool pXU = new RubPool(address(rubx), USDC, 18, 6, address(eco), address(tr));
        RubPool pZU = new RubPool(address(rubz), USDC, 18, 6, address(eco), address(tr));
        RubPool pXZ = new RubPool(address(rubx), address(rubz), 18, 18, address(eco), address(tr));
        RubPool pXC = new RubPool(address(rubx), WETH, 18, 18, address(eco), address(tr));
        RubPool pZC = new RubPool(address(rubz), WETH, 18, 18, address(eco), address(tr));
        address[5] memory ps = [address(pXU), address(pZU), address(pXZ), address(pXC), address(pZC)];
        eco.linkPools(ps);
        tr.setOwner(address(eco));
        rubx.setMinter(address(eco));
        rubz.setMinter(address(eco));

        (uint160 sq,,,,,,) = IV3P(V3).slot0();
        // micro-USDC per 1e18 wei: raw(sq^2/2^192) * 1e18/1e6 = sq^2 * 1e18 / 2^192
        uint256 wethPx = (uint256(sq) * uint256(sq) * 1e18) / (uint256(1) << 192);
        require(wethPx > 1000e6 && wethPx < 10000e6, "FORK: bad wethPx");
        eco.setWethPx(wethPx);
        emit Check("wethPx", wethPx);

        IERC20F(USDC).approve(address(eco), type(uint256).max);
        IERC20F(WETH).approve(address(eco), type(uint256).max);
        IERC20F(USDC).approve(address(pXU), type(uint256).max);
        IERC20F(USDC).approve(address(pZU), type(uint256).max);

        uint256 wFor2 = (2_000_000 * 1e18) / wethPx; // $2 of WETH
        eco.seed(
            50e18, 50_000_000, 50e18, 50_000_000,
            50e18, 50e18, 2e18, wFor2,
            2e18, wFor2, 5_000_000, 0.02 ether
        );
        uint256 hard0 = eco.hardNAV();
        require(hard0 > 0, "FORK: empty hardNAV");
        emit Check("hard0", hard0);

        // external flow so ADDLP budget exists, then mock yield (test actor
        // plays the outside world: sends its own real WETH, books as yield)
        pXU.swapBForA(200000, true);
        pZU.swapBForA(200000, true);
        eco.noteTreasury();
        IERC20F(WETH).transfer(address(tr), 0.002 ether);
        eco.bookYield();

        // invariant 1: fresh triangle arb is HardNAV-neutral
        (uint256 arbOut, uint256 arbSp) = eco.arbTriangle(20000);
        arbOut; arbSp;
        uint256 hardPreAddlp = eco.hardNAV();
        eco.addlpXU(1000);
        require(eco.hardNAV() == hardPreAddlp, "FORK: addlp moved HardNAV");

        uint256 uBal0 = IERC20F(USDC).balanceOf(address(this));
        uint256 traderSpent;
        uint256 NCYC = 20;
        for (uint256 c = 0; c < NCYC; c++) {
            // recursive loop: taker volume scales with USDC depth
            (, uint256 d0) = pXU.getReserves();
            (, uint256 d1) = pZU.getReserves();
            uint256 v = (50000 * (d0 + d1)) / 100_000_000;
            if (v < 20000) v = 20000;
            if (v > 300000) v = 300000;
            pXU.swapBForA(v, true);
            traderSpent += v;
            pZU.swapBForA(v, true);
            traderSpent += v;
            if (c == 8 || c == 16) {
                eco.noteTreasury();
                IERC20F(WETH).transfer(address(tr), 0.002 ether);
                eco.bookYield();
            }
            try eco.arbTriangle(20000) {} catch {}
            try eco.rebalanceXZ() {} catch {}
            if (c % 6 == 5) {
                try eco.mintSellX(0.5e18) {} catch {}
                try eco.mintSellZ(0.5e18) {} catch {}
            }
            if (c % 8 == 7) {
                try eco.addlpXU(20000) {} catch {}
            }
            eco.investorCycle();
        }

        require(eco.totalPrincipalOut() == eco.totalDeposits(), "FORK: principal not returned");
        require(eco.paidYield() <= eco.realized(), "FORK: yield exceeds realized profit");
        require(eco.freeU() >= 500000, "FORK: reserve floor breached");

        uint256 uBal1 = IERC20F(USDC).balanceOf(address(this));
        require(uBal1 + traderSpent >= uBal0, "FORK: actor accounting");
        require(uBal1 + traderSpent - uBal0 == eco.paidYield(), "FORK: delta != paid yield");

        uint256 tu = IERC20F(USDC).balanceOf(address(tr));
        uint256 tc = IERC20F(WETH).balanceOf(address(tr));
        (, uint256 r0u) = pXU.getReserves();
        (, uint256 r1u) = pZU.getReserves();
        (, uint256 r3c) = pXC.getReserves();
        (, uint256 r4c) = pZC.getReserves();
        uint256 expectHard = tu + (tc * wethPx) / 1e18 + r0u + r1u
            + (r3c * wethPx) / 1e18 + (r4c * wethPx) / 1e18;
        require(eco.hardNAV() == expectHard, "FORK: hardNAV accounting open");

        // owner-withdraw paths: exact HardNAV accounting, guarantees intact
        uint256 hardPreW = eco.hardNAV();
        eco.treasuryWithdraw(USDC, address(this), 100000);
        require(eco.hardNAV() == hardPreW - 100000, "FORK: treasuryWithdraw accounting");
        eco.poolWithdraw(0, address(this), 0, 50000);
        require(eco.hardNAV() == hardPreW - 100000 - 50000, "FORK: poolWithdraw accounting");
        require(eco.ownerOut() == 150000, "FORK: ownerOut tracking");
        // investor guarantees still hold after discretionary takes
        eco.investorCycle();
        require(eco.totalPrincipalOut() == eco.totalDeposits(), "FORK: principal after withdraw");
        require(eco.paidYield() <= eco.realized(), "FORK: yield after withdraw");

        eco.emitBoard();
        emit Check("hard1", eco.hardNAV());
        emit Check("tvl1", eco.grossTVL());
        emit Check("mark1", eco.markNAV());
        emit Check("realized", eco.realized());
        emit Check("paidYield", eco.paidYield());
        emit Check("fees", eco.feesAcc());
        emit Check("cycles", eco.cycles());
    }
}
