// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RubSimLib} from "../src/RubSim.sol";

/// Long-horizon simulator + parameter tuner (pure math, deterministic).
/// Snapshot stride keeps memory bounded: every cycle (1k), every 10th (10k),
/// every 100th (100k), every 1000th (1M). 100k/1M run in 100k-state chunks.
/// NOTE: single-tx EVM gas limit caps in-test runs at ~100k cycles;
/// the 1M run executes via RubSimState on local anvil (20 x 50k chunks).
contract RubSimTest {
    using RubSimLib for RubSimLib.S;

    event SimDone(string name, uint256 cycles, uint256 hardEnd, uint256 tvlEnd,
        uint256 paidY, uint256 realized, uint256 supX, uint256 supZ, uint256 snaps);
    event Tuned(uint256 indexed best, uint256 hardEnd, uint256 reinvest, uint256 arbMin, uint256 micro);

    function _prm() internal pure returns (RubSimLib.Prm memory p) {
        p = RubSimLib.Prm({
            sellThrBps: 200, buyThrBps: 200,
            microMintX: 5e18, microMintZ: 5e18, microSizeU: 50000,
            buyCapBps: 200, reinvestBps: 2500,
            arbMinBps: 30, rebThrBps: 500, dustTolU: 2000,
            microRebMax: 2e18, rebCooldown: 200, maxSlipBps: 100,
            ownerTakeU: 0,
            yieldTarget: 20000, investorIn: 100000,
            reserveFloorU: 500000, payMode: 0,
            targetX: 1000000, targetZ: 1000000,
            wethPx: 2400_000_000, baseVolU: 100_000_000, yieldC: 4_000_000_000_000,
            depthRefU: 1_000_000_000
        });
    }

    function _state() internal pure returns (RubSimLib.S memory s) {
        // Seed mirrors fork test proportions (micro-USDC / wei):
        // XU 500X+500U, ZU 500Z+500U, XZ 500X+500Z,
        // XC 20X + 20/2400 WETH, ZC same, treasury 2U.
        uint256 wpx = 2400_000_000;
        uint256 wFor20 = (20_000_000 * 1e18) / wpx;
        s.rxuX = 500e18; s.rxuU = 500_000_000;
        s.rzuZ = 500e18; s.rzuU = 500_000_000;
        s.rxzX = 500e18; s.rxzZ = 500e18;
        s.rxcX = 20e18;  s.rxcC = wFor20;
        s.rzcZ = 20e18;  s.rzcC = wFor20;
        s.supX = 500e18 + 500e18 + 20e18;
        s.supZ = 500e18 + 500e18 + 20e18;
        s.treasU = 2_000_000;
        s.treasC = 0;
    }

    function _run(RubSimLib.S memory s, RubSimLib.Prm memory p, uint256 n, uint256 stride)
        internal pure returns (RubSimLib.Snap[] memory snaps, uint256 cnt)
    {
        uint256 maxSnaps = n / stride + 1;
        snaps = new RubSimLib.Snap[](maxSnaps);
        cnt = RubSimLib.run(s, p, n, stride, snaps);
    }

    function _check(RubSimLib.S memory s, RubSimLib.Prm memory p, uint256 hard0) internal pure {
        require(s.paidY <= s.realized, "SIM: yield exceeds realized");
        require(s.treasU >= p.reserveFloorU, "SIM: floor breached");
        require(RubSimLib.hard(s, p.wethPx) >= hard0, "SIM: hardNAV shrank");
    }

    event Row(uint256 cycle, uint256 hard, uint256 tvl, uint256 paidY, uint256 realized, uint256 treasU);

    /// Короткий прогон ровно на 10 циклов: полный ряд построчно + множители.
    function testSim10() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        uint256 hard0 = RubSimLib.hard(s, p.wethPx);
        uint256 tvl0 = RubSimLib.tvl(s, p.wethPx);
        emit Row(0, hard0, tvl0, 0, 0, s.treasU);
        for (uint256 i = 0; i < 10; i++) {
            RubSimLib.Snap[] memory snaps = new RubSimLib.Snap[](2);
            RubSimLib.run(s, p, 1, 1, snaps);
            emit Row(s.cycles, RubSimLib.hard(s, p.wethPx), RubSimLib.tvl(s, p.wethPx),
                s.paidY, s.realized, s.treasU);
        }
        emit SimDone("sim10", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, 10);
    }

    /// Короткий прогон ровно на 20 циклов: полный ряд построчно.
    function testSim20() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        for (uint256 i = 0; i < 20; i++) {
            RubSimLib.Snap[] memory snaps = new RubSimLib.Snap[](2);
            RubSimLib.run(s, p, 1, 1, snaps);
            emit Row(s.cycles, RubSimLib.hard(s, p.wethPx), RubSimLib.tvl(s, p.wethPx),
                s.paidY, s.realized, s.treasU);
        }
        require(s.paidY <= s.realized, "SIM20: yield exceeds realized");
        require(s.treasU >= p.reserveFloorU, "SIM20: floor breached");
        emit SimDone("sim20", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, 20);
    }

    function testSim1000() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        uint256 hard0 = RubSimLib.hard(s, p.wethPx);
        (RubSimLib.Snap[] memory snaps, uint256 cnt) = _run(s, p, 1000, 1);
        require(cnt == 1000, "SIM: snap count");
        _check(s, p, hard0);
        emit SimDone("sim1000", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, cnt);
        snaps[0].cycle; // silence linter
    }

    function testSim10000() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        uint256 hard0 = RubSimLib.hard(s, p.wethPx);
        (RubSimLib.Snap[] memory snaps, uint256 cnt) = _run(s, p, 10000, 10);
        require(cnt == 1000, "SIM: snap count");
        _check(s, p, hard0);
        emit SimDone("sim10000", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, cnt);
        snaps[0].cycle;
    }

    function testSim100000() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        uint256 hard0 = RubSimLib.hard(s, p.wethPx);
        RubSimLib.Snap[] memory snaps = new RubSimLib.Snap[](1000);
        uint256 cnt;
        for (uint256 k = 0; k < 10; k++) {
            RubSimLib.Snap[] memory tmp = new RubSimLib.Snap[](100);
            uint256 c = RubSimLib.run(s, p, 10000, 100, tmp);
            for (uint256 j = 0; j < c; j++) snaps[cnt++] = tmp[j];
        }
        require(cnt == 1000, "SIM: snap count");
        _check(s, p, hard0);
        emit SimDone("sim100000", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, cnt);
    }

    /// 1M cycles exceed single-tx gas: executed via RubSimState on local
    /// anvil in 20 x 50k chunks (state persists in storage between chunks).
    function testSim1000000() public {
        RubSimLib.S memory s = _state();
        RubSimLib.Prm memory p = _prm();
        uint256 hard0 = RubSimLib.hard(s, p.wethPx);
        // smoke: first 1000 cycles in-tx prove the code path; full 1M via anvil
        (RubSimLib.Snap[] memory snaps, uint256 cnt) = _run(s, p, 1000, 1);
        require(cnt == 1000, "SIM: snap count");
        _check(s, p, hard0);
        emit SimDone("sim1000000-smoke", s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized, s.supX, s.supZ, cnt);
        snaps[0].cycle;
    }

    /// Grid tuner: 2x2x2 configs x 300 cycles. Score = final HardNAV subject to
    /// payout-met + floor-kept constraints. Emits best config.
    function testTuner() public {
        uint256[2] memory reinvest = [uint256(1000), uint256(5000)];
        uint256[2] memory arbMin = [uint256(20), uint256(100)];
        uint256[2] memory micro = [uint256(20000), uint256(100000)];
        uint256 bestScore;
        uint256 bestCfg;
        uint256 bestR; uint256 bestA; uint256 bestM;
        uint256 cfg;
        for (uint256 i = 0; i < 2; i++) {
            for (uint256 j = 0; j < 2; j++) {
                for (uint256 k = 0; k < 2; k++) {
                    RubSimLib.S memory s = _state();
                    RubSimLib.Prm memory p = _prm();
                    p.reinvestBps = reinvest[i];
                    p.arbMinBps = arbMin[j];
                    p.microSizeU = micro[k];
                    RubSimLib.Snap[] memory snaps = new RubSimLib.Snap[](301);
                    RubSimLib.run(s, p, 300, 1, snaps);
                    bool ok = s.paidY <= s.realized && s.treasU >= p.reserveFloorU;
                    // payout coverage: paid vs target*300
                    uint256 cover = (s.paidY * 10000) / (p.yieldTarget * 300);
                    if (ok && cover >= 9500) {
                        uint256 score = RubSimLib.hard(s, p.wethPx);
                        if (score > bestScore) {
                            bestScore = score;
                            bestCfg = cfg;
                            bestR = reinvest[i]; bestA = arbMin[j]; bestM = micro[k];
                        }
                    }
                    cfg++;
                    snaps[0].cycle;
                }
            }
        }
        require(bestScore > 0, "TUNER: no feasible config");
        emit Tuned(bestCfg, bestScore, bestR, bestA, bestM);
    }
}
