# RUBX / RUBZ — экономическая система. Полная документация

Дата среза: 2026-09-16. Папка-релиз: всё важное из `RUBX_RUBZ_ECONOMY`
(контракты `src/`, тесты `test/`, конфиг, собранные артефакты `out/`).
Кэш forge (`cache/`) не копировался — пересоздаётся командой `forge build`.

Главная цель проекта — **рост Hard NAV** (настоящего резерва), а не TVL.
Рост TVL без роста Hard NAV прибылью НЕ считается — это правило зашито
в учёт и тесты.

---

## 1. Активы

| Актив | Тип | Роль |
|---|---|---|
| RUBX (18 dec) | внутренний | MINT через контроллер, BURN при выкупе |
| RUBZ (18 dec) | внутренний | то же |
| USDC (6 dec, Base `0x8335…2913`) | **реальный резерв** | расчёт капитала, депозиты, выплаты |
| Collateral = WETH (18 dec, `0x4200…0006`) | **реальный резерв** | второй резервный актив, цена — внешняя (V3) |

Реальный капитал = только USDC + collateral. RUBX/RUBZ в резерв не входят.

## 2. Пять пулов (все 100% protocol-owned)

| # | Пара | Роль |
|---|---|---|
| 0 | RUBX / USDC | базовая цена RUBX |
| 1 | RUBZ / USDC | базовая цена RUBZ |
| 2 | RUBX / RUBZ | внутренняя ликвидность без USDC |
| 3 | RUBX / WETH | связь с collateral |
| 4 | RUBZ / WETH | связь с collateral |

CPMM `x*y=k`, комиссия 30 bps всего, из них **5 bps — протокол** в treasury.
Протокол-комиссия берётся **только с внешнего потока** (`withProto=true`).
Собственные операции (сид, маршрут инвестора, контроллер) идут с `withProto=false`,
поэтому система **не может нарисовать себе realized-прибыль своим же объёмом**.

## 3. Файлы и контракты

| Файл | Что внутри |
|---|---|
| `src/RubToken.sol` | ERC20 RUBX/RUBZ, MINT/BURN только через minter (Economy) |
| `src/RubPool.sol` | CPMM-пул: `addLiquidity`, `swapAForB/swapBForA`, `quoteAForB/quoteBForA`, `removeTo` (только owner), proto-fee в treasury + `notifyProto` |
| `src/RubTreasury.sol` | глупый сейф USDC/WETH/RUBX/RUBZ; весь учёт — в Economy |
| `src/RubEconomy.sol` | контроллер + все метрики + investor-цикл + `decide()` + `dashboard()` |
| `src/RubSim.sol` | `RubSimLib`: чистая математика = 1:1 логике Economy, без токенов (для 1k–1M циклов) |
| `src/RubSimState.sol` | stateful-обёртка: состояние в storage, прогон 1M чанками (N×50k) |
| `test/RubEconomyFork.t.sol` | **форк-тест Base mainnet**: реальные USDC/WETH, 20 investor-циклов |
| `test/RubSim.t.sol` | симуляторы 10/20/1k/10k/100k/1M(smoke) + грид-тюнер параметров |

## 4. Три метрики (микро-USDC)

- **Gross TVL** = сумма обеих сторон всех 5 пулов по текущим ценам.
  Включает внутренние токены → растёт от MINT. Не прибыль.
- **Mark NAV** = TVL + все активы treasury по текущим ценам.
- **Hard NAV** = treasury USDC+WETH **+** USDC+WETH внутри пулов.
  Внутренних токенов здесь **нет**. Главный показатель.

Цены: `pxX = resU*1e18/resX` (пул 0), `pxZ` (пул 1),
кросс `pxXviaZ = resZ*pxZ/resX` (пул 2), `pxXviaC = resC*wethPx/resX` (пул 3).
`wethPx` — внешний (на форке читается из V3 `slot0` один раз при setup).

## 5. Механики контроллера

- **MINT + SELL** — только при премии (`px > target×(1+2%)`), микро-лотом,
  кап ≤ ~1% USDC-стороны пула (анти-принтер). Перемещение USDC пул→treasury,
  HardNAV не меняется; смысл — фиксация переоценки + глубина.
- **BUY + BURN** — только при дисконте, трата ≤ 2% свободного резерва и
  никогда ниже `reserveFloorU` (0.50 USDC).
- **Арбитраж-треугольник** U→X→Z→U — только выравнивание цен, HardNAV-neutral
  по построению. Срабатывает при спреде ≥ 30 bps и проходит слиппедж-гарды,
  иначе пропуск (без реверта).
- **Ребаланс XZ** — при спреде ≥ 500 bps: MINT обеих сторон ≤ 2e18,
  кулдаун 200 циклов (защита от экспоненциальной печати; найдено прогоном 1M).
- **ADDLP** — только из свободной реальной прибыли:
  `amt ≤ (realized − paidYield) × 25%` и не больше свободного USDC.
  Для пары XU/ZU вторая сторона — свежий MINT; пара XZ — MINT обеих сторон
  (номинал растёт, HardNAV не меняется).
- **`decide()`** — порядок: Rebalance → Arb → MintSell → BuyBurn → Addlp → None.
  Цель — долгосрочный HardNAV, не моментальный TVL.

## 6. Investor-цикл (0.10 USDC in → 0.10 + до 0.02 out)

1. Маршрут **адаптивный**: котируется треугольник U→X→Z→U; если просадка
   ≤ `dustTolU` (2000 micro) — идём им, иначе fallback — круг U→X→U
   на пуле 0 (потеря ≤ ~60 bps, XZ не трогаем).
2. Principal 0.10 возвращается всегда (недобор покрывается из свободного
   резерва выше floor и пишется в `totalShortfall`).
3. Yield = `min(0.02, realized − paidYield, freeAboveFloor)`.
   Режимы: `0` урезать (по умолч.), `1` отложить в `owedYield`, `2` выкл.
4. Пыль маршрута — в treasury **без** зачёта в realized (внутреннее).

## 7. Откуда берётся реальная прибыль (и только она идёт в realized)

1. Proto-комиссии 5 bps с внешнего тейкер-объёма (автоматом через `notifyProto`).
2. Спред, осевший в пулах от внешних кругов (LP-захват).
3. Yield collateral через `noteTreasury/bookYield` (внешний источник).
4. Пыль НЕ считается. MINT/ADDLP/внутренний арбитраж — НЕ считаются.

## 8. Формула доходности per flash (лагерная)

`net = flash × spread_bps/10000 − flash × 60bps/10000`
Пример из спеки: L1 TWAP $2400, L2 spot $2520 → spread 500 bps;
flash 1000 USDC → gross 50 − fee 6 = **net 44 USDC**.
Мост — виртуальный инвентарь (`BridgeInventory.l1Weth/l2Usdc` — числа, без
переездов токенов каждый цикл). Работает тогда и только тогда, когда
`spread > fee` **и** пул достаточно глубок, чтобы слиппедж не съел спред.

## 9. Замеренный множитель (10 циклов, сим)

Депозиты: 10 × $0.10 = **$1.00**.

| cycle | HardNAV | TVL | paidY | realized |
|---|---|---|---|---|
| 0 | 1042.00 | 3080.00 | 0 | 0 |
| 10 | 1045.14 | 3089.09 | 0.20 | 0.40 |

- **ΔHardNAV / $1 = $3.14 → 3.14×**
- **ΔTVL / $1 = $9.09 → 9.09×**
- Плечо TVL/Hard ≈ 2.96×
- Инвестор: внёс $1.00 → забрал $1.00 + $0.20 (покрытие realized 198%)

Множитель применяется к **внешнему потоку**, не к депозиту (депозит ходит
кругом 1:1). Нет потока — нет роста.

## 10. Форк-прогон Base (20 циклов) — PASS

`forge test --fork-url https://mainnet.base.org --match-test testForkEconomy`

- `wethPx` (V3): 2401701643 ($2401.70); `hard0`: $157.03
- 24→20 циклов: внешние свопы 2×v/cycle (v масштабируется от глубины),
  yield 3×0.002 WETH, arb/mintSell/addlp best-effort, investor 0.10
- `hard1`: **$173.46** (+$16.4 = yield $14.4 + внешние покупки $2 + proto)
- `tvl1`: $311.86, `mark1`: $380.34, `realized`: $14.41
- `paidYield`: $0.40 = 20×$0.02 полностью; `fees`: 1200 micro
- Инварианты: principal 1:1 ✓, `paidYield ≤ realized` ✓, floor $0.50 цел ✓,
  arb/addlp HardNAV-neutral ✓, независимый пересчёт HardNAV сошёлся ✓
- Цены у пега: RUBX $1.008, RUBZ $1.004

## 11. Длинные горизонты (детерминированный сим)

| Горизонт | Статус | Итог |
|---|---|---|
| 1 000 | PASS | Hard растёт, инварианты держат |
| 10 000 | PASS | то же |
| 100 000 | PASS (10×10k чанков) | то же |
| 1 000 000 | PASS (anvil, 20×50k, `seal()`) | cycles 1M, **Hard $2,957,525**, TVL $2.76M, paidY **$20,000 = ровно таргет**, realized $257,732, shortfalls **$600** (было $99,751 до адаптивного маршрута), snaps 1000 |
| Тюнер (2×2×2 × 300 циклов) | PASS | выбирает max HardNAV при выплате ≥95% и целом поле |

Снапшоты: каждый цикл (1k) / каждый 10-й (10k) / каждый 100-й (100k) /
каждый 1000-й (1M) — всегда ≤1000 записей. Полный пер-цикл ряд для 1M
читается из `RubSimState.snaps` на anvil.

## 12. Найденные и исправленные дефекты (честно)

1. `markNAV()` не возвращал значение (→ 0). Исправлено.
2. Потеря консервации в sim-ветке investor (печать USDC). Исправлено.
3. Фиксированный треугольный маршрут дренировал XZ за 1M (shortfall $99k).
   Исправлено адаптивным маршрутом + фолбэком (→ $600).
4. Ребаланс без кулдауна = экспоненциальный принтер (1.28M X/Z к 20k).
   Исправлено кулдауном 200 + капом 2e18.
5. Sim-arb печатал `inU` (нет дебета treasury). Исправлено (латентно:
   слиппедж-гард и так не давал стрелять).
6. Forge 1.8.x в этой сборке не знает `deal(ERC20)`/`createSelectFork` —
   форк-тест финансируется реальными `WETH.deposit` + V3-свопом, форк через CLI.

## 13. Как воспроизвести

```powershell
& "C:\Users\Shtenco\AppData\Local\Temp\opencode\foundry-v1.8.1\forge.exe" build --root "C:\Users\Shtenco\Desktop\RUBX_RUBZ_RELEASE"
& "C:\Users\Shtenco\AppData\Local\Temp\opencode\foundry-v1.8.1\forge.exe" test --root "C:\Users\Shtenco\Desktop\RUBX_RUBZ_RELEASE" --match-test "testSim10|testSim1000|testTuner"
& "C:\Users\Shtenco\AppData\Local\Temp\opencode\foundry-v1.8.1\forge.exe" test --root "C:\Users\Shtenco\Desktop\RUBX_RUBZ_RELEASE" --fork-url https://mainnet.base.org --match-test "testForkEconomy" -vvvv
```

1M (нужен anvil с большим лимитом газа):
```powershell
& "<foundry>\anvil.exe" --gas-limit 2000000000 --port 8545
# deploy out/RubSimState.sol/RubSimState.json -> init() -> 20x advance(50000) -> seal() -> result()
```

Дашборд в любой момент: `RubEconomy.dashboard()` —
`(hardNAV, markNAV, tvl, treasU, treasC, 10 резервов, pxX, pxZ, supX, supZ,
fees, arbVol, paidY, paidP, realized, cycles, coverBps)`, плюс событие `Dashboard`.

## 14. Вывод овнера (discretionary takes)

- `RubEconomy.treasuryWithdraw(token, to, amount)` — прямой вывод из treasury.
- `RubEconomy.poolWithdraw(i, to, a, b)` — прямой вывод резервов любого пула.
- `RubEconomy.rescue(...)` — пыль с самого Economy.
- Всё onlyOwner, каждый вывод пишется в `ownerOut` (USDC-эквивалент) и событие
  `OwnerWithdraw`, виден в `dashboard().ownerOut_`.
- Честное правило: вывод уменьшает HardNAV ровно на выведенное (доказано
  форк-ассёртами `hardNAV == hardPre - amount`). Это НЕ прибыль и НЕ realized —
  просто перемещение своих денег. Гарантии инвестора после выводов
  перепроверяются тем же тестом.

## 15. Состав папки

- `foundry.toml` — solc 0.8.24, optimizer, via_ir
- `src/` — 6 контрактов (см. §3)
- `test/` — `RubEconomyFork.t.sol`, `RubSim.t.sol`
- `out/` — собранные артефакты (байткод/ABI), пересобираются `forge build`
