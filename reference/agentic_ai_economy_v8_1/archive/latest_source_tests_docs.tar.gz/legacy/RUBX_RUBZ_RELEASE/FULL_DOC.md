# RUBX/RUBZ — полная документация системы (свод)

Дата: 2026-09-16. Релиз: `RUBX_RUBZ_RELEASE`. Основные документы:
`DOCUMENTATION.md` (архитектура/механики/инварианты), `ADDRESSES.md`
(Base mainnet деплой), `CYCLES.md` (live-прогоны), `MULTIPLIER_MATH.md`
(математика множителя HardNAV/TVL). Этот файл — индекс и свод состояния.

## 1. Живое состояние Base mainnet (dashboard, 2026-09-16)

| Показатель | Значение |
|---|---|
| hardNAV | $1.502622 (1502622 micro) |
| markNAV | $2.241863 |
| grossTVL | $1.280155 |
| treasury | 939990 USDC + 9e12 WETH-wei |
| pxX / pxZ | $0.0546 / $0.0542 (таргет $1, дисконт — buyBurn зона) |
| supply RUBX/RUBZ | 6.81e18 / 6.81e18 |
| realized / paidYield | 0 / 0 |
| cycles | 2 (deposits=400=principalOut, shortfall=10) |
| ownerOut | 0 (выводов не было) |

V3-ориентир: slot0 sqrt=3.888e24, tick −198454 → рынок ≈ $2420/ETH.

## 2. Контракты (адреса, owner-выходы)

| Контракт | Адрес | Вывод овнера |
|---|---|---|
| RubEconomy | `0xd798…3f0dc` | `rescue`, `treasuryWithdraw`, `poolWithdraw`, `ownerOut` |
| RubTreasury | `0xa8AE…57a64` | `send` (owner=Economy) |
| RubPool ×5 | `0x6e76…1e84`, `0x7f3d…0e87a`, `0xa70e…0fe33`, `0xb328…4a75e`, `0x56fd…dce74` | `removeTo` (owner=Economy) |
| RUBX | `0xf3E9…21Afe9` | `rescueForeign`, `setMinter` |
| RUBZ | `0xf29C…f212E` | `rescueForeign`, `setMinter` |

⚠️ Live-версия Economy/Treasury/Pool задеплоена ДО патча выводов: у живых
контрактов прямой кран treasury→deployer отсутствует (owner=Economy без
`treasuryWithdraw`). Патч в коде и RELEASE — работает для будущих деплоев
(решение зафиксировано: «оставляем как есть»).

## 3. Инварианты (проверяются форк-тестом)

1. Principal инвестора возвращается 1:1 (`totalDeposits == totalPrincipalOut`).
2. `paidYield ≤ realized` — доход только из реального заработка.
3. Floor резерва не пробивается (`freeU ≥ reserveFloorU`).
4. MINT/ADDLP/внутренний арбитраж — HardNAV-neutral (не прибыль).
5. Перемещения пул↔treasury не меняют HardNAV.
6. `hardNAV()` равен независимому пересчёту по балансам (учёт закрыт).
7. Owner-вывод уменьшает HardNAV ровно на выведенное (`ownerOut`-трекинг).

## 4. Результаты прогонов

| Прогон | Результат |
|---|---|
| Сим 10 циклов | ΔHard $3.14/$1 деп., ΔTVL $9.09/$1 (внешний флоу финансирует) |
| Сим 1k/10k/100k | PASS, инварианты держат |
| Сим 1M (anvil 20×50k) | Hard $2.96M, yield ровно таргет, shortfall $600 |
| Тюнер 2×2×2 | PASS (max Hard при покрытии ≥95%) |
| Форк Base 20 циклов | PASS: Hard $157.03→$173.46, yield $0.40 из realized $14.41 |
| Live прогон #1 | Hard $1.501022→$1.502422, множитель 1.00× |
| Live прогон #2 | Hard→$1.502622, buyBurn двинул цены к пегу, arb честно отказал (110bps<fees) |

## 5. Экономическое ядро

- Realized = только внешнее: proto-fee 5bps чужого объёма, осевший спред,
  внешний yield (`noteTreasury/bookYield`), чистые внешние покупки.
- MINT+SELL/BUY+BURN/ADDLP/арбитраж/ребаланс — управление ликвидностью,
  в HardNAV дают ноль.
- Investor-цикл: адаптивный маршрут (треугольник при просадке ≤2000 micro,
  иначе круг XU), principal 1:1, yield `min(0.02, realized−paid, freeAboveFloor)`,
  режимы 0=урезать/1=отложить/2=выкл.
- Параметры живые (`setParams`): thr 200/200 bps, buyCap 20%, reinvest 25%,
  arbMin 30 bps, rebThr 500 bps, floor 200000, цикл 200/40.

## 6. Воспроизведение

```powershell
forge build --root "C:\Users\Shtenco\Desktop\RUBX_RUBZ_RELEASE"
forge test --root ... --match-test "testSim10|testSim1000|testTuner"
forge test --root ... --fork-url https://mainnet.base.org --match-test testForkEconomy
# 1M: anvil --gas-limit 2000000000; deploy RubSimState; init; 20x advance(50000); seal
```
