// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Pure-math mirror of RubEconomy for long-horizon simulation (no ERC20s).
/// Units: RUBX/RUBZ/WETH in wei (1e18), USDC in micro (1e6), prices in
/// micro-USDC per 1e18 token. All cycle logic matches RubEconomy 1:1 except
/// token transfers (state is plain integers).
library RubSimLib {
    uint256 constant BPS = 10000;

    struct Prm {
        uint256 sellThrBps; uint256 buyThrBps;
        uint256 microMintX; uint256 microMintZ; uint256 microSizeU;
        uint256 buyCapBps; uint256 reinvestBps;
        uint256 arbMinBps; uint256 rebThrBps; uint256 dustTolU; uint256 maxSlipBps;
        uint256 microRebMax; uint256 rebCooldown;
        uint256 ownerTakeU; // per-controller-tick discretionary owner take (default 0)
        uint256 yieldTarget; uint256 investorIn; uint256 reserveFloorU;
        uint8 payMode;
        uint256 targetX; uint256 targetZ;
        uint256 wethPx; uint256 baseVolU; uint256 yieldC; // per-cycle externals
        uint256 depthRefU; // USDC-depth reference for recursive volume scaling
    }

    struct S {
        // pools raw: [XU(x,u), ZU(z,u), XZ(x,z), XC(x,c), ZC(z,c)]
        uint256 rxuX; uint256 rxuU; uint256 rzuZ; uint256 rzuU;
        uint256 rxzX; uint256 rxzZ; uint256 rxcX; uint256 rxcC;
        uint256 rzcZ; uint256 rzcC;
        uint256 supX; uint256 supZ;
        uint256 treasU; uint256 treasC;
        uint256 realized; uint256 paidY; uint256 owedY;
        uint256 fees; uint256 arbVol; uint256 paidP; uint256 deposits;
        uint256 shortfalls; uint256 cycles;
        uint256 mintX; uint256 mintZ; uint256 burnX; uint256 burnZ; uint256 addlp;
        uint256 lastReb; uint256 ownerOut;
    }

    struct Snap {
        uint256 cycle; uint256 hard; uint256 mark; uint256 tvl;
        uint256 freeU; uint256 paidY; uint256 supX; uint256 supZ;
    }

    function pxX(S memory s) internal pure returns (uint256) {
        return (s.rxuU * 1e18) / s.rxuX;
    }
    function pxZ(S memory s) internal pure returns (uint256) {
        return (s.rzuU * 1e18) / s.rzuZ;
    }
    function pxXviaZ(S memory s) internal pure returns (uint256) {
        return (s.rxzZ * pxZ(s)) / s.rxzX;
    }

    function hard(S memory s, uint256 wethPx) internal pure returns (uint256 h) {
        h = s.treasU + (s.treasC * wethPx) / 1e18
            + s.rxuU + s.rzuU
            + (s.rxcC * wethPx) / 1e18 + (s.rzcC * wethPx) / 1e18;
    }
    function tvl(S memory s, uint256 wethPx) internal pure returns (uint256 t) {
        uint256 px = pxX(s);
        uint256 pz = pxZ(s);
        t = (s.rxuX * px) / 1e18 + s.rxuU
            + (s.rzuZ * pz) / 1e18 + s.rzuU
            + (s.rxzX * px) / 1e18 + (s.rxzZ * pz) / 1e18
            + (s.rxcX * px) / 1e18 + (s.rxcC * wethPx) / 1e18
            + (s.rzcZ * pz) / 1e18 + (s.rzcC * wethPx) / 1e18;
    }
    function mark(S memory s, uint256 wethPx) internal pure returns (uint256) {
        return tvl(s, wethPx) + s.treasU + (s.treasC * wethPx) / 1e18
            + (0); // pools are 100% protocol-owned, counted in tvl()
    }

    /// One full controller cycle. Deterministic; no timestamps used.
    /// Core loop (volume/yield/investor) runs every cycle; heavy controller
    /// (arb/mint/buy/addlp) runs every 4th cycle to keep 1M-cycle gas bounded.
    function step(S memory s, Prm memory p, uint256 seed) internal pure {
        bool ctl = (s.cycles % 4) == 0;
        // 1) external taker volume: round-trip leaves proto+LP fees in pools.
        //    Model as: trader swaps volU/2 USDC->X then back; net reserve delta
        //    = fees only (principal returns to trader).
        // Recursive loop: depth -> volume -> fees -> depth. Volume scales
        // with USDC depth vs reference, clamped to avoid death spiral.
        uint256 depth = s.rxuU + s.rzuU;
        uint256 vol = (p.baseVolU * depth) / p.depthRefU;
        if (vol < p.baseVolU / 2) vol = p.baseVolU / 2;
        uint256 volCap = p.baseVolU * 8;
        if (vol > volCap) vol = volCap;
        vol = vol + (s.cycles % 7) * (vol / 12); // deterministic wobble
        uint256 half = vol / 2;
        // buy leg U->X with proto
        {
            uint256 z = (half * 9970) / 10000;
            uint256 xOut = (s.rxuX * z) / (s.rxuU + z);
            uint256 fee = (half * 5) / 10000;
            s.rxuU += half - fee;
            s.rxuX -= xOut;
            s.treasU += fee; s.realized += fee; s.fees += fee;
            // sell leg X->U with proto (round trip)
            uint256 z2 = (xOut * 9970) / 10000;
            uint256 uOut = (s.rxuU * z2) / (s.rxuX + z2);
            uint256 fee2 = (xOut * 5) / 10000; // proto in X: internal, no realized credit
            fee2;
            s.rxuX += xOut;
            s.rxuU -= uOut;
            // trader P&L vs fees ignored (external actor); pool keeps spread+fees
            seed;
        }
        // 2) collateral yield accrues to treasury (external source)
        if (p.yieldC > 0) {
            s.treasC += p.yieldC;
            s.realized += (p.yieldC * p.wethPx) / 1e18;
        }
        // 3) internal triangular arb (alignment only, no realized credit)
        if (ctl) {
            uint256 a = pxX(s);
            uint256 b = pxXviaZ(s);
            uint256 hi = a > b ? a : b;
            uint256 lo = a > b ? b : a;
            uint256 sp = ((hi - lo) * BPS) / hi;
            if (sp >= p.arbMinBps) {
                uint256 inU = p.microSizeU;
                if (inU > s.treasU / 4) inU = s.treasU / 4;
                if (inU >= 1000 && s.rxuU > inU && s.rxzX > 0 && s.rzuZ > 0) {
                    uint256 z1 = (inU * 9970) / 10000;
                    uint256 xo = (s.rxuX * z1) / (s.rxuU + z1);
                    uint256 z2 = (xo * 9970) / 10000;
                    uint256 zo = (s.rxzZ * z2) / (s.rxzX + z2);
                    uint256 z3 = (zo * 9970) / 10000;
                    uint256 uo = (s.rzuU * z3) / (s.rzuZ + z3);
                    if (uo > inU && ((inU * BPS) / uo) >= BPS - p.maxSlipBps) {
                        // funding FIRST (mirrors on-chain treasury.send): else inU is printed
                        require(s.treasU >= inU, "SIM: arb funding");
                        s.treasU -= inU;
                        s.rxuU += inU; s.rxuX -= xo;
                        s.rxzX += xo; s.rxzZ -= zo;
                        s.rzuZ += zo; s.rzuU -= uo;
                        s.treasU += uo;
                        s.arbVol += uo;
                    }
                }
            }
        }
        // 4) mint+sell micro on premium (relocates, no realized credit)
        if (ctl && pxX(s) > (p.targetX * (BPS + p.sellThrBps)) / BPS && s.rxuX > 0) {
            // depth cap: never extract more than ~1% of pool USDC side
            uint256 m = p.microMintX;
            uint256 capX = ((s.rxuU / 100) * 1e18) / pxX(s);
            if (m > capX) m = capX;
            if (m > 0) {
                s.supX += m; s.mintX += m;
                uint256 z = (m * 9970) / 10000;
                uint256 uo = (s.rxuU * z) / (s.rxuX + z);
                s.rxuX += m; s.rxuU -= uo;
                s.treasU += uo;
            }
        }
        if (ctl && pxZ(s) > (p.targetZ * (BPS + p.sellThrBps)) / BPS && s.rzuZ > 0) {
            uint256 m = p.microMintZ;
            uint256 capZ = ((s.rzuU / 100) * 1e18) / pxZ(s);
            if (m > capZ) m = capZ;
            if (m > 0) {
                s.supZ += m; s.mintZ += m;
                uint256 z = (m * 9970) / 10000;
                uint256 uo = (s.rzuU * z) / (s.rzuZ + z);
                s.rzuZ += m; s.rzuU -= uo;
                s.treasU += uo;
            }
        }
        // 5) buy+burn capped
        if (ctl && pxX(s) < (p.targetX * (BPS - p.buyThrBps)) / BPS) {
            uint256 cap = (s.treasU * p.buyCapBps) / BPS;
            uint256 spend = 50000;
            if (spend > cap) spend = cap;
            if (spend > 0 && s.treasU - spend >= p.reserveFloorU && s.rxuU > spend) {
                s.treasU -= spend;
                uint256 z = (spend * 9970) / 10000;
                uint256 xo = (s.rxuX * z) / (s.rxuU + z);
                s.rxuU += spend; s.rxuX -= xo;
                s.supX -= xo; s.burnX += xo;
            }
        }
        // 6b) rebalance XZ toward 1:1 when spread exceeds rebThr (mint both,
        // HardNAV-neutral; nominal TVL only)
        if (ctl) {
            uint256 _a = pxX(s);
            uint256 _b = pxXviaZ(s);
            uint256 _hi = _a > _b ? _a : _b;
            uint256 _lo = _a > _b ? _b : _a;
            if (_hi > 0 && (((_hi - _lo) * BPS) / _hi) >= p.rebThrBps
                && s.cycles >= s.lastReb + p.rebCooldown) {
                uint256 _m = s.rxzX < s.rxzZ ? s.rxzX / 20 : s.rxzZ / 20;
                if (_m > p.microRebMax) _m = p.microRebMax;
                if (_m > 0) {
                    s.supX += _m; s.supZ += _m;
                    s.mintX += _m; s.mintZ += _m;
                    s.rxzX += _m; s.rxzZ += _m;
                    s.lastReb = s.cycles;
                }
            }
        }
        // 6a) discretionary owner take (modeled; default 0). Reduces HardNAV
        // 1:1 by construction; tracked in ownerOut, never from realized.
        if (ctl && p.ownerTakeU > 0) {
            uint256 t = p.ownerTakeU;
            if (t > s.treasU) t = s.treasU;
            s.treasU -= t;
            s.ownerOut += t;
        }
        // 6) ADDLP from real free profit only
        if (ctl) {
            uint256 free = s.realized > s.paidY ? s.realized - s.paidY : 0;
            uint256 budget = (free * p.reinvestBps) / BPS;
            uint256 amt = 20000;
            if (amt > budget) amt = budget;
            if (amt > s.treasU) amt = s.treasU;
            if (amt >= 1000 && s.rxuU > 0) {
                uint256 xn = (amt * s.rxuX) / s.rxuU;
                s.treasU -= amt;
                s.rxuU += amt; s.rxuX += xn;
                s.supX += xn; s.mintX += xn; s.addlp += amt;
            }
        }
        // 7) investor cycle: ADAPTIVE route. Triangular U->X->Z->U while its
        //    quoted shortfall <= dustTolU, else fallback XU round-trip
        //    U->X->U (bounded ~60bps loss, never touches XZ).
        //    Principal IN returned from route output + treasury cover.
        //    Route dust goes to treasury WITHOUT realized credit (internal).
        {
            uint256 IN = p.investorIn;
            s.deposits += IN;
            s.treasU += IN; // deposit arrives (returned below; conservation)
            // quote triangular
            uint256 z1 = (IN * 9970) / 10000;
            uint256 xo = s.rxuX > 0 ? (s.rxuX * z1) / (s.rxuU + z1) : 0;
            uint256 z2 = (xo * 9970) / 10000;
            uint256 zo = s.rxzX > 0 ? (s.rxzZ * z2) / (s.rxzX + z2) : 0;
            uint256 z3 = (zo * 9970) / 10000;
            uint256 uoT = s.rzuZ > 0 ? (s.rzuU * z3) / (s.rzuZ + z3) : 0;
            uint256 uo;
            if (uoT + p.dustTolU >= IN) {
                s.rxuU += IN; s.rxuX -= xo;
                s.rxzX += xo; s.rxzZ -= zo;
                s.rzuZ += zo; s.rzuU -= uoT;
                uo = uoT;
            } else {
                // fallback: direct XU round-trip
                uint256 xd = xo; // same first leg quote
                s.rxuU += IN; s.rxuX -= xd;
                uint256 zb = (xd * 9970) / 10000;
                uint256 ud = (s.rxuU * zb) / (s.rxuX + zb);
                s.rxuX += xd; s.rxuU -= ud;
                uo = ud;
            }
            s.paidP += IN;
            s.treasU -= IN; // principal back out (net of deposit: zero)
            if (uo >= IN) {
                s.treasU += (uo - IN); // favorable-route dust to treasury
            } else {
                uint256 short_ = IN - uo;
                s.shortfalls += short_;
                uint256 above = s.treasU > p.reserveFloorU ? s.treasU - p.reserveFloorU : 0;
                require(above >= short_, "SIM: floor");
                s.treasU -= short_; // reserve covers route slippage
            }
            // yield only from realized
            uint256 avail = s.realized > s.paidY ? s.realized - s.paidY : 0;
            uint256 pay = p.yieldTarget;
            if (p.payMode == 2) pay = 0;
            else if (pay > avail) {
                if (p.payMode == 1) { s.owedY += (pay - avail); pay = avail; }
                else pay = avail;
            }
            uint256 above2 = s.treasU > p.reserveFloorU ? s.treasU - p.reserveFloorU : 0;
            if (pay > above2) {
                if (p.payMode == 1) { s.owedY += (pay - above2); pay = above2; }
                else pay = above2;
            }
            s.paidY += pay;
            s.treasU -= pay;
        }
        s.cycles += 1;
    }

    function run(S memory s, Prm memory p, uint256 n, uint256 stride, Snap[] memory out)
        internal pure returns (uint256 nSnaps)
    {
        uint256 j;
        for (uint256 i = 0; i < n; i++) {
            step(s, p, i);
            if ((s.cycles % stride) == 0) {
                out[j] = Snap(s.cycles, hard(s, p.wethPx), mark(s, p.wethPx),
                    tvl(s, p.wethPx), s.treasU, s.paidY, s.supX, s.supZ);
                j++;
            }
        }
        return j;
    }
}
