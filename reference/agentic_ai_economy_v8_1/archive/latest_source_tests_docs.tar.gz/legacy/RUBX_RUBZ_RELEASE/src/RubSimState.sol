// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RubSimLib} from "./RubSim.sol";

/// Stateful long-run harness: persists simulator state in storage so 1M
/// cycles can be executed as N sequential transactions (e.g. 20 x 50k).
/// Each advance() loads state to MEMORY once, loops, stores back once —
/// per-cycle cost is memory-only (~6k gas). Driven off-chain (anvil/cast).
/// Snapshots every 1000th cycle are stored (1000 entries for 1M run).
contract RubSimState {
    RubSimLib.S public s;
    RubSimLib.Prm public p;
    bool public initialized;
    RubSimLib.Snap[] public snaps;
    uint256 public constant STRIDE = 1000;

    event Advanced(uint256 cycles, uint256 hard, uint256 tvl, uint256 paidY, uint256 realized);
    event Sealed(uint256 cycles, uint256 hard, uint256 tvl, uint256 paidY, uint256 realized);

    function init() external {
        require(!initialized, "SS: init");
        initialized = true;
        p = RubSimLib.Prm({
            sellThrBps: 200, buyThrBps: 200,
            microMintX: 5e18, microMintZ: 5e18, microSizeU: 50000,
            buyCapBps: 200, reinvestBps: 2500,
            arbMinBps: 30, rebThrBps: 500, dustTolU: 2000,
            microRebMax: 2e18, rebCooldown: 200, maxSlipBps: 100,
            ownerTakeU: 0,
            yieldTarget: 20000, investorIn: 100000,
            reserveFloorU: 500000, payMode: 0,
            targetX: 1000000, targetZ: 1000000,
            wethPx: 2400_000_000, baseVolU: 100_000_000, yieldC: 4_000_000_000_000,
            depthRefU: 1_000_000_000
        });
        uint256 wpx = 2400_000_000;
        uint256 wFor20 = (20_000_000 * 1e18) / wpx;
        s.rxuX = 500e18; s.rxuU = 500_000_000;
        s.rzuZ = 500e18; s.rzuU = 500_000_000;
        s.rxzX = 500e18; s.rxzZ = 500e18;
        s.rxcX = 20e18;  s.rxcC = wFor20;
        s.rzcZ = 20e18;  s.rzcC = wFor20;
        s.supX = 500e18 + 500e18 + 20e18;
        s.supZ = 500e18 + 500e18 + 20e18;
        s.treasU = 2_000_000;
    }

    /// Advance n cycles entirely in memory; single storage write-back.
    function advance(uint256 n) external {
        require(initialized, "SS: init");
        RubSimLib.S memory m;
        m.rxuX = s.rxuX; m.rxuU = s.rxuU;
        m.rzuZ = s.rzuZ; m.rzuU = s.rzuU;
        m.rxzX = s.rxzX; m.rxzZ = s.rxzZ;
        m.rxcX = s.rxcX; m.rxcC = s.rxcC;
        m.rzcZ = s.rzcZ; m.rzcC = s.rzcC;
        m.supX = s.supX; m.supZ = s.supZ;
        m.treasU = s.treasU; m.treasC = s.treasC;
        m.realized = s.realized; m.paidY = s.paidY; m.owedY = s.owedY;
        m.fees = s.fees; m.arbVol = s.arbVol; m.paidP = s.paidP;
        m.deposits = s.deposits; m.shortfalls = s.shortfalls; m.cycles = s.cycles;
        m.mintX = s.mintX; m.mintZ = s.mintZ;
        m.burnX = s.burnX; m.burnZ = s.burnZ; m.addlp = s.addlp;
        m.lastReb = s.lastReb; m.ownerOut = s.ownerOut;
        RubSimLib.Prm memory pm = p;
        for (uint256 i = 0; i < n; i++) {
            RubSimLib.step(m, pm, i);
            if ((m.cycles % STRIDE) == 0) {
                snaps.push(RubSimLib.Snap(m.cycles, RubSimLib.hard(m, pm.wethPx),
                    RubSimLib.mark(m, pm.wethPx), RubSimLib.tvl(m, pm.wethPx),
                    m.treasU, m.paidY, m.supX, m.supZ));
            }
        }
        s.rxuX = m.rxuX; s.rxuU = m.rxuU;
        s.rzuZ = m.rzuZ; s.rzuU = m.rzuU;
        s.rxzX = m.rxzX; s.rxzZ = m.rxzZ;
        s.rxcX = m.rxcX; s.rxcC = m.rxcC;
        s.rzcZ = m.rzcZ; s.rzcC = m.rzcC;
        s.supX = m.supX; s.supZ = m.supZ;
        s.treasU = m.treasU; s.treasC = m.treasC;
        s.realized = m.realized; s.paidY = m.paidY; s.owedY = m.owedY;
        s.fees = m.fees; s.arbVol = m.arbVol; s.paidP = m.paidP;
        s.deposits = m.deposits; s.shortfalls = m.shortfalls; s.cycles = m.cycles;
        s.mintX = m.mintX; s.mintZ = m.mintZ;
        s.burnX = m.burnX; s.burnZ = m.burnZ; s.addlp = m.addlp;
        s.lastReb = m.lastReb; s.ownerOut = m.ownerOut;
        emit Advanced(s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized);
    }

    function seal() external {
        require(initialized, "SS: init");
        require(s.paidY <= s.realized, "SS: yield exceeds realized");
        require(s.treasU >= p.reserveFloorU, "SS: floor breached");
        emit Sealed(s.cycles, RubSimLib.hard(s, p.wethPx),
            RubSimLib.tvl(s, p.wethPx), s.paidY, s.realized);
    }

    function result() external view returns (
        uint256 cycles, uint256 hardEnd, uint256 tvlEnd, uint256 paidY,
        uint256 realized, uint256 supX, uint256 supZ, uint256 nSnaps,
        uint256 treasU, uint256 shortfalls, uint256 paidP
    ) {
        cycles = s.cycles;
        hardEnd = RubSimLib.hard(s, p.wethPx);
        tvlEnd = RubSimLib.tvl(s, p.wethPx);
        paidY = s.paidY; realized = s.realized;
        supX = s.supX; supZ = s.supZ; nSnaps = snaps.length;
        treasU = s.treasU; shortfalls = s.shortfalls; paidP = s.paidP;
    }
}
