// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20P {
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

interface INotify {
    function notifyProto(address token, uint256 amount) external;
}

/// Constant-product AMM (x*y=k), fee 30 bps total, 5 bps protocol fee to treasury.
/// Protocol fee applies ONLY to external flow (withProto=true). Own ops (owner
/// as trader: seeding, investor route, controller) pay LP fee only, so the
/// system can never mint "realized profit" out of its own volume.
contract RubPool {
    address public immutable tokenA;
    address public immutable tokenB;
    uint8 public immutable decA;
    uint8 public immutable decB;
    uint256 public resA;
    uint256 public resB;
    uint256 public constant FEE_TOTAL_BPS = 30;
    uint256 public constant FEE_PROTO_BPS = 5;
    address public owner;
    address public treasury;

    event Swap(address indexed trader, bool aForB, uint256 amountIn, uint256 amountOut, uint256 protoFee);
    event Liquidity(address indexed from, uint256 a, uint256 b);
    event Remove(address indexed to, uint256 a, uint256 b);

    constructor(address a, address b, uint8 da, uint8 db, address owner_, address treasury_) {
        tokenA = a; tokenB = b; decA = da; decB = db; owner = owner_; treasury = treasury_;
    }

    modifier onlyOwner() { require(msg.sender == owner, "POOL: only owner"); _; }

    function setTreasury(address t) external onlyOwner { treasury = t; }

    function getReserves() external view returns (uint256, uint256) { return (resA, resB); }

    /// Raw quote, no state change. out = resOut*z/(resIn+z), z=in*9970/10000.
    function quoteAForB(uint256 aIn) external view returns (uint256 out) {
        uint256 z = (aIn * (10000 - FEE_TOTAL_BPS)) / 10000;
        out = (resB * z) / (resA + z);
    }

    function quoteBForA(uint256 bIn) external view returns (uint256 out) {
        uint256 z = (bIn * (10000 - FEE_TOTAL_BPS)) / 10000;
        out = (resA * z) / (resB + z);
    }

    function addLiquidity(uint256 a, uint256 b) external {
        require(IERC20P(tokenA).transferFrom(msg.sender, address(this), a), "POOL: tA");
        require(IERC20P(tokenB).transferFrom(msg.sender, address(this), b), "POOL: tB");
        resA += a;
        resB += b;
        emit Liquidity(msg.sender, a, b);
    }

    function _takeProto(address token, uint256 inAmt, bool withProto) internal returns (uint256 proto) {
        if (withProto && treasury != address(0)) {
            proto = (inAmt * FEE_PROTO_BPS) / 10000;
            if (proto > 0) {
                require(IERC20P(token).transfer(treasury, proto), "POOL: proto");
                INotify(owner).notifyProto(token, proto);
            }
        }
    }

    function swapAForB(uint256 aIn, bool withProto) external returns (uint256 out) {
        uint256 z = (aIn * (10000 - FEE_TOTAL_BPS)) / 10000;
        out = (resB * z) / (resA + z);
        require(out > 0 && out < resB, "POOL: OUT");
        require(IERC20P(tokenA).transferFrom(msg.sender, address(this), aIn), "POOL: in");
        uint256 proto = _takeProto(tokenA, aIn, withProto);
        resA += (aIn - proto);
        resB -= out;
        require(IERC20P(tokenB).transfer(msg.sender, out), "POOL: out");
        emit Swap(msg.sender, true, aIn, out, proto);
    }

    function swapBForA(uint256 bIn, bool withProto) external returns (uint256 out) {
        uint256 z = (bIn * (10000 - FEE_TOTAL_BPS)) / 10000;
        out = (resA * z) / (resB + z);
        require(out > 0 && out < resA, "POOL: OUT");
        require(IERC20P(tokenB).transferFrom(msg.sender, address(this), bIn), "POOL: in");
        uint256 proto = _takeProto(tokenB, bIn, withProto);
        resB += (bIn - proto);
        resA -= out;
        require(IERC20P(tokenA).transfer(msg.sender, out), "POOL: out");
        emit Swap(msg.sender, false, bIn, out, proto);
    }

    /// Owner-only reserve move (treasury rebalancing). Does NOT create profit:
    /// HardNAV counts pool + treasury together.
    function removeTo(address to, uint256 a, uint256 b) external onlyOwner {
        require(a <= resA && b <= resB, "POOL: res");
        resA -= a;
        resB -= b;
        if (a > 0) require(IERC20P(tokenA).transfer(to, a), "POOL: tA");
        if (b > 0) require(IERC20P(tokenB).transfer(to, b), "POOL: tB");
        emit Remove(to, a, b);
    }
}
