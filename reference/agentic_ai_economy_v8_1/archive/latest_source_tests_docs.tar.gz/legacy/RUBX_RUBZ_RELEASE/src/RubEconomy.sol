// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RubToken} from "./RubToken.sol";
import {RubPool} from "./RubPool.sol";
import {RubTreasury} from "./RubTreasury.sol";

interface IERC20E {
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

/// Five-pool internal economy with honest HardNAV accounting.
///
/// Pools (all 100% protocol-owned):
///   0 P_XU : RUBX / USDC      4 P_XC : RUBX / COLLAT (WETH)
///   1 P_ZU : RUBZ / USDC      5 P_ZC : RUBZ / COLLAT (WETH)
///   2 P_XZ : RUBX / RUBZ
///
/// Accounting rules (enforced, tested):
/// - MINT alone never changes HardNAV (internal tokens excluded).
/// - Moving USDC/COLLAT pool <-> treasury never changes HardNAV (both counted).
/// - Internal arbitrage never changes HardNAV (value only relocates).
/// - HardNAV grows ONLY from: external proto fees, booked external yield,
///   and external demand flow measured via poke deltas.
/// - Investor yield is paid ONLY from realized (cumulative external income
///   minus already-paid yield), never from the next deposit or the floor reserve.
contract RubEconomy {
    uint256 constant BPS = 10000;

    RubToken public immutable rubx;
    RubToken public immutable rubz;
    address public immutable usdc;
    address public immutable collat;
    RubTreasury public immutable treasury;
    address public owner;

    RubPool[5] public pools; // XU, ZU, XZ, XC, ZC
    bool public linked;

    uint256 public wethPx;   // micro-USDC per 1e18 wei, set from V3 once at setup
    uint256 public targetX = 1000000; // $1 in micro per 1e18
    uint256 public targetZ = 1000000;

    struct Params {
        uint256 sellThrBps;   // mint+sell when px > target*(1+thr)
        uint256 buyThrBps;    // buy+burn when px < target*(1-thr)
        uint256 microMintX;   // raw RUBX per mintSell micro-trade
        uint256 microMintZ;
        uint256 microSizeU;   // micro-USDC size reference for arb sizing
        uint256 buyCapBps;    // max treasury-free spend per buyBurn
        uint256 reinvestBps;  // share of free profit routed to ADDLP
        uint256 arbMinBps;    // min cross-route spread to arb
        uint256 rebThrBps;    // spread above which XZ is rebalanced (not arbed)
        uint256 dustTolU;     // max triangular shortfall before fallback route
        uint256 microRebMax;  // max mint per rebalance side (anti-printer cap)
        uint256 rebCooldown;  // min cycles between rebalances
        uint256 maxSlipBps;   // max acceptable slippage guard
        uint256 yieldTarget;  // micro-USDC per investor cycle, e.g. 20000
        uint256 investorIn;   // micro-USDC per cycle, e.g. 100000
        uint256 reserveFloorU;// micro-USDC floor never spent
        uint8 payMode;        // 0=reduce(partial), 1=defer(owed), 2=off
    }
    Params public params;

    // ---- accounting (all in micro-USDC unless noted) ----
    uint256 public realized;        // cumulative REAL external income
    uint256 public paidYield;       // cumulative yield paid to investors
    uint256 public owedYield;       // deferred yield (payMode=1)
    uint256 public totalDeposits;   // cumulative investor principal in
    uint256 public totalPrincipalOut;
    uint256 public totalShortfall;  // principal covered from reserve (bounded)
    uint256 public feesAcc;         // proto fees from external flow
    uint256 public arbAcc;          // internal alignment volume (info only, NOT profit)
    uint256 public mintAccX;        // raw RUBX minted (info)
    uint256 public mintAccZ;
    uint256 public burnAccX;        // raw burned (info)
    uint256 public burnAccZ;
    uint256 public addlpAcc;        // micro-USDC value routed to ADDLP
    uint256 public cycles;
    uint256 public ownerOut;        // cumulative USDC-micro value pulled by owner (transparency)
    uint256 private snapU;          // treasury USDC snapshot for yield booking
    uint256 private snapC;          // treasury COLLAT snapshot for yield booking
    bool private snapped;
    uint256 public lastRebCycle;    // cooldown for XZ rebalancing

    event InvestorResult(uint256 indexed cycle, uint256 inU, uint256 outU, uint256 yieldPaid, uint256 principalOut);
    event ArbResult(string route, uint256 inU, uint256 outU, uint256 spreadBps);
    event MintSell(bool isX, uint256 minted, uint256 usdcOut);
    event BuyBurn(bool isX, uint256 usdcIn, uint256 burned);
    event Addlp(string pool, uint256 usdcValue);
    event YieldBooked(uint256 usdcValue);
    event OwnerWithdraw(string indexed kind, address indexed token, address indexed to, uint256 amount, uint256 usdcValue);
    event Dashboard(uint256 hardNAV, uint256 markNAV, uint256 tvl, uint256 freeU, uint256 freeC, uint256 pxX, uint256 pxZ, uint256 supX, uint256 supZ);

    modifier onlyOwner() { require(msg.sender == owner, "ECO: only owner"); _; }
    modifier onlyPool() {
        bool ok = msg.sender == address(pools[0]) || msg.sender == address(pools[1])
            || msg.sender == address(pools[2]) || msg.sender == address(pools[3])
            || msg.sender == address(pools[4]);
        require(ok, "ECO: only pool");
        _;
    }

    constructor(address rubx_, address rubz_, address usdc_, address collat_, address treasury_, address owner_) {
        rubx = RubToken(rubx_); rubz = RubToken(rubz_);
        usdc = usdc_; collat = collat_;
        treasury = RubTreasury(treasury_);
        owner = owner_;
        params = Params({
            sellThrBps: 200, buyThrBps: 200,
            microMintX: 5e18, microMintZ: 5e18, microSizeU: 50000,
            buyCapBps: 200, reinvestBps: 2500,
            arbMinBps: 30, rebThrBps: 500, dustTolU: 2000,
            microRebMax: 2e18, rebCooldown: 200, maxSlipBps: 100,
            yieldTarget: 20000, investorIn: 100000,
            reserveFloorU: 500000, payMode: 0
        });
    }

    function linkPools(address[5] calldata p) external onlyOwner {
        for (uint256 i = 0; i < 5; i++) pools[i] = RubPool(p[i]);
        linked = true;
    }

    function setWethPx(uint256 px) external onlyOwner { wethPx = px; }
    function setTargets(uint256 tx_, uint256 tz_) external onlyOwner { targetX = tx_; targetZ = tz_; }
    function setParams(Params calldata p) external onlyOwner { params = p; }

    // ---------- INotify: protocol fee from EXTERNAL flow only ----------
    // Pools call this on every swap with withProto=true. Own ops always use
    // withProto=false, so self-volume can never inflate `realized`.
    function notifyProto(address token, uint256 amount) external onlyPool {
        if (token == usdc) { realized += amount; feesAcc += amount; }
        else if (token == collat) {
            uint256 v = (amount * wethPx) / 1e18;
            realized += v; feesAcc += v;
        }
        // RUBX/RUBZ proto is internal: ignored for realized.
    }

    // ---------- prices (micro-USDC per 1e18 token) ----------
    function pxX() public view returns (uint256) {
        (uint256 rx, uint256 ru) = pools[0].getReserves();
        require(rx > 0, "ECO: no XU liq");
        return (ru * 1e18) / rx;
    }
    function pxZ() public view returns (uint256) {
        (uint256 rz, uint256 ru) = pools[1].getReserves();
        require(rz > 0, "ECO: no ZU liq");
        return (ru * 1e18) / rz;
    }
    function pxXviaZ() public view returns (uint256) {
        (uint256 rx, uint256 rz) = pools[2].getReserves();
        require(rx > 0, "ECO: no XZ liq");
        return (rz * pxZ()) / rx;
    }
    function pxXviaC() public view returns (uint256) {
        (uint256 rx, uint256 rc) = pools[3].getReserves();
        require(rx > 0, "ECO: no XC liq");
        return (rc * wethPx) / rx;
    }
    function pxZviaC() public view returns (uint256) {
        (uint256 rz, uint256 rc) = pools[4].getReserves();
        require(rz > 0, "ECO: no ZC liq");
        return (rc * wethPx) / rz;
    }

    // ---------- metrics (all micro-USDC) ----------
    function _v18(uint256 amt, uint256 px) internal pure returns (uint256) {
        return (amt * px) / 1e18;
    }
    function _vC(uint256 amt) internal view returns (uint256) {
        return (amt * wethPx) / 1e18;
    }

    function poolTVL(uint256 i) public view returns (uint256) {
        (uint256 a, uint256 b) = pools[i].getReserves();
        if (i == 0) return _v18(a, pxX()) + b;
        if (i == 1) return _v18(a, pxZ()) + b;
        if (i == 2) return _v18(a, pxX()) + _v18(b, pxZ());
        if (i == 3) return _v18(a, pxX()) + _vC(b);
        return _v18(a, pxZ()) + _vC(b);
    }

    function grossTVL() public view returns (uint256 t) {
        for (uint256 i = 0; i < 5; i++) t += poolTVL(i);
    }

    function markNAV() public view returns (uint256 m) {
        uint256 px = pxX();
        uint256 pz = pxZ();
        m = _v18(IERC20E(address(rubx)).balanceOf(address(treasury)), px)
            + _v18(IERC20E(address(rubz)).balanceOf(address(treasury)), pz)
            + IERC20E(usdc).balanceOf(address(treasury))
            + _vC(IERC20E(collat).balanceOf(address(treasury)));
        for (uint256 i = 0; i < 5; i++) {
            (uint256 a, uint256 b) = pools[i].getReserves();
            if (i == 0) m += _v18(a, px) + b;
            else if (i == 1) m += _v18(a, pz) + b;
            else if (i == 2) m += _v18(a, px) + _v18(b, pz);
            else if (i == 3) m += _v18(a, px) + _vC(b);
            else m += _v18(a, pz) + _vC(b);
        }
    }

    /// Only real reserve: treasury USDC+COLLAT + protocol-owned USDC+COLLAT in pools.
    function hardNAV() public view returns (uint256 h) {
        h = IERC20E(usdc).balanceOf(address(treasury))
            + _vC(IERC20E(collat).balanceOf(address(treasury)));
        (uint256 a0, uint256 b0) = pools[0].getReserves(); h += b0; a0;
        (uint256 a1, uint256 b1) = pools[1].getReserves(); h += b1; a1;
        (uint256 a3, uint256 b3) = pools[3].getReserves(); h += _vC(b3); a3;
        (uint256 a4, uint256 b4) = pools[4].getReserves(); h += _vC(b4); a4;
        // P_XZ holds no real assets by construction.
    }

    function freeU() public view returns (uint256) {
        return IERC20E(usdc).balanceOf(address(treasury));
    }
    function freeC() public view returns (uint256) {
        return IERC20E(collat).balanceOf(address(treasury));
    }

    // ---------- internal helpers ----------
    function _approvePool(uint256 i, address token, uint256 a) internal {
        IERC20E(token).approve(address(pools[i]), a);
    }

    function _sweep() internal {
        uint256 u = IERC20E(usdc).balanceOf(address(this));
        if (u > 0) IERC20E(usdc).transfer(address(treasury), u);
        uint256 c = IERC20E(collat).balanceOf(address(this));
        if (c > 0) IERC20E(collat).transfer(address(treasury), c);
    }

    // ---------- seeding ----------
    function seed(
        uint256 xuX, uint256 xuU, uint256 zuZ, uint256 zuU,
        uint256 xzX, uint256 xzZ, uint256 xcX, uint256 xcC,
        uint256 zcZ, uint256 zcC, uint256 treasU, uint256 treasC
    ) external onlyOwner {
        require(linked, "ECO: link first");
        IERC20E(usdc).transferFrom(msg.sender, address(this),
            xuU + zuU + treasU);
        IERC20E(collat).transferFrom(msg.sender, address(this),
            xcC + zcC + treasC);
        rubx.mint(address(this), xuX + xzX + xcX);
        rubz.mint(address(this), zuZ + xzZ + zcZ);
        _approvePool(0, address(rubx), xuX); _approvePool(0, usdc, xuU);
        _approvePool(1, address(rubz), zuZ); _approvePool(1, usdc, zuU);
        _approvePool(2, address(rubx), xzX); _approvePool(2, address(rubz), xzZ);
        _approvePool(3, address(rubx), xcX); _approvePool(3, collat, xcC);
        _approvePool(4, address(rubz), zcZ); _approvePool(4, collat, zcC);
        pools[0].addLiquidity(xuX, xuU);
        pools[1].addLiquidity(zuZ, zuU);
        pools[2].addLiquidity(xzX, xzZ);
        pools[3].addLiquidity(xcX, xcC);
        pools[4].addLiquidity(zcZ, zcC);
        IERC20E(usdc).transfer(address(treasury), treasU);
        IERC20E(collat).transfer(address(treasury), treasC);
    }

    // ---------- external yield booking (mock oracle inflow) ----------
    // Test deals funds to treasury first, then books the delta as realized.
    function noteTreasury() external onlyOwner {
        snapU = IERC20E(usdc).balanceOf(address(treasury));
        snapC = IERC20E(collat).balanceOf(address(treasury));
        snapped = true;
    }
    function bookYield() external onlyOwner {
        require(snapped, "ECO: note first");
        snapped = false;
        uint256 u = IERC20E(usdc).balanceOf(address(treasury));
        uint256 c = IERC20E(collat).balanceOf(address(treasury));
        uint256 v;
        if (u > snapU) v += (u - snapU);
        if (c > snapC) v += ((c - snapC) * wethPx) / 1e18;
        realized += v;
        emit YieldBooked(v);
    }

    // ---------- MINT + SELL (revaluation capture, micro) ----------
    function mintSellX(uint256 amountX) external onlyOwner {
        uint256 p = pxX();
        require(p > (targetX * (BPS + params.sellThrBps)) / BPS, "ECO: no premium");
        (, uint256 ru) = pools[0].getReserves();
        uint256 capX = ((ru / 100) * 1e18) / p; // <= ~1% of pool USDC side
        if (amountX > capX) amountX = capX;
        require(amountX > 0, "ECO: capped to zero");
        rubx.mint(address(this), amountX);
        mintAccX += amountX;
        _approvePool(0, address(rubx), amountX);
        uint256 out = pools[0].swapAForB(amountX, false);
        IERC20E(usdc).transfer(address(treasury), out);
        emit MintSell(true, amountX, out);
    }
    function mintSellZ(uint256 amountZ) external onlyOwner {
        uint256 p = pxZ();
        require(p > (targetZ * (BPS + params.sellThrBps)) / BPS, "ECO: no premium");
        (, uint256 ru) = pools[1].getReserves();
        uint256 capZ = ((ru / 100) * 1e18) / p; // <= ~1% of pool USDC side
        if (amountZ > capZ) amountZ = capZ;
        require(amountZ > 0, "ECO: capped to zero");
        rubz.mint(address(this), amountZ);
        mintAccZ += amountZ;
        _approvePool(1, address(rubz), amountZ);
        uint256 out = pools[1].swapAForB(amountZ, false);
        IERC20E(usdc).transfer(address(treasury), out);
        emit MintSell(false, amountZ, out);
    }

    // ---------- BUY + BURN (bounded reserve spend) ----------
    function buyBurnX(uint256 usdcIn) external onlyOwner {
        uint256 free = freeU();
        uint256 cap = (free * params.buyCapBps) / BPS;
        require(usdcIn <= cap && free - usdcIn >= params.reserveFloorU, "ECO: cap/floor");
        require(pxX() < (targetX * (BPS - params.buyThrBps)) / BPS, "ECO: no discount");
        treasury.send(usdc, address(this), usdcIn);
        _approvePool(0, usdc, usdcIn);
        uint256 xOut = pools[0].swapBForA(usdcIn, false);
        rubx.burn(xOut);
        burnAccX += xOut;
        emit BuyBurn(true, usdcIn, xOut);
    }
    function buyBurnZ(uint256 usdcIn) external onlyOwner {
        uint256 free = freeU();
        uint256 cap = (free * params.buyCapBps) / BPS;
        require(usdcIn <= cap && free - usdcIn >= params.reserveFloorU, "ECO: cap/floor");
        require(pxZ() < (targetZ * (BPS - params.buyThrBps)) / BPS, "ECO: no discount");
        treasury.send(usdc, address(this), usdcIn);
        _approvePool(1, usdc, usdcIn);
        uint256 zOut = pools[1].swapBForA(usdcIn, false);
        rubz.burn(zOut);
        burnAccZ += zOut;
        emit BuyBurn(false, usdcIn, zOut);
    }

    // ---------- internal triangular arbitrage (price alignment only) ----------
    // Route U->X (P_XU), X->Z (P_XZ), Z->U (P_ZU). Profit stays in pools/
    // treasury as aligned reserves; HardNAV-neutral by construction.
    function arbTriangle(uint256 inU) external onlyOwner returns (uint256 outU, uint256 spreadBps) {
        uint256 pDirect = pxX();
        uint256 pVia = pxXviaZ();
        uint256 hi = pDirect > pVia ? pDirect : pVia;
        uint256 lo = pDirect > pVia ? pVia : pDirect;
        spreadBps = ((hi - lo) * BPS) / hi;
        if (spreadBps < params.arbMinBps) return (0, spreadBps);
        treasury.send(usdc, address(this), inU);
        _approvePool(0, usdc, inU);
        uint256 xOut = pools[0].swapBForA(inU, false);
        _approvePool(2, address(rubx), xOut);
        uint256 zOut = pools[2].swapAForB(xOut, false);
        _approvePool(1, address(rubz), zOut);
        outU = pools[1].swapAForB(zOut, false);
        require(outU > inU, "ECO: no profit");
        uint256 slip = ((inU * BPS) / outU);
        require(slip >= BPS - params.maxSlipBps, "ECO: slip");
        IERC20E(usdc).transfer(address(treasury), outU);
        arbAcc += outU;
        emit ArbResult("U-X-Z-U", inU, outU, spreadBps);
    }

    // ---------- ADDLP from REAL free profit only ----------
    function addlpXU(uint256 usdcAmt) external onlyOwner {
        uint256 free = freeU();
        uint256 budget = ((realized - paidYield) * params.reinvestBps) / BPS;
        require(usdcAmt <= free && usdcAmt <= budget, "ECO: addlp budget");
        (uint256 rx, uint256 ru) = pools[0].getReserves();
        uint256 xNeed = (usdcAmt * rx) / ru;
        rubx.mint(address(this), xNeed);
        mintAccX += xNeed;
        treasury.send(usdc, address(this), usdcAmt);
        _approvePool(0, address(rubx), xNeed);
        _approvePool(0, usdc, usdcAmt);
        pools[0].addLiquidity(xNeed, usdcAmt);
        addlpAcc += usdcAmt;
        emit Addlp("XU", usdcAmt);
    }
    function addlpXZ(uint256 xAmt, uint256 zAmt) external onlyOwner {
        rubx.mint(address(this), xAmt);
        rubz.mint(address(this), zAmt);
        mintAccX += xAmt; mintAccZ += zAmt;
        _approvePool(2, address(rubx), xAmt);
        _approvePool(2, address(rubz), zAmt);
        pools[2].addLiquidity(xAmt, zAmt);
        emit Addlp("XZ", 0);
    }

    /// Quote triangular route U->X->Z->U without state change.
    function quoteRoute(uint256 inU) public view returns (uint256 xOut, uint256 zOut, uint256 uOut) {
        xOut = pools[0].quoteBForA(inU);
        zOut = pools[2].quoteAForB(xOut);
        uOut = pools[1].quoteAForB(zOut);
    }

    /// Rebalance XZ toward 1:1 value at targets by minting both sides.
    /// HardNAV-neutral (no real assets move); only nominal TVL changes.
    function rebalanceXZ() external onlyOwner {
        uint256 pXv = pxXviaZ();
        uint256 pX = pxX();
        uint256 hi = pX > pXv ? pX : pXv;
        uint256 lo = pX > pXv ? pXv : pX;
        require(((hi - lo) * BPS) / hi >= params.rebThrBps, "ECO: no rebalance need");
        require(cycles >= lastRebCycle + params.rebCooldown, "ECO: rebalance cooldown");
        (uint256 rx, uint256 rz) = pools[2].getReserves();
        uint256 m = rx < rz ? rx / 20 : rz / 20; // 5% nudge, both sides equal raw
        if (m > params.microRebMax) m = params.microRebMax;
        require(m > 0, "ECO: empty pool");
        lastRebCycle = cycles;
        rubx.mint(address(this), m);
        rubz.mint(address(this), m);
        mintAccX += m; mintAccZ += m;
        _approvePool(2, address(rubx), m);
        _approvePool(2, address(rubz), m);
        pools[2].addLiquidity(m, m);
        emit Addlp("XZ-reb", 0);
    }

    // ---------- investor cycle: adaptive route, principal back, yield only from realized ----------
    // Route A (triangular U->X->Z->U) when quoted shortfall <= dustTolU,
    // else fallback B (direct XU round-trip U->X->U, bounded ~60bps loss).
    function investorCycle() external onlyOwner returns (uint256 yieldPaid, uint256 principalOut) {
        uint256 IN = params.investorIn;
        uint256 TGT = params.yieldTarget;
        IERC20E(usdc).transferFrom(msg.sender, address(this), IN);
        totalDeposits += IN;
        (,, uint256 uoQ) = quoteRoute(IN);
        uint256 uOut;
        if (uoQ + params.dustTolU >= IN) {
            _approvePool(0, usdc, IN);
            uint256 xOut = pools[0].swapBForA(IN, false);
            _approvePool(2, address(rubx), xOut);
            uint256 zOut = pools[2].swapAForB(xOut, false);
            _approvePool(1, address(rubz), zOut);
            uOut = pools[1].swapAForB(zOut, false);
        } else {
            _approvePool(0, usdc, IN);
            uint256 xOut = pools[0].swapBForA(IN, false);
            _approvePool(0, address(rubx), xOut);
            uOut = pools[0].swapAForB(xOut, false);
        }
        cycles += 1;
        // principal first
        if (uOut >= IN) {
            principalOut = IN;
            uint256 dust = uOut - IN;
            if (dust > 0) IERC20E(usdc).transfer(address(treasury), dust);
        } else {
            uint256 short_ = IN - uOut;
            totalShortfall += short_;
            uint256 free = freeU();
            require(free >= short_ + params.reserveFloorU, "ECO: reserve floor");
            treasury.send(usdc, msg.sender, IN); // full principal from route+reserve
            IERC20E(usdc).transfer(address(treasury), uOut); // route output to treasury
            // net reserve spend = short_
            principalOut = IN;
            totalPrincipalOut += principalOut;
            yieldPaid = _payYield(TGT);
            emit InvestorResult(cycles, IN, uOut, yieldPaid, principalOut);
            _sweep();
            return (yieldPaid, principalOut);
        }
        IERC20E(usdc).transfer(msg.sender, principalOut);
        totalPrincipalOut += principalOut;
        yieldPaid = _payYield(TGT);
        emit InvestorResult(cycles, IN, uOut, yieldPaid, principalOut);
        _sweep();
    }

    function _payYield(uint256 tgt) internal returns (uint256 pay) {
        uint256 avail = realized > paidYield ? realized - paidYield : 0;
        uint256 free = freeU();
        uint256 freeAbove = free > params.reserveFloorU ? free - params.reserveFloorU : 0;
        if (params.payMode == 2) return 0; // off
        if (avail == 0 || freeAbove == 0) {
            if (params.payMode == 1) owedYield += tgt; // defer
            return 0;
        }
        pay = tgt;
        if (pay > avail) {
            if (params.payMode == 1) { owedYield += (tgt - avail); pay = avail; }
            else pay = avail; // reduce
        }
        if (pay > freeAbove) {
            if (params.payMode == 1) { owedYield += (pay - freeAbove); pay = freeAbove; }
            else pay = freeAbove;
        }
        if (pay > 0) {
            paidYield += pay;
            treasury.send(usdc, msg.sender, pay);
        }
    }

    // ---------- controller: HardNAV-first decision ----------
    enum Act { None, Arb, MintSellX, MintSellZ, BuyBurnX, BuyBurnZ, Addlp, Rebalance }
    function decide() external view returns (Act act, uint256 spreadBps) {
        uint256 pXv = pxXviaZ();
        uint256 pX = pxX();
        uint256 hi = pX > pXv ? pX : pXv;
        uint256 lo = pX > pXv ? pXv : pX;
        spreadBps = ((hi - lo) * BPS) / hi;
        if (spreadBps >= params.rebThrBps) return (Act.Rebalance, spreadBps);
        if (spreadBps >= params.arbMinBps) return (Act.Arb, spreadBps);
        if (pX > (targetX * (BPS + params.sellThrBps)) / BPS) return (Act.MintSellX, spreadBps);
        uint256 pZ = pxZ();
        if (pZ > (targetZ * (BPS + params.sellThrBps)) / BPS) return (Act.MintSellZ, spreadBps);
        if (pX < (targetX * (BPS - params.buyThrBps)) / BPS) return (Act.BuyBurnX, spreadBps);
        if (pZ < (targetZ * (BPS - params.buyThrBps)) / BPS) return (Act.BuyBurnZ, spreadBps);
        uint256 free = freeU();
        uint256 budget = realized > paidYield ? ((realized - paidYield) * params.reinvestBps) / BPS : 0;
        if (free > params.reserveFloorU && budget > 0) return (Act.Addlp, spreadBps);
        return (Act.None, spreadBps);
    }

    // ---------- dashboard ----------
    struct Board {
        uint256 hardNAV; uint256 markNAV; uint256 tvl;
        uint256 treasU; uint256 treasC;
        uint256 rxuX; uint256 rxuU; uint256 rzuZ; uint256 rzuU;
        uint256 rxzX; uint256 rxzZ; uint256 rxcX; uint256 rxcC; uint256 rzcZ; uint256 rzcC;
        uint256 pxXv; uint256 pxZv; uint256 supX; uint256 supZ;
        uint256 fees; uint256 arbVol; uint256 paidY; uint256 paidP;
        uint256 realized_; uint256 cycles_; uint256 coverBps;
        uint256 ownerOut_;
    }
    function dashboard() external view returns (Board memory b) {
        (uint256 a0, uint256 b0) = pools[0].getReserves();
        (uint256 a1, uint256 b1) = pools[1].getReserves();
        (uint256 a2, uint256 b2) = pools[2].getReserves();
        (uint256 a3, uint256 b3) = pools[3].getReserves();
        (uint256 a4, uint256 b4) = pools[4].getReserves();
        b.hardNAV = hardNAV(); b.markNAV = markNAV(); b.tvl = grossTVL();
        b.treasU = freeU(); b.treasC = freeC();
        b.rxuX = a0; b.rxuU = b0; b.rzuZ = a1; b.rzuU = b1;
        b.rxzX = a2; b.rxzZ = b2; b.rxcX = a3; b.rxcC = b3; b.rzcZ = a4; b.rzcC = b4;
        b.pxXv = pxX(); b.pxZv = pxZ();
        b.supX = rubx.totalSupply(); b.supZ = rubz.totalSupply();
        b.fees = feesAcc; b.arbVol = arbAcc; b.paidY = paidYield; b.paidP = totalPrincipalOut;
        b.realized_ = realized; b.cycles_ = cycles;
        b.coverBps = params.yieldTarget == 0 ? 0 :
            ((realized > paidYield ? realized - paidYield : 0) * BPS) / params.yieldTarget;
        b.ownerOut_ = ownerOut;
    }

    /// Instant owner rescue: pull ANY stranded balance out of Economy.
    /// (Pools: removeTo / Treasury: send — both already owner-only instant.)
    function rescue(address token, address to, uint256 amount) external onlyOwner {
        require(IERC20E(token).transfer(to, amount), "ECO: rescue");
    }

    /// Instant owner withdraw FROM TREASURY to any address.
    /// Reduces HardNAV 1:1 by construction (treasury is counted),
    /// recorded in ownerOut for honest reporting.
    function treasuryWithdraw(address token, address to, uint256 amount) external onlyOwner {
        uint256 v = _usdcVal(token, amount);
        treasury.send(token, to, amount);
        ownerOut += v;
        emit OwnerWithdraw("treasury", token, to, amount, v);
    }

    /// Instant owner withdraw FROM ANY POOL to any address.
    /// Reduces HardNAV by the real-asset legs withdrawn (internal legs: 0).
    function poolWithdraw(uint256 i, address to, uint256 a, uint256 b) external onlyOwner {
        require(i < 5, "ECO: pool idx");
        pools[i].removeTo(to, a, b);
        uint256 v = _poolLegValue(i, a, b);
        ownerOut += v;
        emit OwnerWithdraw("pool", address(0), to, a, v);
    }

    /// USDC-micro value of any system token amount at current prices.
    function _usdcVal(address token, uint256 amount) internal view returns (uint256) {
        if (token == usdc) return amount;
        if (token == collat) return (amount * wethPx) / 1e18;
        if (token == address(rubx)) return (amount * pxX()) / 1e18;
        if (token == address(rubz)) return (amount * pxZ()) / 1e18;
        return 0;
    }

    /// Real-asset value of pool legs (i, sideA amount a, sideB amount b).
    /// XU/ZU: b is USDC. XC/ZC: b is COLLAT. XZ: no real legs.
    function _poolLegValue(uint256 i, uint256 a, uint256 b) internal view returns (uint256) {
        a; // internal legs valued 0 by design
        if (i == 0 || i == 1) return b;
        if (i == 3 || i == 4) return (b * wethPx) / 1e18;
        return 0;
    }

    function emitBoard() external {
        Board memory b = this.dashboard();
        emit Dashboard(b.hardNAV, b.markNAV, b.tvl, b.treasU, b.treasC,
            b.pxXv, b.pxZv, b.supX, b.supZ);
    }
}
