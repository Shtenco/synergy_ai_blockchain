// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20R {
    function transfer(address to, uint256 amount) external returns (bool);
}

/// Minimal ERC20 with owner-gated MINT/BURN for internal tokens (RUBX/RUBZ).
contract RubToken {
    string public name;
    string public symbol;
    uint8 public immutable decimals;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    address public owner;
    address public minter;

    event Transfer(address indexed from, address indexed to, uint256 amount);
    event Approval(address indexed owner, address indexed spender, uint256 amount);

    constructor(string memory n, string memory s, uint8 d, address owner_) {
        name = n; symbol = s; decimals = d; owner = owner_;
    }

    modifier onlyOwner() { require(msg.sender == owner, "TOK: only owner"); _; }

    function setMinter(address m) external onlyOwner { minter = m; }

    /// Rescue foreign ERC20s mistakenly sent TO this token contract.
    /// Own ledger balances are accounting entries, never touched.
    function rescueForeign(address token, address to, uint256 a) external onlyOwner {
        require(token != address(this), "TOK: own ledger");
        require(IERC20R(token).transfer(to, a), "TOK: rescue");
    }

    function approve(address s, uint256 a) external returns (bool) {
        allowance[msg.sender][s] = a;
        emit Approval(msg.sender, s, a);
        return true;
    }

    function transfer(address to, uint256 a) external returns (bool) {
        require(balanceOf[msg.sender] >= a, "TOK: bal");
        balanceOf[msg.sender] -= a;
        balanceOf[to] += a;
        emit Transfer(msg.sender, to, a);
        return true;
    }

    function transferFrom(address f, address t, uint256 a) external returns (bool) {
        uint256 al = allowance[f][msg.sender];
        require(al >= a && balanceOf[f] >= a, "TOK: allow/bal");
        if (al != type(uint256).max) allowance[f][msg.sender] = al - a;
        balanceOf[f] -= a;
        balanceOf[t] += a;
        emit Transfer(f, t, a);
        return true;
    }

    function mint(address to, uint256 a) external {
        require(msg.sender == minter || msg.sender == owner, "TOK: only minter");
        totalSupply += a;
        balanceOf[to] += a;
        emit Transfer(address(0), to, a);
    }

    function burn(uint256 a) external {
        require(balanceOf[msg.sender] >= a, "TOK: bal");
        balanceOf[msg.sender] -= a;
        totalSupply -= a;
        emit Transfer(msg.sender, address(0), a);
    }

    function burnFrom(address f, uint256 a) external {
        require(msg.sender == minter || msg.sender == owner, "TOK: only minter");
        require(balanceOf[f] >= a, "TOK: bal");
        balanceOf[f] -= a;
        totalSupply -= a;
        emit Transfer(f, address(0), a);
    }
}
