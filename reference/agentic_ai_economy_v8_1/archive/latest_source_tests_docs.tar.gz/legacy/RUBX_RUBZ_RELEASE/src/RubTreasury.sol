// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20T {
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

/// Dumb vault: all accounting lives in RubEconomy. Owner = Economy.
contract RubTreasury {
    address public owner;
    modifier onlyOwner() { require(msg.sender == owner, "TR: only owner"); _; }
    constructor(address owner_) { owner = owner_; }
    function setOwner(address o) external onlyOwner { owner = o; }
    function pull(address token, address from, uint256 a) external onlyOwner {
        require(IERC20T(token).transferFrom(from, address(this), a), "TR: pull");
    }
    function send(address token, address to, uint256 a) external onlyOwner {
        require(IERC20T(token).transfer(to, a), "TR: send");
    }
    function approvePool(address token, address pool, uint256 a) external onlyOwner {
        require(IERC20T(token).approve(pool, a), "TR: appr");
    }
    function bal(address token) external view returns (uint256) {
        return IERC20T(token).balanceOf(address(this));
    }
}
