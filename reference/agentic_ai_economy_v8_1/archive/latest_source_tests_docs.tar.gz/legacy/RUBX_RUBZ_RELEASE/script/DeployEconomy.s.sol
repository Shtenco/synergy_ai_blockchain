// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {RubToken} from "../src/RubToken.sol";
import {RubPool} from "../src/RubPool.sol";
import {RubTreasury} from "../src/RubTreasury.sol";
import {RubEconomy} from "../src/RubEconomy.sol";

interface VmS {
    function startBroadcast() external;
    function stopBroadcast() external;
}

interface IERC20S {
    function approve(address spender, uint256 amount) external returns (bool);
}

interface IV3S {
    function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16, uint16, uint16, uint8, bool);
}

/// Deploys Economy + 5 pools, links everything, sets oracle, seeds.
/// Run: forge script script/DeployEconomy.s.sol --rpc-url https://mainnet.base.org --broadcast --private-key $KEY
contract DeployEconomy {
    address constant RUBX = 0xf3E95649B994338Ca3A791F3Fdf4B2c96621Afe9;
    address constant RUBZ = 0xf29Cd1b5c17E2ceAf30c89Fb0B0549F7897f212E;
    address constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address constant WETH = 0x4200000000000000000000000000000000000006;
    address constant TREASURY = 0xa8AEabD7708fa11450E65B96bF34C71Ee3057a64;
    address constant DEPLOYER = 0x76E61c8169446cB404141BB5a05a21b754348D52;
    address constant V3 = 0xd0b53D9277642d899DF5C87A3966A349A798F224;

    function run() external {
        VmS(address(uint160(uint256(keccak256("hevm cheat code"))))).startBroadcast();
        RubEconomy eco = new RubEconomy(RUBX, RUBZ, USDC, WETH, TREASURY, DEPLOYER);
        RubPool pXU = new RubPool(RUBX, USDC, 18, 6, address(eco), TREASURY);
        RubPool pZU = new RubPool(RUBZ, USDC, 18, 6, address(eco), TREASURY);
        RubPool pXZ = new RubPool(RUBX, RUBZ, 18, 18, address(eco), TREASURY);
        RubPool pXC = new RubPool(RUBX, WETH, 18, 18, address(eco), TREASURY);
        RubPool pZC = new RubPool(RUBZ, WETH, 18, 18, address(eco), TREASURY);
        address[5] memory ps = [address(pXU), address(pZU), address(pXZ), address(pXC), address(pZC)];
        eco.linkPools(ps);
        RubTreasury(TREASURY).setOwner(address(eco));
        RubToken(RUBX).setMinter(address(eco));
        RubToken(RUBZ).setMinter(address(eco));
        (uint160 sq,,,,,,) = IV3S(V3).slot0();
        eco.setWethPx((uint256(sq) * uint256(sq) * 1e18) / (uint256(1) << 192));
        IERC20S(USDC).approve(address(eco), type(uint256).max);
        IERC20S(WETH).approve(address(eco), type(uint256).max);
        eco.seed(
            5000000000000000000, 250000,
            5000000000000000000, 250000,
            1000000000000000000, 1000000000000000000,
            1000000000000000000, 4000000000000,
            1000000000000000000, 4000000000000,
            960000, 9000000000000
        );
        VmS(address(uint160(uint256(keccak256("hevm cheat code"))))).stopBroadcast();
    }
}
