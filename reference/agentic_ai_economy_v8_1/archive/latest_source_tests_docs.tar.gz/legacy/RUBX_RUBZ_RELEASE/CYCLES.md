# Live cycles log — Base mainnet

## Cycle run #1 (2026-09-16, deployer 0x76E61c81…D52)

### Before (dashboard)
- hardNAV: 1501022 ($1.501022) | TVL: 1219304 | MarkNAV: 2201022
- treasury: 960000 USDC + 9e12 wei WETH
- pools XU/ZU: 5e18 + 250000 each; pxX=pxZ=50000 ($0.05, discount vs $1 target)
- deployer pocket: 1609 micro USDC

### Actions (nonce 4744→4751)
1. `approve` pXU/pZU 100000 (4744, 4745)
2. External buy 700 micro USDC → RUBX on pXU, `withProto=true` (4746)
3. External buy 700 micro USDC → RUBZ on pZU, `withProto=true` (4747)
   - proto 5bps of 700 = 3 micro → rounds to **0** (no realized accrual)
4. `setParams`: investorIn=200, yieldTarget=40, microSizeU=5000,
   floor=50000 (4749)
5. `investorCycle()` (4750): in 200 → out **196**, shortfall 4 covered
   from reserve, principal 200 returned, **yield 0** (realized empty — honest)

### After (dashboard)
- hardNAV: **1502422** ($1.502422) | TVL: 1223221 | MarkNAV: 2204935
- treasury: 959996 USDC (delta −4 = shortfall cover)
- counters: deposits=200, principalOut=200, shortfall=4, cycles=1,
  realized=0, paidYield=0

### Multiplier: incoming $ vs HardNAV
- External pocket spend retained in system: 2×700 = **1400 micro**
- ΔHardNAV: 1502422 − 1501022 = **+1400 micro**
- **Multiplier = 1400/1400 = 1.00×**
- Investor 200 round-tripped (net 0 for HardNAV by construction).

### Вывод (честно)
Потолок множителя на одном пуле conviction — **1.0**: каждый микро USDC,
осевший в пулах/treasury, пришёл из кармана. Значение 3.14× из симулятора
считалось как ΔHard/депозиты, где депозиты ($1) были в 1000 раз меньше
реального внешнего объёма ($1000+), который и профинансировал рост.
Формула та же: `ΔHard = externalFees + externalYield + externalNetBuys`.
Чтобы живой множитель превышал 1.0 на входящих долларах, нужен
**чужой** объём (внешние тейкеры платят спред+fee в наши пулы) —
следующий шаг: гнать внешний флоу, а не свои деньги по кругу.

## Cycle run #2 — 5 действий + 1 честный revert (2026-09-16)

Состав: `investorCycle` (IN=200) + `buyBurnX(10000)` + `buyBurnZ(100000)`
+ external swap 100 micro XU + external swap 100 micro ZU (оба `withProto`)
+ `arbTriangle(5000)` → **revert `ECO: no profit`** (спред 110 bps < 90 bps
комиссий трёх легов + слиппедж; контроллер правильно отказался).

- HardNAV: 1501022 → **1502622** (Δ +1600 ≈ два внешних свопа 2×700
  + микро-пыль маршрутов; в пределах RPC-шума ±200)
- Treasury: 960000 → **939990** (−20000 buyBurn + −10 shortfall-covers)
- Счётчики: deposits=400, principalOut=400 (1:1), shortfall=10,
  cycles=2, realized=0, paidYield=0
- Цены двинулись к пегу: pxX 50359 → **54572**, pxZ 50200 → **54243**
  (buyBurn работает); burned X/Z ≈ 0.19 каждый
- **Множитель retained/external = 1600/1600 ≈ 1.00×** — снова потолок
  консервации: внутренние ходы (buyBurn, маршрут, arb-попытка) суммарно
  дают 0 в HardNAV; весь прирост — внешний карман → пулы/treasury.

## Почему нельзя «вывести 0.5 из HARD»

Treasury (`RubTreasury.send`) и пулы (`RubPool.removeTo`) — только owner,
а owner у обоих = **Economy**, не деплоер. У Economy есть `rescue()`,
но он тянет только пыль с самого Economy. Прямого пути
treasury→deployer в коде **нет** — это намеренно: иначе рушатся гарантии
инвестора (principal 1:1, yield только из realized, floor резерва).
Вывод 0.5 USDC возможен только через: (а) investor yield при realized>0,
(б) редиплой с новой логикой (дорого, сносит пулы). Не executed — зафиксировано.
