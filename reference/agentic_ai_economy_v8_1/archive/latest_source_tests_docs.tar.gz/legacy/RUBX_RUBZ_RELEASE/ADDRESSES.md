# RUBX/RUBZ — Base mainnet deployment record

Дата: 2026-09-16. Deployer: `0x76E61c8169446cB404141BB5a05a21b754348D52`.
Скрипт: `script/DeployEconomy.s.sol` (батч: deploy → link → seed, ~14.5M gas).

## Контракты

| Контракт | Адрес |
|---|---|
| RUBX (18 dec) | `0xf3E95649B994338Ca3A791F3Fdf4B2c96621Afe9` |
| RUBZ (18 dec) | `0xf29Cd1b5c17E2ceAf30c89Fb0B0549F7897f212E` |
| RubTreasury (owner → Economy) | `0xa8AEabD7708fa11450E65B96bF34C71Ee3057a64` |
| RubEconomy (owner = deployer) | `0xd7986fe2131a16ac227dde2a8bb3ca2dbca3f0dc` |
| Pool 0 RUBX/USDC | `0x6e761c19a444b30e7a1b5e00c6e7277129821e84` |
| Pool 1 RUBZ/USDC | `0x7f3d3d52b41bae8e209d1ef1ceeb30312220e87a` |
| Pool 2 RUBX/RUBZ | `0xa70ef1873221726124d20574b754cf9bf510fe33` |
| Pool 3 RUBX/WETH | `0xb328cb17f29f9774dc30b94e43d3b137c754a75e` |
| Pool 4 RUBZ/WETH | `0x56fdc8908ef99d3db58e04fb992e3df366fdce74` |

## Стартовый сид (0.50 USDC + WETH)

- Pool 0: 5 RUBX + 0.25 USDC; Pool 1: 5 RUBZ + 0.25 USDC
- Pool 2: 1 RUBX + 1 RUBZ
- Pool 3: 1 RUBX + 0.000004 WETH; Pool 4: 1 RUBZ + 0.000004 WETH
- Treasury: 0.96 USDC + 0.000009 WETH
- Стартовый dashboard: HardNAV $1.50 / MarkNAV $2.20 / TVL $1.22

## Мгновенный вывод овнера (проверено в исходниках, все onlyOwner)

- `RubEconomy.rescue(token,to,amount)` — любые зависшие балансы Economy
- `RubPool.removeTo(to,a,b)` — резервы любого пула
- `RubTreasury.send(token,to,amount)` — весь сейф
- Плюс `setMinter`/`setOwner`/`linkPools`/`setParams` — полный контроль

## Живые параметры циклов

`investorIn=20000` (0.02), `yieldTarget=4000` (0.004), `microSizeU=10000`,
`reserveFloorU=200000` (0.20), `payMode=0` (урезать при нехватке),
`buyCapBps=200`, `reinvestBps=2500`, `arbMinBps=30`, `rebThrBps=500`.

## Газовый бюджет

Своп 0.5 USDC→ETH на газ выполнен. Один investor-цикл ≈ 5 свопов (~0.5–1M газа).
Перед циклами проверить ETH-баланс деплоера.
