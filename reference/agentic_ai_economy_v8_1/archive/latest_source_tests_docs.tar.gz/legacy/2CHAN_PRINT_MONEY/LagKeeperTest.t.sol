// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MockERC20Simple {
    uint8 public immutable decimals;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    constructor(uint8 d) { decimals = d; }
    function mint(address to, uint256 amount) external { balanceOf[to] += amount; totalSupply += amount; }
    function approve(address s, uint256 a) external returns (bool) { allowance[msg.sender][s] = a; return true; }
    function transfer(address to, uint256 a) external returns (bool) { balanceOf[msg.sender] -= a; balanceOf[to] += a; return true; }
    function transferFrom(address f, address t, uint256 a) external returns (bool) { allowance[f][msg.sender] -= a; balanceOf[f] -= a; balanceOf[t] += a; return true; }
}

contract LagOracleSimple {
    uint256 public currentPrice;
    uint256[] public histPrice;
    uint256[] public histBlock;
    constructor(uint256 p) { currentPrice = p; histPrice.push(p); histBlock.push(block.number); }
    function setPrice(uint256 p) external { currentPrice = p; histPrice.push(p); histBlock.push(block.number); }
    function getTwap(uint256 lag) external view returns (uint256) {
        uint256 target = block.number > lag ? block.number - lag : 0;
        for (uint256 i = histPrice.length; i > 0; i--) if (histBlock[i-1] <= target) return histPrice[i-1];
        return histPrice[0];
    }
    function getSpot() external view returns (uint256) { return currentPrice; }
}

contract BridgeInventorySimple {
    uint256 public l1Usdc; uint256 public l2Usdc; uint256 public l1Weth; uint256 public l2Weth;
    function depositL1(uint256 u, uint256 w) external { l1Usdc += u; l1Weth += w; }
    function depositL2(uint256 u, uint256 w) external { l2Usdc += u; l2Weth += w; }
    function totalValue(uint256 price) external view returns (uint256) { return l1Usdc + l2Usdc + (l1Weth + l2Weth) * price / 1e18; }
}

contract LagBridgeTest {
    event DebugStr(string v);
    event DebugNum(uint256 v);

    function testLagBridgeKeeper() public {
        // L1 TWAP = $2400, L2 spot after volatility = $2520 (+5% spread)
        MockERC20Simple usdc = new MockERC20Simple(6);
        MockERC20Simple weth = new MockERC20Simple(18);
        LagOracleSimple l1 = new LagOracleSimple(2400e6);
        // Simulate L2 move: new price $2520, L1 still $2400 (lag)
        l1.setPrice(2520e6);

        emit DebugStr("L1 TWAP (lag=300 blocks)");
        emit DebugNum(l1.getTwap(300));
        emit DebugStr("L1 spot");
        emit DebugNum(l1.getSpot());
        emit DebugStr("Spread bps if L2 spot = 2520");
        emit DebugNum(500);

        // Bridge inventory: 10 WETH on L1, 10000 USDC on L2
        BridgeInventorySimple bridge = new BridgeInventorySimple();
        usdc.mint(address(bridge), 10000 * 1e6);
        weth.mint(address(bridge), 10 ether);
        bridge.depositL2(10000 * 1e6, 0);
        bridge.depositL1(0, 10 ether);
        emit DebugStr("Bridge L1 WETH");
        emit DebugNum(bridge.l1Weth());
        emit DebugStr("Bridge L2 USDC");
        emit DebugNum(bridge.l2Usdc());

        // Keeper profit: volatility x lag - fees
        uint256 spreadBps = 500; // 5%
        uint256 flashUsdc = 1000 * 1e6;
        uint256 gross = flashUsdc * spreadBps / 10000;
        uint256 fees = flashUsdc * 60 / 10000; // 30+30 bps CPMM+V3
        uint256 profit = gross > fees ? gross - fees : 0;
        emit DebugStr("Flash USDC");
        emit DebugNum(flashUsdc);
        emit DebugStr("Gross from spread");
        emit DebugNum(gross);
        emit DebugStr("Fees (60bps)");
        emit DebugNum(fees);
        emit DebugStr("Net profit USDC");
        emit DebugNum(profit);
        emit DebugStr("Profit formula: volatility * lag - fees");

        require(profit > 0, "LK: no profit");
        require(spreadBps > 60, "LK: spread < fees");
    }
}
