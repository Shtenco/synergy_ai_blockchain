// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract MockERC20 {
    uint8 public immutable decimals;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    constructor(uint8 d) { decimals = d; }
    function mint(address to, uint256 amount) external { balanceOf[to] += amount; totalSupply += amount; }
    function burn(address from, uint256 amount) external { balanceOf[from] -= amount; totalSupply -= amount; }
    function transfer(address to, uint256 amount) external returns (bool) { balanceOf[msg.sender] -= amount; balanceOf[to] += amount; return true; }
    function approve(address spender, uint256 amount) external returns (bool) { allowance[msg.sender][spender] = amount; return true; }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) { allowance[from][msg.sender] -= amount; balanceOf[from] -= amount; balanceOf[to] += amount; return true; }
}

contract MockRouter {
    uint256 public rateWethUsd6;
    constructor(uint256 r) { rateWethUsd6 = r; }
    function setRate(uint256 r) external { rateWethUsd6 = r; }
    struct MEIP {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(MEIP calldata p) external payable returns (uint256) {
        MockERC20 tIn = MockERC20(p.tokenIn);
        MockERC20 tOut = MockERC20(p.tokenOut);
        require(tIn.transferFrom(msg.sender, address(this), p.amountIn), "router: in");
        uint256 out;
        uint8 decIn = MockERC20(p.tokenIn).decimals();
        uint8 decOut = MockERC20(p.tokenOut).decimals();
        if (decIn == 18 && decOut == 6) {
            out = (p.amountIn * rateWethUsd6) / 1e18;
        } else if (decIn == 6 && decOut == 18) {
            out = (p.amountIn * 1e18) / rateWethUsd6;
        } else revert("router: bad pair");
        require(tOut.balanceOf(address(this)) >= out, "router: insufficient");
        require(tOut.transfer(msg.sender, out), "router: out");
        return out;
    }
}

contract MockBalancer {
    MockERC20 public immutable usdc;
    constructor(MockERC20 u) { usdc = u; }
    function flashLoan(address recipient, address[] calldata tokens, uint256[] calldata amounts, bytes calldata) external {
        require(tokens.length == 1 && tokens[0] == address(usdc), "bal: tokens");
        uint256 vaultBefore = usdc.balanceOf(address(this));
        require(usdc.transfer(recipient, amounts[0]), "bal: transfer");
        (bool ok,) = recipient.call(abi.encodeWithSignature("receiveFlashLoan(address[],uint256[],uint256[],bytes)",
            tokens, amounts, new uint256[](1), ""));
        require(ok, "bal: callback");
        // Real Balancer semantics: vault only verifies its own balance recovered (callback repays via transfer).
        require(usdc.balanceOf(address(this)) >= vaultBefore, "bal: not repaid");
    }
}

contract CounterPool {
    address public immutable token0;
    address public immutable token1;
    uint256 public reserve0;
    uint256 public reserve1;
    uint256 public constant FEE = 30;
    constructor(address t0, address t1) { token0 = t0; token1 = t1; }
    function addLiquidity(uint256 a0, uint256 a1) external {
        require(MockERC20(token0).transferFrom(msg.sender, address(this), a0), "cp: t0");
        require(MockERC20(token1).transferFrom(msg.sender, address(this), a1), "cp: t1");
        reserve0 += a0;
        reserve1 += a1;
    }
    function swap1For0(uint256 aIn) external returns (uint256 out) {
        uint256 z = (aIn * (10000 - FEE)) / 10000;
        out = (reserve0 * z) / (reserve1 + z);
        require(out > 0 && out < reserve0, "OUT");
        require(MockERC20(token1).transferFrom(msg.sender, address(this), aIn), "cp: in");
        reserve1 += aIn;
        reserve0 -= out;
        require(MockERC20(token0).transfer(msg.sender, out), "cp: out");
    }
}

contract MockAtomicBatch {
    address public pool;
    address public owner;
    MockERC20 public usdc;
    MockERC20 public weth;
    MockRouter public router;
    MockBalancer public balancer;
    uint256 public lastNetUsdc;
    uint256 public lastFlashFee;
    uint256 public lastWethBought;
    uint256 public lastUsdcBack;

    event DebugStep(string tag, uint256 v);

    constructor(address pool_, address owner_, address usdc_, address weth_, address router_, address balancer_) {
        pool = pool_;
        owner = owner_;
        usdc = MockERC20(usdc_);
        weth = MockERC20(weth_);
        router = MockRouter(router_);
        balancer = MockBalancer(balancer_);
        usdc.approve(address(pool_), type(uint256).max);
        usdc.approve(address(balancer_), type(uint256).max);
        weth.approve(address(router_), type(uint256).max);
    }

    modifier onlyOwner() { require(msg.sender == owner, "B: only owner"); _; }

    function executeBatch(uint256 flashUsdc) external onlyOwner {
        uint256 pre = usdc.balanceOf(address(this));
        emit DebugStep("pre", pre);
        address[] memory tokens = new address[](1);
        uint256[] memory amounts = new uint256[](1);
        tokens[0] = address(usdc);
        amounts[0] = flashUsdc;
        balancer.flashLoan(address(this), tokens, amounts, "");
        uint256 post = usdc.balanceOf(address(this));
        emit DebugStep("post", post);
        emit DebugStep("wethBought", lastWethBought);
        emit DebugStep("usdcBack", lastUsdcBack);
        emit DebugStep("flashFee", lastFlashFee);
        require(post > pre, "B: no canonical profit");
        lastNetUsdc = post - pre;
    }

    function receiveFlashLoan(address[] calldata, uint256[] calldata amounts, uint256[] calldata fees, bytes calldata) external {
        require(msg.sender == address(balancer), "B: bad caller");
        lastFlashFee = fees[0];
        uint256 flashAmount = amounts[0];
        usdc.approve(address(pool), flashAmount);
        uint256 wBought = CounterPool(pool).swap1For0(flashAmount);
        lastWethBought = wBought;
        emit DebugStep("wBought", wBought);
        require(wBought > 0, "B: empty");
        weth.approve(address(router), wBought);
        uint256 usdcBackBefore = usdc.balanceOf(address(this));
        router.exactInputSingle(MockRouter.MEIP(
            address(weth), address(usdc), 500, address(this), wBought, 0, 0
        ));
        uint256 usdcBackAfter = usdc.balanceOf(address(this));
        lastUsdcBack = usdcBackAfter - usdcBackBefore;
        uint256 need = flashAmount + fees[0];
        uint256 have = usdc.balanceOf(address(this));
        require(have >= need, "B: no repay");
        require(usdc.transfer(address(balancer), need), "B: xfer");
    }
}

contract ForkMockBatchTest {
    event LogEvent(string tag, uint256 val);
    event LogStr(string s);

    function testAtomicBatch500pct() public {
        uint256 ext = 2479e6; // USDC6 per WETH ($2479) — matches SpreadLab units
        uint256 inner = ext / 6; // 500% spread
        emit LogStr("External USDC6/WETH");
        emit LogEvent("ext", ext);
        emit LogEvent("inner", inner);

        MockERC20 usdc = new MockERC20(6);
        MockERC20 weth = new MockERC20(18);

        MockRouter router = new MockRouter(ext);
        // Заранее минтим много USDC в router (в реальности это pool reserves)
        usdc.mint(address(router), type(uint128).max);
        CounterPool pool = new CounterPool(address(weth), address(usdc));
        MockBalancer balancer = new MockBalancer(usdc);
        // Имитируем "бесконечный" vault: минтим много USDC в balancer
        usdc.mint(address(balancer), type(uint128).max);

        // Seed pool matching SpreadLab 5000 USDC / 0.0124 WETH at 500% discount
        uint256 targetUsdc = 5000 * 1e6; // 5e9 USDC raw
        uint256 wethReserve = (targetUsdc * 1e18) / inner; // ~1.21e13 wei = 0.0121 WETH
        emit LogEvent("seed_weth_wei", wethReserve);
        emit LogEvent("seed_usdc_raw", targetUsdc);
        usdc.mint(address(this), targetUsdc);
        weth.mint(address(this), wethReserve);
        usdc.approve(address(pool), targetUsdc);
        weth.approve(address(pool), wethReserve);
        pool.addLiquidity(wethReserve, targetUsdc);

        MockAtomicBatch batch = new MockAtomicBatch(
            address(pool), address(this),
            address(usdc), address(weth),
            address(router), address(balancer)
        );

        usdc.approve(address(batch), type(uint256).max);
        weth.approve(address(batch), type(uint256).max);

        uint256 flash = 50 * 1e6; // 50 USDC raw = 5e7
        emit LogEvent("flash_usdc", flash);
        bytes memory err;
        bool ok;
        try batch.executeBatch(flash) {
            ok = true;
        } catch (bytes memory e) {
            ok = false;
            err = e;
        }
        emit LogStr(ok ? "Atomic batch SUCCEEDED" : "Atomic batch REVERTED");
        if (!ok) {
            emit LogStr(string(err));
        }
        emit LogEvent("lastNetUsdc", batch.lastNetUsdc());
        emit LogEvent("lastFlashFee", batch.lastFlashFee());
        emit LogEvent("lastWethBought", batch.lastWethBought());
        emit LogEvent("lastUsdcBack", batch.lastUsdcBack());

        require(ok && batch.lastNetUsdc() > 0, "atomic batch did not yield canonical profit");
    }
}
