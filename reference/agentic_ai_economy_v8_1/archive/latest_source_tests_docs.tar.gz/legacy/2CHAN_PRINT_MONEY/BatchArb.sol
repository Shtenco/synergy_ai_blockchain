// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20BA {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
}

interface IBalancerVaultBA {
    function flashLoan(address recipient, address[] calldata tokens, uint256[] calldata amounts, bytes calldata userData) external;
}

interface IV3RouterBA {
    struct EIP {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(EIP calldata params) external payable returns (uint256);
}

/// Self-contained pool deployed by BatchArb (owner = BatchArb)
contract CounterPoolBA {
    address public immutable token0;
    address public immutable token1;
    address public immutable owner;
    uint256 public reserve0;
    uint256 public reserve1;
    uint256 public constant FEE = 30;
    modifier onlyOwner() { require(msg.sender == owner, "CP: only owner"); _; }
    constructor(address t0, address t1, address o) {
        token0 = t0; token1 = t1; owner = o;
    }
    function addLiquidity(uint256 a0, uint256 a1) external {
        IERC20BA(token0).transferFrom(msg.sender, address(this), a0);
        IERC20BA(token1).transferFrom(msg.sender, address(this), a1);
        reserve0 += a0;
        reserve1 += a1;
    }
    function removeAll(address to) external onlyOwner {
        uint256 a0 = reserve0;
        uint256 a1 = reserve1;
        reserve0 = 0;
        reserve1 = 0;
        require(IERC20BA(token0).transfer(to, a0), "R0");
        require(IERC20BA(token1).transfer(to, a1), "R1");
    }
    function swap1For0(uint256 aIn) external returns (uint256 out) {
        uint256 z = (aIn * 9970) / 10000;
        out = (reserve0 * z) / (reserve1 + z);
        require(out > 0 && out < reserve0, "OUT");
        IERC20BA(token1).transferFrom(msg.sender, address(this), aIn);
        reserve1 += aIn;
        reserve0 -= out;
        require(IERC20BA(token0).transfer(msg.sender, out), "OUT_T");
    }
}

/// Self-contained keeper deployed by BatchArb (owner = BatchArb)
contract LagKeeperBA {
    address public constant BAL = 0xBA12222222228d8Ba445958a75a0704d566BF2C8;
    address public constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address public constant WETH = 0x4200000000000000000000000000000000000006;
    address public constant ROUTER = 0x2626664c2603336E57B271c5C0b26F421741e481;
    CounterPoolBA public immutable pool;
    address public immutable owner;
    modifier onlyOwner() { require(msg.sender == owner, "LK: only owner"); _; }
    constructor(CounterPoolBA pool_, address owner_) {
        pool = pool_; owner = owner_;
        IERC20BA(USDC).approve(address(pool_), type(uint256).max);
        IERC20BA(WETH).approve(address(pool_), type(uint256).max);
        IERC20BA(USDC).approve(BAL, type(uint256).max);
        IERC20BA(WETH).approve(BAL, type(uint256).max);
        IERC20BA(USDC).approve(ROUTER, type(uint256).max);
        IERC20BA(WETH).approve(ROUTER, type(uint256).max);
    }
    function arbCheapPool(uint256 flashUsdc) external onlyOwner {
        uint256 preBal = IERC20BA(USDC).balanceOf(address(this));
        address[] memory tokens = new address[](1);
        uint256[] memory amounts = new uint256[](1);
        tokens[0] = USDC;
        amounts[0] = flashUsdc;
        IBalancerVaultBA(BAL).flashLoan(address(this), tokens, amounts, abi.encode(uint256(0)));
        uint256 profit = IERC20BA(USDC).balanceOf(address(this)) - preBal;
        require(profit > 0, "LK: no profit");
    }
function receiveFlashLoan(
        address[] memory tokens,
        uint256[] memory amounts,
        uint256[] memory fees,
        bytes memory data
    ) external {
        require(msg.sender == BAL, "LK: bad caller");
        uint256 mode = abi.decode(data, (uint256));
        if (mode == 0) {
            uint256 wOut = pool.swap1For0(amounts[0]);
            IERC20BA(WETH).approve(ROUTER, wOut);
            IV3RouterBA(ROUTER).exactInputSingle(
                IV3RouterBA.EIP(WETH, USDC, 500, address(this), wOut, 0, 0)
            );
            uint256 need = amounts[0] + fees[0];
            require(IERC20BA(USDC).balanceOf(address(this)) >= need, "LK: not repaid");
            IERC20BA(USDC).transfer(BAL, need);
        } else { revert("mode 1"); }
        tokens; fees; data;
    }
    function withdrawAll() external onlyOwner {
        uint256 u = IERC20BA(USDC).balanceOf(address(this));
        if (u > 0) IERC20BA(USDC).transfer(owner, u);
        uint256 w = IERC20BA(WETH).balanceOf(address(this));
        if (w > 0) IERC20BA(WETH).transfer(owner, w);
    }
}

/// BatchArb: deploys fresh pool + keeper, runs flash cycle, extracts profit, returns.
contract BatchArb {
    address public constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address public constant WETH = 0x4200000000000000000000000000000000000006;

    event CycleDone(uint256 indexed i, uint256 seedWeth, uint256 flashUsdc, uint256 profitUsdc);

    /// One full atomic cycle: seed -> flash arb -> extract -> send back.
    function executeBatch(uint256 seedWeth, uint256 seedUsdc, uint256 flashUsdc) external {
        IERC20BA(WETH).transferFrom(msg.sender, address(this), seedWeth);
        IERC20BA(USDC).transferFrom(msg.sender, address(this), seedUsdc);

        CounterPoolBA pool = new CounterPoolBA(WETH, USDC, address(this));
        LagKeeperBA keeper = new LagKeeperBA(pool, address(this));

        IERC20BA(WETH).approve(address(pool), seedWeth);
        IERC20BA(USDC).approve(address(pool), seedUsdc);

        pool.addLiquidity(seedWeth, seedUsdc);
        keeper.arbCheapPool(flashUsdc);

        keeper.withdrawAll();
        pool.removeAll(address(this));

        uint256 wBal = IERC20BA(WETH).balanceOf(address(this));
        uint256 uBal = IERC20BA(USDC).balanceOf(address(this));
        if (wBal > 0) IERC20BA(WETH).transfer(msg.sender, wBal);
        if (uBal > 0) IERC20BA(USDC).transfer(msg.sender, uBal);
        emit CycleDone(0, seedWeth, flashUsdc, uBal);
    }

    /// Multiple cycles in ONE tx. Each cycle creates fresh pool + keeper.
    /// Total seed = numCycles * seedWethEach (and seedUsdcEach).
    function executeMulti(uint256 numCycles, uint256 seedWethEach, uint256 seedUsdcEach, uint256 flashUsdcEach) external {
        require(numCycles > 0 && numCycles <= 10, "BA: 1..10");
        IERC20BA(WETH).transferFrom(msg.sender, address(this), seedWethEach * numCycles);
        IERC20BA(USDC).transferFrom(msg.sender, address(this), seedUsdcEach * numCycles);

        for (uint256 i = 0; i < numCycles; i++) {
            CounterPoolBA pool = new CounterPoolBA(WETH, USDC, address(this));
            LagKeeperBA keeper = new LagKeeperBA(pool, address(this));

            IERC20BA(WETH).approve(address(pool), seedWethEach);
            IERC20BA(USDC).approve(address(pool), seedUsdcEach);

            pool.addLiquidity(seedWethEach, seedUsdcEach);
            keeper.arbCheapPool(flashUsdcEach);

            keeper.withdrawAll();
            pool.removeAll(address(this));
            emit CycleDone(i, seedWethEach, flashUsdcEach, IERC20BA(USDC).balanceOf(address(this)));
        }

        uint256 wBal = IERC20BA(WETH).balanceOf(address(this));
        uint256 uBal = IERC20BA(USDC).balanceOf(address(this));
        if (wBal > 0) IERC20BA(WETH).transfer(msg.sender, wBal);
        if (uBal > 0) IERC20BA(USDC).transfer(msg.sender, uBal);
    }
}