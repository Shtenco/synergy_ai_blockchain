// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Minimal ERC20 interface (USDC 6 dec / WETH 18 dec on Base).
interface IERC20Lag {
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

/// L1 TWAP Oracle — lagged price feed.
/// Stores price history, returns price from `lag` blocks ago.
contract LagOracle {
    address public owner;
    uint256 public lagBlocks; // e.g. 3600 / 12 = 300 blocks for 1h lag on Base (2s block)
    struct PricePoint { uint256 blockNum; uint256 price; }
    PricePoint[] public history;
    uint256 public currentPrice;

    modifier onlyOwner() { require(msg.sender == owner, "LO: only owner"); _; }

    constructor(address owner_, uint256 lagBlocks_, uint256 initialPrice) {
        owner = owner_;
        lagBlocks = lagBlocks_;
        currentPrice = initialPrice;
        history.push(PricePoint(block.number, initialPrice));
    }

    function setPrice(uint256 price) external onlyOwner {
        currentPrice = price;
        history.push(PricePoint(block.number, price));
    }

    function setLag(uint256 lag) external onlyOwner {
        lagBlocks = lag;
    }

    /// TWAP-like lagged price: price from `lagBlocks` ago.
    function getTwap() external view returns (uint256) {
        uint256 targetBlock = block.number > lagBlocks ? block.number - lagBlocks : 0;
        // Binary search history for price at or before targetBlock
        uint256 lo = 0;
        uint256 hi = history.length;
        while (lo < hi) {
            uint256 mid = (lo + hi) / 2;
            if (history[mid].blockNum <= targetBlock) lo = mid + 1;
            else hi = mid;
        }
        if (lo == 0) return history[0].price;
        return history[lo - 1].price;
    }

    function getSpot() external view returns (uint256) {
        return currentPrice;
    }
}

/// Bridge Inventory — holds USDC/WETH on both "chains" (L1 and L2).
/// For fork testing, both sides are on same chain but tracked separately.
/// Bridge operation simulates delay via block number.
contract BridgeInventory {
    address public owner;
    // L1 side
    uint256 public l1Usdc;
    uint256 public l1Weth;
    // L2 side
    uint256 public l2Usdc;
    uint256 public l2Weth;
    // Pending bridges
    struct PendingBridge { uint256 amount; uint256 unlockBlock; bool isWeth; bool toL2; }
    PendingBridge[] public pending;

    modifier onlyOwner() { require(msg.sender == owner, "BI: only owner"); _; }

    constructor(address owner_) { owner = owner_; }

    function depositL1(uint256 usdcAmount, uint256 wethAmount) external onlyOwner {
        l1Usdc += usdcAmount;
        l1Weth += wethAmount;
    }

    function depositL2(uint256 usdcAmount, uint256 wethAmount) external onlyOwner {
        l2Usdc += usdcAmount;
        l2Weth += wethAmount;
    }

    /// Bridge USDC from L2 -> L1 (takes `delay` blocks)
    function bridgeUsdcToL1(uint256 amount, uint256 delay) external onlyOwner {
        require(l2Usdc >= amount, "BI: insufficient L2 USDC");
        l2Usdc -= amount;
        pending.push(PendingBridge(amount, block.number + delay, false, false));
    }

    /// Bridge WETH from L1 -> L2
    function bridgeWethToL2(uint256 amount, uint256 delay) external onlyOwner {
        require(l1Weth >= amount, "BI: insufficient L1 WETH");
        l1Weth -= amount;
        pending.push(PendingBridge(amount, block.number + delay, true, true));
    }

    /// Claim matured bridges
    function claim() external onlyOwner {
        for (uint256 i = 0; i < pending.length; i++) {
            if (block.number >= pending[i].unlockBlock) {
                if (pending[i].isWeth) {
                    if (pending[i].toL2) l2Weth += pending[i].amount;
                    else l1Weth += pending[i].amount;
                } else {
                    if (pending[i].toL2) l2Usdc += pending[i].amount;
                    else l1Usdc += pending[i].amount;
                }
                // Remove by swapping with last
                pending[i] = pending[pending.length - 1];
                pending.pop();
                i--;
            }
        }
    }

    function withdrawL1(uint256 usdcAmount, uint256 wethAmount) external onlyOwner {
        require(l1Usdc >= usdcAmount && l1Weth >= wethAmount, "BI: insufficient L1");
        l1Usdc -= usdcAmount;
        l1Weth -= wethAmount;
    }

    function withdrawL2(uint256 usdcAmount, uint256 wethAmount) external onlyOwner {
        require(l2Usdc >= usdcAmount && l2Weth >= wethAmount, "BI: insufficient L2");
        l2Usdc -= usdcAmount;
        l2Weth -= wethAmount;
    }

    function totalValue(uint256 price) external view returns (uint256) {
        // Total inventory value in USDC at given price
        return l1Usdc + l2Usdc + ((l1Weth + l2Weth) * price) / 1e18;
    }
}
