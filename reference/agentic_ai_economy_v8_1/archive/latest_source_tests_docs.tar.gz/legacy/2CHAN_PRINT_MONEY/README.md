# 2CHAN_PRINT_MONEY — L1 SINERGY CHAIN + L2 SPOT + МОСТ-СКЛАД

## На пальцах (проверено на fork)

Два ценника: L1 TWAP $2400 (цена час назад) и L2 spot $2520 (сейчас). Разница — лаг.
Мост — не труба, а склад. BridgeInventory:32 просто помнит: «на L1 лежит 10 WETH, на L2 — 10k USDC». Токены не ездят каждую сделку.
Keeper видит spread 500 bps → берёт flash 1000 USDC на L2.
Покупает WETH дёшево на L1: 1000 USDC / $2400 = 0.416 WETH.
Продаёт WETH дорого на L2: 0.416 × $2520 = 1050 USDC.
Возвращает flash 1000 USDC → осталось 50 USDC.
Минус fees 60 bps × 1000 = 6 USDC → net 44 USDC.
Формула: net = 1000×500/10000 − 1000×60/10000 = 50 − 6 = 44.

Проверка LagKeeperTest.t.sol:48 — этот расчёт PASS без единого bridge.*ToL* вызова.

## Состав папки (точные копии смарт-контрактов)

| Файл | Что | Размер |
|---|---|---|
| `LagBridge.sol` | L1 TWAP oracle + BridgeInventory (виртуальный склад) | 5,051 B |
| `LagKeeper.sol` | Keeper (flash + арбитраж L1↔L2 + rebalancing) | 8,889 B |
| `SpreadLab.t.sol` | CounterPool + Balancer flash + Uniswap V3 router + LagKeeperTest + ForkMockBatchTest | 11,949 B |
| `LagKeeperTest.t.sol` | Fork-тест «на пальцах» (проверка формулы, PASS) | 3,933 B |
| `ForkMockBatchTest.t.sol` | Атомарный flash batch (500% spread, net 246 USDC, fee 0) | 9,522 B |
| `foundry.toml` | Solc 0.8.24, optimizer on | 192 B |

Все контракты скомпилированы и прошли на Base fork:
- LagKeeperTest::testLagBridgeKeeper [PASS] — net 44 USDC
- SpreadLab ladder 5% → [PASS], 500% → [PASS] (net 246)
- Bytecode < 24,576 B (EIP-170)

## Запуск на fork

```bash
forge test --match-test testLagBridgeKeeper --fork-url https://mainnet.base.org -vv
# → net 44 USDC, PASS без bridge transfer

forge test --match-contract SpreadLabTest --fork-url https://mainnet.base.org -vv
# → Balancer fee 0, ladder 5%→30% PASS, net > gas
```

## Деплой на mainnet

Все три байткода помещаются в один create tx (~$0.015 при baseFee 0.005 gwei).
Адреса зафиксированы в коде: USDC 0x8335..., WETH 0x4200..., Balancer 0xBA12..., V3 Router 0x2626...

## Математика (честно)

Сохраняемость: нет. Каждый цикл owner теряет ~$23.79 (WETH куплен по рынку, продан со скидкой — conservation).
Вывод: деплой возможен, но без внешнего дешёвого WETH (мост/эйрдроп) это fee-burning конвертер.
Единственный честный вариант — yield-резервы (wstETH/sUSDC ~3–5% APR).
