// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface VmCheats {
    function label(address who, string calldata lbl) external;
    function createSelectFork(string calldata url, uint256 blockNumber) external returns (uint256 id);
    function createSelectFork(string calldata url) external returns (uint256 id);
    function deal(address who, uint256 amt) external;
}

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
    function deposit() external payable;
}

interface IV3Pool {
    function slot0() external view returns (uint160 sqrtPriceX96, int24 tick, uint16, uint16, uint16, uint8, bool);
}

interface IBalancerVault {
    function flashLoan(address recipient, address[] calldata tokens, uint256[] calldata amounts, bytes calldata userData) external;
}

interface IV3Router {
    struct EIP {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(EIP calldata params) external payable returns (uint256);
}

contract CounterPool {
    address public immutable token0; // WETH
    address public immutable token1; // USDC
    uint256 public reserve0;
    uint256 public reserve1;
    uint256 public constant FEE = 30;

    constructor(address t0, address t1) { token0 = t0; token1 = t1; }

    function addLiquidity(uint256 a0, uint256 a1) external {
        IERC20(token0).transferFrom(msg.sender, address(this), a0);
        IERC20(token1).transferFrom(msg.sender, address(this), a1);
        reserve0 += a0;
        reserve1 += a1;
    }

    function swap1For0(uint256 aIn) external returns (uint256 out) {
        uint256 z = (aIn * (10000 - FEE)) / 10000;
        out = (reserve0 * z) / (reserve1 + z);
        require(out > 0 && out < reserve0, "OUT");
        IERC20(token1).transferFrom(msg.sender, address(this), aIn);
        reserve1 += aIn;
        reserve0 -= out;
        IERC20(token0).transfer(msg.sender, out);
    }

    /// Reverse: WETH (token0) in -> USDC (token1) out. Needed for premium phase.
    function swap0For1(uint256 aIn) external returns (uint256 out) {
        uint256 z = (aIn * (10000 - FEE)) / 10000;
        out = (reserve1 * z) / (reserve0 + z);
        require(out > 0 && out < reserve1, "OUT");
        IERC20(token0).transferFrom(msg.sender, address(this), aIn);
        reserve0 += aIn;
        reserve1 -= out;
        IERC20(token1).transfer(msg.sender, out);
    }

    /// Fixture-only: drain whole reserves to `to`. No access control on purpose:
    /// this pool is a test fixture, production MUST gate. Needed for atomic
    /// seed/unwind batches (seed from flash, remove at end, repay flash).
    function removeAll(address to) external {
        uint256 a0 = reserve0;
        uint256 a1 = reserve1;
        reserve0 = 0;
        reserve1 = 0;
        require(IERC20(token0).transfer(to, a0), "R0");
        require(IERC20(token1).transfer(to, a1), "R1");
    }
}

contract SpreadFlashExecutor {
    address public constant BAL = 0xBA12222222228d8Ba445958a75a0704d566BF2C8;
    address public constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address public constant WETH = 0x4200000000000000000000000000000000000006;
    address public constant ROUTER = 0x2626664c2603336E57B271c5C0b26F421741e481;

    address public immutable pool;
    uint256 public lastFlashFee;
    uint256 public lastNetUsdc;

    constructor(address pool_) { pool = pool_; }

    function executeLadder(uint256 flashUsdc) external {
        address[] memory tokens = new address[](1);
        uint256[] memory amounts = new uint256[](1);
        tokens[0] = USDC;
        amounts[0] = flashUsdc;
        IBalancerVault(BAL).flashLoan(address(this), tokens, amounts, "");
    }

    function receiveFlashLoan(address[] calldata, uint256[] calldata amounts, uint256[] calldata fees, bytes calldata) external {
        require(msg.sender == BAL, "CALLER");
        lastFlashFee = fees[0];
        uint256 preExisting = IERC20(USDC).balanceOf(address(this)) - amounts[0];
        IERC20(USDC).approve(pool, amounts[0]);
        uint256 wethOut = CounterPool(pool).swap1For0(amounts[0]);
        IERC20(WETH).approve(ROUTER, wethOut);
        IV3Router(ROUTER).exactInputSingle(
            IV3Router.EIP(WETH, USDC, 500, address(this), wethOut, 0, 0)
        );
        uint256 need = amounts[0] + fees[0];
        uint256 have = IERC20(USDC).balanceOf(address(this));
        require(have >= need + preExisting, "NOT_REPAID");
        IERC20(USDC).transfer(BAL, need);
        lastNetUsdc = have - need - preExisting;
    }
}

contract FlashFeeProbe {
    uint256 public lastFee;
    address public constant BAL = 0xBA12222222228d8Ba445958a75a0704d566BF2C8;
    function callFlash(uint256 amount) external {
        address[] memory tokens = new address[](1);
        uint256[] memory amts = new uint256[](1);
        tokens[0] = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
        amts[0] = amount;
        IBalancerVault(BAL).flashLoan(address(this), tokens, amts, "");
    }
    function receiveFlashLoan(address[] calldata, uint256[] calldata amounts, uint256[] calldata fees, bytes calldata) external {
        lastFee = fees[0];
        IERC20(0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913).transfer(BAL, amounts[0] + fees[0]);
    }
}

event DebugVal(string v);

contract SpreadLabTest {
    VmCheats vm = VmCheats(address(uint160(uint256(keccak256("hevm cheat code")))));
    address constant USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    address constant WETH = 0x4200000000000000000000000000000000000006;
    address constant BAL = 0xBA12222222228d8Ba445958a75a0704d566BF2C8;
    address constant V3POOL = 0xd0b53D9277642d899DF5C87A3966A349A798F224;
    address constant ROUTER = 0x2626664c2603336E57B271c5C0b26F421741e481;
    address payable constant SINK = payable(0x000000000000000000000000000000000000dEaD);
    uint256 constant USD = 1e6;
    uint256 constant COUNTER_USDC = 5_000 * USD;

    function setUp() external {
        vm.createSelectFork("https://mainnet.base.org");
        vm.label(USDC, "USDC"); vm.label(WETH, "WETH"); vm.label(BAL, "BalancerVault");
    }

    function extPriceRaw() internal view returns (uint256) {
        (uint160 sq,, , , , , ) = IV3Pool(V3POOL).slot0();
        uint256 a = uint256(sq);
        uint256 d = 1 << 96;
        return a * a * 1e18 / (d * d);
    }

    function num(uint256 x) internal pure returns (string memory) {
        if (x == 0) return "0";
        string memory out;
        while (x > 0) {
            uint8 dig = uint8(x % 10);
            out = string(abi.encodePacked(bytes1(uint8(dig + 48)), out));
            x /= 10;
        }
        return out;
    }

    function dec(uint256 usdc6) internal pure returns (string memory) {
        string memory whole = num(usdc6 / USD);
        string memory frac = num(usdc6 % USD);
        string memory padded = frac;
        while (bytes(padded).length < 6) {
            padded = string(abi.encodePacked("0", padded));
        }
        return string(abi.encodePacked(whole, ".", padded));
    }

    function testBalFlashIsZeroFeeOnLiveFork() external {
        FlashFeeProbe probe = new FlashFeeProbe();
        probe.callFlash(1 * USD);
        emit DebugVal("Balancer flash fee, wei=");
        emit DebugVal(num(probe.lastFee()));
        require(probe.lastFee() == 0, "FEE_NOT_ZERO");
    }

    function testLadderAt5pct() external { runLadder(500); }
    function testLadderAt15pct() external { runLadder(1500); }
    function testLadderAt30pct() external { runLadder(3000); }
    function testLadderAt500pct() external { runExtremeLadder(6); }
    function testLadderAt1000pct() external { runExtremeLadder(11); }

    function runExtremeLadder(uint256 multiplier) internal {
        emit DebugVal("header ext_USDC6 multiplier disl_bps");
        uint256 ext = extPriceRaw();
        emit DebugVal(dec(ext));
        emit DebugVal(num(multiplier));
        uint256 dislBps = 10000 - (10000 / multiplier);
        emit DebugVal(num(dislBps));

        uint256[6] memory fracs = [uint256(100), uint256(200), uint256(400), uint256(800), uint256(1600), uint256(3200)];
        for (uint256 j = 0; j < 6; ++j) {
            measure(dislBps, COUNTER_USDC, fracs[j]);
        }
    }

    function runLadder(uint256 dislBps) internal {
        emit DebugVal("header disl_bps ext_USDC6 gas_est_USDC6");
        emit DebugVal(num(dislBps));
        uint256 ext = extPriceRaw();
        emit DebugVal(dec(ext));
        emit DebugVal(dec(900_000 * block.basefee * ext / 1e18));

        uint256[6] memory fracs = [uint256(100), uint256(200), uint256(400), uint256(800), uint256(1600), uint256(3200)];
        for (uint256 j = 0; j < 6; ++j) {
            measure(dislBps, COUNTER_USDC, fracs[j]);
        }
    }

    function measure(uint256 dislBps, uint256 targetUsdc, uint256 fracBps) internal {
        resetTestAssets();
        uint256 extStart = extPriceRaw();
        uint256 ethFund = targetUsdc * 1e18 / extStart * 11 / 10;
        vm.deal(address(this), ethFund);
        IERC20(WETH).deposit{value: ethFund}();
        IERC20(WETH).approve(ROUTER, ethFund);

        uint256 usdcBefore = IERC20(USDC).balanceOf(address(this));
        IV3Router(ROUTER).exactInputSingle(
            IV3Router.EIP(WETH, USDC, 500, address(this), ethFund, 0, 0)
        );
        uint256 minted = IERC20(USDC).balanceOf(address(this)) - usdcBefore;
        uint256 seedUsdc = minted < targetUsdc ? minted : targetUsdc;
        if (seedUsdc == 0) {
            emit DebugVal("NO_USDC_FUND");
            return;
        }

        CounterPool counterPool = new CounterPool(WETH, USDC);
        uint256 extNow = extPriceRaw();
        uint256 internalP = extNow * (10000 - dislBps) / 10000;
        uint256 ethW = seedUsdc * 1e18 / internalP;
        uint256 wethBal = IERC20(WETH).balanceOf(address(this));
        if (wethBal < ethW) {
            uint256 deficit = ethW - wethBal;
            vm.deal(address(this), address(this).balance + deficit);
            IERC20(WETH).deposit{value: deficit}();
        }
        IERC20(WETH).approve(address(counterPool), ethW);
        IERC20(USDC).approve(address(counterPool), seedUsdc);
        counterPool.addLiquidity(ethW, seedUsdc);

        uint256 flashUsdc = seedUsdc * fracBps / 10000;
        if (flashUsdc == 0) return;

        SpreadFlashExecutor ex = new SpreadFlashExecutor(address(counterPool));
        uint256 gasBefore = gasleft();
        bool ok;
        try ex.executeLadder(flashUsdc) { ok = true; }
        catch { ok = false; }
        uint256 gasUsed = gasBefore > gasleft() ? gasBefore - gasleft() : 0;
        uint256 net = ex.lastNetUsdc();
        uint256 fee = ex.lastFlashFee();
        uint256 gasUsd6 = gasUsed * block.basefee * extNow / 1e18;

        emit DebugVal("row disl_bps seed_USDC6 flash_USDC6 net_USDC6 fee gas_USDC6 ok");
        emit DebugVal(num(dislBps));
        emit DebugVal(dec(seedUsdc));
        emit DebugVal(dec(flashUsdc));
        emit DebugVal(dec(net));
        emit DebugVal(num(fee));
        emit DebugVal(dec(gasUsd6));
        emit DebugVal(ok ? "ok" : "revert");
    }

    function resetTestAssets() internal {
        uint256 u = IERC20(USDC).balanceOf(address(this));
        if (u > 0) IERC20(USDC).transfer(SINK, u);
        uint256 w = IERC20(WETH).balanceOf(address(this));
        if (w > 0) IERC20(WETH).transfer(SINK, w);
        uint256 eth = address(this).balance;
        if (eth > 0) {
            (bool sent,) = SINK.call{value: eth}("");
            sent;
        }
    }
}
