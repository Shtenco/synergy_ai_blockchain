from __future__ import annotations

import argparse
import json
from decimal import Decimal
from pathlib import Path

from macro_economy.stability_engine import StabilityConfig, StabilityEconomyV8

D = Decimal


def main() -> int:
    p = argparse.ArgumentParser(description='Run SYNERGY Global Stability Fund v8')
    p.add_argument('--blocks', type=int, default=500)
    p.add_argument('--seed', type=int, default=77)
    p.add_argument('--reference-vol-multiplier', type=str, default='1')
    p.add_argument('--initial-capital', type=str, default='8700')
    p.add_argument('--disable-stability-fund', action='store_true')
    p.add_argument('--gas-aware', action='store_true')
    p.add_argument('--gas-min-interval-blocks', type=int, default=8)
    p.add_argument('--gas-safety-multiple', type=str, default='1.50')
    p.add_argument('--gas-risk-benefit-multiplier', type=str, default='3.0')
    p.add_argument('--output', required=True)
    args = p.parse_args()

    initial_capital = D(args.initial_capital)
    if initial_capital <= 0:
        raise SystemExit('--initial-capital must be positive')
    cfg = StabilityConfig(
        blocks=args.blocks,
        seed=args.seed,
        reference_vol_multiplier=D(args.reference_vol_multiplier),
        enable_stability_fund=not args.disable_stability_fund,
        capital_scale=initial_capital / D('8700'),
        enable_gas_aware_execution=args.gas_aware,
        gas_min_interval_blocks=args.gas_min_interval_blocks,
        gas_safety_multiple=D(args.gas_safety_multiple),
        gas_risk_benefit_multiplier=D(args.gas_risk_benefit_multiplier),
    )
    report = StabilityEconomyV8(cfg).run()
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({
        'output': str(out),
        'alpha_vs_hodl': str(report.system_alpha_vs_hodl),
        'max_drawdown_pct': str(report.max_adjusted_drawdown_pct),
        'floor_breaches': report.floor_breaches,
        'stability_fund_nav_end': str(report.stability_fund_nav_end),
        'hedge_gas_cost_usdc': str(report.hedge_gas_cost_usdc),
        'hedge_batch_executions': report.hedge_batch_executions,
        'hedge_execution_skips': report.hedge_execution_skips,
    }))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
