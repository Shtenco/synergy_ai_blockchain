import unittest
from decimal import Decimal

from macro_economy.agents import MarketAgent
from macro_economy.assets import default_base_assets
from macro_economy.portfolio import PortfolioAllocator
from macro_economy.yield_curve import SynergyYieldCurve

D = Decimal


class YieldCurveTests(unittest.TestCase):
    def test_normal_curve_has_standard_tenors_and_positive_term_premium(self):
        curve = SynergyYieldCurve(policy_rate=D('0.045'))
        quoted = curve.update(
            coverage_ratio=D('2.0'),
            realized_vol=D('0.04'),
            credit_utilization=D('0.25'),
            bad_debt_ratio=D('0'),
        )
        self.assertEqual(tuple(quoted), (1, 7, 30, 90, 365))
        self.assertGreater(quoted[365], quoted[1])
        self.assertGreater(quoted[1], D('0'))

    def test_curve_rises_when_credit_and_bad_debt_stress_rise(self):
        curve = SynergyYieldCurve(policy_rate=D('0.045'))
        calm = curve.update(D('2.0'), D('0.03'), D('0.20'), D('0'))
        stressed = curve.update(D('1.05'), D('0.12'), D('0.90'), D('0.08'))
        for tenor in calm:
            self.assertGreater(stressed[tenor], calm[tenor])

    def test_discount_factor_uses_actual_elapsed_seconds(self):
        curve = SynergyYieldCurve(policy_rate=D('0.05'))
        curve.update(D('2'), D('0.03'), D('0.2'), D('0'))
        one_hour = curve.discount_factor(D('0.08'), 3600)
        one_day = curve.discount_factor(D('0.08'), 86400)
        self.assertLess(one_day, one_hour)
        self.assertLess(one_hour, D('1'))


class PortfolioAllocatorTests(unittest.TestCase):
    def setUp(self):
        assets = default_base_assets()
        self.symbols = tuple(a.symbol for a in assets)
        self.prices = {a.symbol: D(str(a.initial_price)) for a in assets}
        self.prev = {s: p * D('0.997') for s, p in self.prices.items()}
        self.internal = {s: p * D('0.999') for s, p in self.prices.items()}
        self.curve = SynergyYieldCurve(policy_rate=D('0.05'))
        self.curve.update(D('2'), D('0.04'), D('0.3'), D('0'))
        self.alloc = PortfolioAllocator(self.symbols)

    def _weights(self, risk: float):
        agent = MarketAgent('a', D('100'), risk=risk, trend=0.4, mean_reversion=0.4)
        return self.alloc.target_weights(
            agent,
            prices=self.prices,
            prev_prices=self.prev,
            internal_prices=self.internal,
            rubx_price=D('1.0'),
            rubz_price=D('1.01'),
            rubz_fair_value=D('1.02'),
            curve=self.curve,
        )

    def test_target_weights_are_bounded_and_sum_to_one(self):
        weights = self._weights(0.55)
        self.assertEqual(set(weights), {'USDC', 'RUBX', 'RUBZ', *self.symbols})
        self.assertAlmostEqual(float(sum(weights.values())), 1.0, places=10)
        self.assertTrue(all(D('0') <= w <= D('1') for w in weights.values()))

    def test_riskier_agent_allocates_more_to_risk_assets(self):
        low = self._weights(0.15)
        high = self._weights(0.90)
        low_risk_assets = low['RUBZ'] + sum(low[s] for s in self.symbols)
        high_risk_assets = high['RUBZ'] + sum(high[s] for s in self.symbols)
        self.assertGreater(high_risk_assets, low_risk_assets)
        self.assertGreater(low['USDC'] + low['RUBX'], high['USDC'] + high['RUBX'])

    def test_allocator_is_deterministic_for_same_inputs(self):
        self.assertEqual(self._weights(0.5), self._weights(0.5))


if __name__ == '__main__':
    unittest.main()
