from decimal import Decimal as D

from macro_economy.gas_execution import GasAwareHedgeExecutor, GasExecutionConfig


def test_skips_rebalance_when_expected_benefit_does_not_cover_cost():
    ex = GasAwareHedgeExecutor(GasExecutionConfig(min_interval_blocks=1, safety_multiple=D('1.5')))
    d = ex.decide(block=10, desired_notional_change=D('2'), risk_benefit_usdc=D('0.002'), weth_price=D('2500'), active_legs=4)
    assert not d.execute
    assert d.required_benefit_usdc > d.risk_benefit_usdc


def test_batches_multiple_legs_into_one_transaction():
    ex = GasAwareHedgeExecutor(GasExecutionConfig(min_interval_blocks=1, safety_multiple=D('1')))
    one = ex.estimate_batch_gas_usd(weth_price=D('2500'), active_legs=1)
    ten = ex.estimate_batch_gas_usd(weth_price=D('2500'), active_legs=10)
    assert ten < one * D('10')


def test_executes_after_interval_when_benefit_covers_cost():
    ex = GasAwareHedgeExecutor(GasExecutionConfig(min_interval_blocks=4, safety_multiple=D('1.25')))
    ex.mark_executed(4)
    early = ex.decide(block=6, desired_notional_change=D('10'), risk_benefit_usdc=D('1'), weth_price=D('2500'), active_legs=5)
    later = ex.decide(block=8, desired_notional_change=D('10'), risk_benefit_usdc=D('1'), weth_price=D('2500'), active_legs=5)
    assert not early.execute
    assert later.execute
