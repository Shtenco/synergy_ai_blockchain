import unittest
from decimal import Decimal

from macro_economy.amm import CPMMPool
from macro_economy.assets import ReferenceMarket, default_base_assets


class CPMMTests(unittest.TestCase):
    def test_swap_increases_k_when_fee_is_retained(self):
        pool = CPMMPool("WETH", "USDC", Decimal("1"), Decimal("2400"), fee_bps=30)
        k0 = pool.k
        result = pool.swap_b_for_a(Decimal("100"))
        self.assertGreater(result.amount_out, 0)
        self.assertGreater(pool.k, k0)
        self.assertEqual(pool.reserve_b, Decimal("2500"))

    def test_marked_value_uses_external_price(self):
        pool = CPMMPool("WETH", "USDC", Decimal("2"), Decimal("1000"), fee_bps=30)
        self.assertEqual(pool.marked_value(Decimal("2400")), Decimal("5800"))


class ReferenceMarketTests(unittest.TestCase):
    def test_asset_universe_has_exactly_ten_non_usdc_base_assets(self):
        assets = default_base_assets()
        self.assertEqual(len(assets), 10)
        self.assertEqual(
            {a.symbol for a in assets},
            {"WETH", "cbBTC", "VVV", "VIRTUAL", "AERO", "cbETH", "USDe", "cbXRP", "TOSHI", "MORPHO"},
        )

    def test_reference_path_is_deterministic_for_seed(self):
        a = ReferenceMarket(default_base_assets(), seed=77, block_seconds=12)
        b = ReferenceMarket(default_base_assets(), seed=77, block_seconds=12)
        path_a = [a.step() for _ in range(5)]
        path_b = [b.step() for _ in range(5)]
        self.assertEqual(path_a, path_b)
        self.assertTrue(all(price > 0 for row in path_a for price in row.values()))


if __name__ == "__main__":
    unittest.main()
