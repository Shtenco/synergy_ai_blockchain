import unittest
from decimal import Decimal

from macro_economy.engine import MacroConfig, MacroEconomy

D = Decimal


class CapitalMarketsEngineIntegrationTests(unittest.TestCase):
    def test_credit_reserve_is_carved_out_of_triangle_without_creating_real_wealth(self):
        economy = MacroEconomy(MacroConfig(blocks=1, seed=77, noise_trades_per_block=0))
        self.assertGreater(economy.capital.credit.reserve_usdc, D('0'))
        # Credit reserve comes from the general Base/protocol treasury, not from the
        # canonical RUBX/RUBZ reserve; it is transferred, not minted.
        self.assertEqual(economy.triangle.treasury_usdc, D('1000'))
        self.assertEqual(
            economy.markets.treasury_usdc + economy.capital.credit.reserve_usdc,
            D('500'),
        )

    def test_capital_step_at_fixed_external_marks_conserves_system_real_wealth(self):
        economy = MacroEconomy(MacroConfig(blocks=1, seed=77, noise_trades_per_block=0))
        before = economy.system_real_wealth()
        economy.capital.step(
            block=1,
            prices=economy.prices,
            prev_prices=economy.prev_prices,
        )
        after = economy.system_real_wealth()
        self.assertEqual(after, before)

    def test_reference_run_contains_endogenous_capital_markets(self):
        report = MacroEconomy(MacroConfig(blocks=500, seed=77)).run()
        self.assertGreaterEqual(report.company_count, 4)
        self.assertGreater(report.equity_issuance_usdc, D('0'))
        self.assertGreater(report.bond_issuance_usdc, D('0'))
        self.assertGreater(report.portfolio_loans_originated, 0)
        self.assertEqual(set(report.yield_curve_end), {1, 7, 30, 90, 365})
        self.assertGreater(report.company_real_wealth_end, D('0'))
        self.assertGreater(report.agent_financial_claims_value_end, D('0'))
        self.assertAlmostEqual(float(sum(report.allocation_by_asset_end.values())), 1.0, places=8)

    def test_v4_reference_run_is_deterministic(self):
        a = MacroEconomy(MacroConfig(blocks=120, seed=91)).run()
        b = MacroEconomy(MacroConfig(blocks=120, seed=91)).run()
        self.assertEqual(a.closing_system_real_wealth, b.closing_system_real_wealth)
        self.assertEqual(a.yield_curve_end, b.yield_curve_end)
        self.assertEqual(a.bond_issuance_usdc, b.bond_issuance_usdc)
        self.assertEqual(a.credit_bad_debt_usdc, b.credit_bad_debt_usdc)

    def test_snapshot_exposes_curve_allocation_securities_and_credit(self):
        report = MacroEconomy(MacroConfig(blocks=60, seed=77)).run()
        snap = report.snapshots[-1]
        for key in (
            'yield_1d', 'yield_30d', 'yield_365d', 'credit_utilization',
            'company_real_wealth', 'equity_market_cap', 'outstanding_bond_face',
            'portfolio_debt', 'portfolio_margin_calls', 'portfolio_liquidations',
            'allocation',
        ):
            self.assertIn(key, snap)
        self.assertIn('USDC', snap['allocation'])
        self.assertIn('RUBX', snap['allocation'])
        self.assertIn('RUBZ', snap['allocation'])

    def test_allocation_snapshot_does_not_double_count_base_assets(self):
        economy = MacroEconomy(MacroConfig(blocks=1, seed=77, noise_trades_per_block=0))
        for agent in economy.agents:
            agent.cash_usdc = D('0')
            agent.rubx = D('0')
            agent.rubz = D('0')
            agent.holdings.clear()
        agent = economy.agents[0]
        agent.cash_usdc = D('100')
        price = economy.prices['WETH']
        agent.holdings['WETH'] = D('100') / price
        allocation = economy.capital.allocation_snapshot(economy.prices)
        self.assertAlmostEqual(float(allocation['USDC']), 0.5, places=10)
        self.assertAlmostEqual(float(allocation['WETH']), 0.5, places=10)

    def test_high_vol_high_ltv_stress_triggers_credit_risk_events(self):
        report = MacroEconomy(MacroConfig(
            blocks=500, seed=77, reference_vol_multiplier=D('7'),
            credit_reserve_usdc=D('300'), credit_principal_fraction=D('0.92'),
            credit_max_loan_usdc=D('30'), credit_max_capacity_fraction=D('1.05'),
        )).run()
        self.assertGreater(report.margin_calls, 0)
        self.assertGreater(report.liquidations, 0)
        self.assertGreaterEqual(report.credit_bad_debt_usdc, D('0'))
        self.assertEqual(report.elapsed_seconds, 6000)


if __name__ == '__main__':
    unittest.main()
