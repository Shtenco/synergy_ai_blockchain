from decimal import Decimal as D

from macro_economy.engine import MacroConfig, MacroEconomy
from macro_economy.dual_contour_engine import DualContourConfig, DualContourEconomy


def test_dual_contour_runs_500_blocks_and_keeps_shadow_mint_out_of_hard_nav():
    cfg = DualContourConfig(blocks=500, block_seconds=12, seed=77)
    eco = DualContourEconomy(cfg)
    before = eco.system_real_wealth()
    eco.shadow_ledger.mint("sWETH", D("1000000"), reason="test-print")
    assert eco.system_real_wealth() == before
    eco.shadow_ledger.burn("sWETH", D("1000000"), reason="test-cleanup")
    report = eco.run()
    assert report.blocks == 500
    assert report.elapsed_seconds == 6000
    assert len(report.snapshots) == 500
    assert report.synthetic_minted_usdc_equivalent > 0
    assert report.ai_actions > 0
    assert report.bridge_real_nav_end > 0
    assert report.shadow_supply_end["sWETH"] >= 0
    assert report.chain_height == 500
    assert report.chain_tip_hash
    assert report.max_synthetic_leverage_observed <= D("4")


def test_dual_contour_reports_matched_v4_and_drawdown_smoothing():
    base_cfg = MacroConfig(blocks=500, block_seconds=12, seed=77)
    base = MacroEconomy(base_cfg).run()
    dual = DualContourEconomy(DualContourConfig(blocks=500, block_seconds=12, seed=77)).run()
    # The v5 controller is explicitly a risk-smoothing overlay; it must not worsen
    # the matched-path maximum adjusted drawdown in the reference scenario.
    assert dual.max_adjusted_drawdown_pct <= base.max_adjusted_drawdown_pct
    assert dual.internal_mean_abs_spread_error_bps < D("15")
    assert dual.external_realized_inventory_pnl_usdc == dual.external_realized_inventory_pnl_usdc  # finite Decimal


def test_external_delta_control_can_be_disabled_for_matched_benchmark():
    off = DualContourEconomy(DualContourConfig(blocks=80, seed=9, enable_external_delta_control=False)).run()
    on = DualContourEconomy(DualContourConfig(blocks=80, seed=9, enable_external_delta_control=True)).run()
    assert off.bridge_external_volume_usdc == 0
    assert on.bridge_external_volume_usdc > 0


def test_shadow_mm_materially_reduces_internal_spread_error():
    on = DualContourEconomy(DualContourConfig(blocks=120, seed=11, enable_shadow_mm=True)).run()
    off = DualContourEconomy(DualContourConfig(blocks=120, seed=11, enable_shadow_mm=False)).run()
    assert on.internal_mean_abs_spread_error_bps < off.internal_mean_abs_spread_error_bps
