import json
import tempfile
import unittest
from pathlib import Path

from macro_economy.engine import MacroConfig, MacroEconomy
from scripts.render_macro_report import render_report


class MacroRenderTests(unittest.TestCase):
    def test_renderer_creates_html_and_many_png_charts(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            report = MacroEconomy(MacroConfig(blocks=25, seed=77)).run()
            src = root / "report.json"
            src.write_text(json.dumps(report.to_dict(), ensure_ascii=False), encoding="utf-8")
            html = render_report(src, root / "out")
            pngs = list((root / "out" / "charts").glob("*.png"))
            self.assertTrue(html.exists())
            self.assertGreaterEqual(len(pngs), 20)
            text = html.read_text(encoding="utf-8")
            self.assertIn("RUBX", text)
            self.assertIn("Capital Markets v4", text)
            self.assertIn("Yield curve", text)

    def test_renderer_direct_script_entrypoint_works_from_repo_root(self):
        import subprocess, sys
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            report = MacroEconomy(MacroConfig(blocks=5, seed=77)).run()
            src = root / "report.json"
            src.write_text(json.dumps(report.to_dict(), ensure_ascii=False), encoding="utf-8")
            out = root / "out"
            proc = subprocess.run(
                [sys.executable, "scripts/render_macro_report.py", str(src), str(out)],
                text=True, capture_output=True, check=False,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue((out / "macro_500_blocks_report.html").exists())


if __name__ == "__main__":
    unittest.main()
