import json
from pathlib import Path
import subprocess
import sys


def test_dual_contour_cli_writes_machine_readable_report(tmp_path: Path):
    out = tmp_path / "dual.json"
    proc = subprocess.run(
        [sys.executable, "run_dual_contour.py", "--blocks", "12", "--seed", "5", "--output", str(out)],
        cwd=Path(__file__).resolve().parents[1],
        text=True,
        capture_output=True,
    )
    assert proc.returncode == 0, proc.stderr
    payload = json.loads(out.read_text())
    assert payload["blocks"] == 12
    assert payload["elapsed_seconds"] == 144
    assert "system_alpha_vs_hodl" in payload
    assert "synthetic_minted_usdc_equivalent" in payload
