import unittest
from decimal import Decimal

from macro_economy.agents import MarketAgent
from macro_economy.assets import default_base_assets
from macro_economy.markets import ProtocolMarkets


class ProtocolMarketTests(unittest.TestCase):
    def setUp(self):
        self.assets = default_base_assets()
        self.prices = {a.symbol: Decimal(str(a.initial_price)) for a in self.assets}
        self.book = ProtocolMarkets(self.assets, usdc_per_pool=Decimal("250"), treasury_usdc=Decimal("500"))

    def test_book_has_ten_protocol_owned_asset_usdc_markets(self):
        self.assertEqual(len(self.book.pools), 10)
        self.assertEqual(set(self.book.pools), set(self.prices))

    def test_outside_taker_trade_is_measured_as_external_nav_delta(self):
        before = self.book.hard_nav(self.prices)
        trade = self.book.external_taker_trade("WETH", "buy", Decimal("25"), self.prices["WETH"])
        after = self.book.hard_nav(self.prices)
        self.assertEqual(after - before, trade.nav_delta)
        self.assertGreater(trade.fee_value_usdc, 0)
        self.assertGreater(trade.volume_usdc, 0)

    def test_informed_arb_size_extracts_value_after_external_price_jump(self):
        external = self.prices["WETH"] * Decimal("1.02")
        notional = self.book.arbitrage_notional("WETH", external)
        self.assertGreater(notional, 0)
        trade = self.book.external_taker_trade("WETH", "buy", notional, external)
        self.assertLess(trade.nav_delta, 0)
        self.assertLess(abs(self.book.deviation_bps("WETH", external)), Decimal("15"))

    def test_internal_agent_trade_conserves_combined_real_wealth_at_fixed_marks(self):
        agent = MarketAgent("a1", Decimal("100"), risk=0.5, trend=0.0, mean_reversion=1.0)
        combined0 = self.book.hard_nav(self.prices) + agent.real_wealth(self.prices)
        agent.buy_internal(self.book, "WETH", Decimal("20"))
        combined1 = self.book.hard_nav(self.prices) + agent.real_wealth(self.prices)
        self.assertEqual(combined1, combined0)

    def test_external_agent_trade_pays_real_fee(self):
        agent = MarketAgent("a1", Decimal("100"), risk=0.5, trend=1.0, mean_reversion=0.0)
        before = agent.real_wealth(self.prices)
        fee = agent.buy_external("WETH", Decimal("20"), self.prices["WETH"], fee_bps=10)
        after = agent.real_wealth(self.prices)
        self.assertEqual(before - after, fee)
        self.assertGreater(fee, 0)

    def test_internal_token_marks_do_not_enter_agent_real_wealth(self):
        agent = MarketAgent("a1", Decimal("100"), risk=0.5, trend=0.0, mean_reversion=1.0)
        agent.rubx = Decimal("50")
        agent.rubz = Decimal("25")
        self.assertEqual(agent.real_wealth(self.prices), Decimal("100"))
        self.assertGreater(agent.gross_wealth(self.prices, Decimal("1"), Decimal("1")), Decimal("100"))


if __name__ == "__main__":
    unittest.main()
