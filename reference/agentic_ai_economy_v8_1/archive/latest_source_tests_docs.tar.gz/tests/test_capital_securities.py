import unittest
from decimal import Decimal

from macro_economy.agents import MarketAgent
from macro_economy.securities import SecuritiesMarket
from macro_economy.yield_curve import SynergyYieldCurve

D = Decimal


class SecuritiesMarketTests(unittest.TestCase):
    def setUp(self):
        self.market = SecuritiesMarket(block_seconds=12)
        self.founder = MarketAgent('founder-agent', D('100'), risk=0.5, trend=0.2, mean_reversion=0.4)
        self.investor = MarketAgent('investor-agent', D('50'), risk=0.4, trend=0.2, mean_reversion=0.5)
        self.curve = SynergyYieldCurve(policy_rate=D('0.05'))
        self.curve.update(D('2'), D('0.04'), D('0.3'), D('0'))

    def total_cash(self):
        return self.founder.cash_usdc + self.investor.cash_usdc + sum(c.cash_usdc for c in self.market.companies.values())

    def test_company_formation_and_primary_equity_conserve_real_cash(self):
        before = self.total_cash()
        company = self.market.form_company(self.founder, contribution_usdc=D('40'), initial_shares=D('40'))
        self.assertEqual(company.equity_price({}), D('1'))
        issue = self.market.subscribe_equity(company.company_id, self.investor, D('10'), prices={})
        self.assertEqual(issue.cash_invested, D('10'))
        self.assertEqual(company.cash_usdc, D('50'))
        self.assertEqual(self.total_cash(), before)
        self.assertEqual(company.equity_price({}), D('1'))

    def test_dividend_is_cash_bounded_and_cannot_print_money(self):
        company = self.market.form_company(self.founder, contribution_usdc=D('20'), initial_shares=D('20'))
        self.market.subscribe_equity(company.company_id, self.investor, D('10'), prices={})
        before = self.total_cash()
        paid = self.market.pay_dividend(company.company_id, D('100'))
        self.assertEqual(paid, D('30'))
        self.assertEqual(company.cash_usdc, D('0'))
        self.assertEqual(self.total_cash(), before)

    def test_bond_subscription_transfers_cash_and_prices_from_curve(self):
        company = self.market.form_company(self.founder, contribution_usdc=D('20'), initial_shares=D('20'))
        before = self.total_cash()
        bond = self.market.issue_bond(
            company.company_id,
            self.investor,
            face_value=D('15'),
            coupon_rate=D('0.08'),
            current_block=10,
            maturity_block=310,
            curve=self.curve,
            issuer_spread=D('0.03'),
        )
        self.assertGreater(bond.issue_price, D('0'))
        self.assertLessEqual(bond.issue_price, bond.amount_due())
        self.assertEqual(self.total_cash(), before)
        self.assertEqual(bond.status, 'active')

    def test_bond_maturity_default_does_not_create_missing_cash(self):
        company = self.market.form_company(self.founder, contribution_usdc=D('2'), initial_shares=D('2'))
        bond = self.market.issue_bond(
            company.company_id,
            self.investor,
            face_value=D('10'),
            coupon_rate=D('0.50'),
            current_block=0,
            maturity_block=10,
            curve=self.curve,
            issuer_spread=D('0.10'),
        )
        # Drain company cash to represent an operating loss paid outside this market object.
        company.cash_usdc = D('1')
        investor_before = self.investor.cash_usdc
        result = self.market.settle_bond(bond.bond_id, self.investor, current_block=10)
        self.assertEqual(result.status, 'defaulted')
        self.assertEqual(result.amount_paid, D('1'))
        self.assertEqual(self.investor.cash_usdc, investor_before + D('1'))
        self.assertGreater(result.loss_given_default, D('0'))

    def test_bond_mark_value_falls_when_market_yield_rises(self):
        company = self.market.form_company(self.founder, contribution_usdc=D('20'), initial_shares=D('20'))
        bond = self.market.issue_bond(
            company.company_id,
            self.investor,
            face_value=D('10'),
            coupon_rate=D('0.08'),
            current_block=0,
            maturity_block=300,
            curve=self.curve,
            issuer_spread=D('0.02'),
        )
        low = self.market.mark_bond(bond.bond_id, current_block=20, annual_yield=D('0.05'))
        high = self.market.mark_bond(bond.bond_id, current_block=20, annual_yield=D('0.25'))
        self.assertLess(high, low)


if __name__ == '__main__':
    unittest.main()
