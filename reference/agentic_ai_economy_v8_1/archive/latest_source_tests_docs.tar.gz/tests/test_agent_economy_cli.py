import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class AgentEconomyCliTests(unittest.TestCase):
    def test_cli_runs_scenario_and_writes_json_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report.json"
            proc = subprocess.run(
                [
                    sys.executable,
                    "run_agent_economy.py",
                    "--agents", "8",
                    "--steps", "24",
                    "--seed", "17",
                    "--json", str(output),
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn("SYNERGY Agent Economy v2", proc.stdout)
            self.assertIn("Founder revenue", proc.stdout)
            self.assertIn("Insurance policies", proc.stdout)
            self.assertIn("Strategy updates", proc.stdout)
            self.assertTrue(output.exists())
            payload = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(payload["agent_count"], 8)
            self.assertEqual(payload["steps"], 24)
            self.assertEqual(payload["conservation_gap"], "0E-12")


if __name__ == "__main__":
    unittest.main()
