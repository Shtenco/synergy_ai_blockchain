import unittest
from decimal import Decimal

from agent_economy.labor import LaborMarket
from agent_economy.ledger import Ledger
from agent_economy.models import AgentGenome, AgentState
from agent_economy.reputation import ReputationEngine


def agent(agent_id: str, skill: float, rep: float = 0.5) -> AgentState:
    return AgentState(
        agent_id=agent_id,
        name=agent_id,
        profession="builder",
        genome=AgentGenome(curiosity=0.7, entrepreneurship=0.7),
        skills={"coding": skill, "research": skill / 2},
        reputation=rep,
    )


class LaborMarketTests(unittest.TestCase):
    def setUp(self):
        self.ledger = Ledger()
        self.rep = ReputationEngine()
        self.market = LaborMarket(self.ledger, self.rep, founder_account="founder:treasury", fee_bps=500)
        self.a = agent("agent:a", 0.9, 0.7)
        self.b = agent("agent:b", 0.6, 0.5)
        self.ledger.seed(self.a.agent_id, "20")
        self.ledger.seed(self.b.agent_id, "5")

    def test_external_job_escrow_is_new_external_income_and_completion_pays_fee(self):
        before = self.ledger.system_cash()
        job = self.market.post_external_job(
            client_id="external:buyer-1",
            title="Build analytics worker",
            skill="coding",
            budget="10",
            min_skill=0.5,
            tick=1,
        )
        self.market.submit_bid(job.job_id, self.a, price="9", tick=1)
        self.market.award(job.job_id, self.a.agent_id, tick=1)
        self.market.complete(job.job_id, self.a, quality=0.9, tick=2)

        self.assertEqual(self.ledger.system_cash() - before, Decimal("10"))
        self.assertEqual(self.ledger.balance(self.a.agent_id), Decimal("28.55"))
        self.assertEqual(self.ledger.balance("founder:treasury"), Decimal("0.45"))
        self.assertEqual(self.ledger.balance(job.escrow_account), Decimal("1.00"))
        self.assertEqual(job.status, "completed")
        self.assertEqual(self.a.memory.jobs_completed, 1)
        self.assertGreater(self.a.reputation, 0.7)

    def test_internal_job_only_redistributes_existing_cash(self):
        before = self.ledger.system_cash()
        job = self.market.post_internal_job(
            client_id=self.a.agent_id,
            title="Research module",
            skill="research",
            budget="4",
            min_skill=0.2,
            tick=1,
        )
        self.market.submit_bid(job.job_id, self.b, price="3", tick=1)
        self.market.award(job.job_id, self.b.agent_id, tick=1)
        self.market.complete(job.job_id, self.b, quality=0.8, tick=2)

        self.assertEqual(self.ledger.system_cash(), before)
        self.assertEqual(self.ledger.external_income(), Decimal("0"))
        self.assertEqual(self.ledger.balance("founder:treasury"), Decimal("0.15"))

    def test_agent_can_subcontract_work_to_another_agent(self):
        parent = self.market.post_external_job(
            client_id="external:buyer-2",
            title="Complex system",
            skill="coding",
            budget="12",
            min_skill=0.5,
            tick=1,
        )
        self.market.submit_bid(parent.job_id, self.a, price="10", tick=1)
        self.market.award(parent.job_id, self.a.agent_id, tick=1)

        child = self.market.create_subcontract(
            parent_job_id=parent.job_id,
            contractor=self.a,
            title="Research dependency",
            skill="research",
            budget="3",
            min_skill=0.2,
            tick=2,
        )
        self.market.submit_bid(child.job_id, self.b, price="2.5", tick=2)
        self.market.award(child.job_id, self.b.agent_id, tick=2)
        self.market.complete(child.job_id, self.b, quality=0.9, tick=3)

        self.assertEqual(child.parent_job_id, parent.job_id)
        self.assertEqual(parent.contractor_id, self.a.agent_id)
        self.assertEqual(self.a.memory.hired_agents, 1)
        self.assertEqual(child.status, "completed")


if __name__ == "__main__":
    unittest.main()
