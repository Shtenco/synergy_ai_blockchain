import unittest

from agent_economy.engine import AgentEconomy
from agent_economy.scenario import stress_credit_config


class ScenarioTests(unittest.TestCase):
    def test_stress_credit_profile_creates_real_defaults_without_breaking_accounting(self):
        report = AgentEconomy(stress_credit_config(seed=3)).run()
        self.assertGreater(report.loans_defaulted, 0)
        self.assertGreater(report.bad_debt_loss, 0)
        self.assertGreater(report.external_expense, 0)
        self.assertEqual(report.conservation_gap, 0)


if __name__ == "__main__":
    unittest.main()
