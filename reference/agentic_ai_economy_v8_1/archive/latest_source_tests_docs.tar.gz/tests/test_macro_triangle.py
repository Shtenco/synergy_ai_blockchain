import unittest
from decimal import Decimal

from macro_economy.triangle import TriangleEconomy


class TriangleEconomyTests(unittest.TestCase):
    def setUp(self):
        self.tri = TriangleEconomy.default()

    def test_initial_structure_maps_debt_equity_and_cash(self):
        self.assertEqual(self.tri.hard_nav(), Decimal("2000"))
        self.assertEqual(self.tri.rubx_liability(), Decimal("1000"))
        self.assertEqual(self.tri.residual_equity(), Decimal("1000"))
        self.assertEqual(self.tri.rubz_fair_value(), Decimal("1"))
        self.assertEqual(self.tri.coverage_ratio(), Decimal("2"))

    def test_minting_internal_tokens_does_not_create_hard_nav(self):
        hard0 = self.tri.hard_nav()
        coverage0 = self.tri.coverage_ratio()
        self.tri.mint_rubx(Decimal("100"))
        self.assertEqual(self.tri.hard_nav(), hard0)
        self.assertLess(self.tri.coverage_ratio(), coverage0)

    def test_protocol_mint_sell_only_reallocates_real_reserves(self):
        hard0 = self.tri.hard_nav()
        self.tri.mint_sell_rubx(Decimal("10"))
        self.assertEqual(self.tri.hard_nav(), hard0)
        self.assertGreater(self.tri.treasury_usdc, Decimal("1000"))

    def test_protocol_buy_burn_only_reallocates_real_reserves(self):
        self.tri.xu.swap_a_for_b(Decimal("80"))  # push RUBX below target
        hard0 = self.tri.hard_nav()
        supply0 = self.tri.rubx_supply
        burned = self.tri.buy_burn_rubx(Decimal("20"))
        self.assertGreater(burned, 0)
        self.assertLess(self.tri.rubx_supply, supply0)
        self.assertEqual(self.tri.hard_nav(), hard0)

    def test_triangle_arbitrage_is_hardnav_neutral(self):
        self.tri.xz.swap_a_for_b(Decimal("120"))
        hard0 = self.tri.hard_nav()
        result = self.tri.triangular_arbitrage(Decimal("5"))
        self.assertIn(result["action"], {"u-x-z-u", "u-z-x-u", "none"})
        self.assertEqual(self.tri.hard_nav(), hard0)

    def test_xz_rebalance_mint_is_hardnav_neutral(self):
        hard0 = self.tri.hard_nav()
        self.tri.add_xz_liquidity_by_mint(Decimal("25"), Decimal("25"))
        self.assertEqual(self.tri.hard_nav(), hard0)


if __name__ == "__main__":
    unittest.main()
