import unittest
from decimal import Decimal

from agent_economy.capital import CapitalMarket
from agent_economy.founder import FounderTreasury
from agent_economy.ledger import InsufficientFunds, Ledger
from agent_economy.models import AgentGenome, AgentState


def mk(agent_id: str) -> AgentState:
    return AgentState(agent_id=agent_id, name=agent_id, profession="operator", genome=AgentGenome())


class CapitalMarketTests(unittest.TestCase):
    def setUp(self):
        self.ledger = Ledger()
        self.capital = CapitalMarket(self.ledger, founder_account="founder:treasury", distribution_fee_bps=200)
        self.founder = FounderTreasury(self.ledger, account="founder:treasury")
        self.owner = mk("agent:owner")
        self.investor = mk("agent:investor")
        self.ledger.seed(self.owner.agent_id, "50")
        self.ledger.seed(self.investor.agent_id, "30")

    def test_company_formation_and_investment_principal_are_not_external_revenue(self):
        company = self.capital.form_company(self.owner, name="Aster Labs", specialty="research", seed_capital="10", tick=1)
        investment = self.capital.invest(self.investor, company, amount="12", revenue_share="0.20", tick=2)

        self.assertEqual(self.ledger.external_income(), Decimal("0"))
        self.assertEqual(self.founder.total_revenue(), Decimal("0"))
        self.assertEqual(investment.principal, Decimal("12"))
        self.assertEqual(self.ledger.balance(company.treasury_account), Decimal("22"))
        self.assertIn(self.investor.agent_id, company.investor_ids)

    def test_investment_return_requires_company_cash_and_pays_settlement_fee(self):
        company = self.capital.form_company(self.owner, name="Aster Labs", specialty="research", seed_capital="2", tick=1)
        investment = self.capital.invest(self.investor, company, amount="3", revenue_share="0.25", tick=2)
        self.capital.record_external_revenue(company, amount="20", source_id="external:client", tick=3)
        before_investor = self.ledger.balance(self.investor.agent_id)

        self.capital.distribute(investment.investment_id, company, self.investor, gross_amount="5", tick=4)

        self.assertEqual(self.ledger.balance(self.investor.agent_id) - before_investor, Decimal("4.90"))
        self.assertEqual(self.ledger.balance("founder:treasury"), Decimal("0.10"))
        self.assertEqual(investment.distributions, Decimal("4.90"))
        self.assertEqual(self.ledger.external_income(), Decimal("20"))

    def test_distribution_cannot_create_cash(self):
        company = self.capital.form_company(self.owner, name="TinyCo", specialty="coding", seed_capital="1", tick=1)
        investment = self.capital.invest(self.investor, company, amount="1", revenue_share="0.5", tick=2)
        with self.assertRaises(InsufficientFunds):
            self.capital.distribute(investment.investment_id, company, self.investor, gross_amount="5", tick=3)

    def test_founder_report_splits_external_attributed_and_internal_fees(self):
        self.ledger.seed("agent:a", "10")
        self.ledger.transfer(
            "agent:a", "founder:treasury", "1", "marketplace_fee", "job:internal",
            metadata={"funding_source": "internal"},
        )
        self.ledger.external_inflow("escrow:external", "10", "external_job_funding", "job:external")
        self.ledger.transfer(
            "escrow:external", "founder:treasury", "2", "marketplace_fee", "job:external",
            metadata={"funding_source": "external"},
        )

        report = self.founder.report()
        self.assertEqual(report["total_revenue"], Decimal("3"))
        self.assertEqual(report["external_attributed_revenue"], Decimal("2"))
        self.assertEqual(report["internal_fee_revenue"], Decimal("1"))
        self.assertEqual(report["by_category"]["marketplace_fee"], Decimal("3"))


if __name__ == "__main__":
    unittest.main()
