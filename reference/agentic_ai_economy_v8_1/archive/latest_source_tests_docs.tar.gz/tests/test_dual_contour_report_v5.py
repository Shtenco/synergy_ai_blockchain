import json
from pathlib import Path

from macro_economy.dual_contour_engine import DualContourConfig, DualContourEconomy
from scripts.render_dual_contour_report import render_dual_contour_report


def test_dual_contour_renderer_builds_html_and_many_charts(tmp_path: Path):
    report = DualContourEconomy(DualContourConfig(blocks=30, seed=4)).run()
    report_path = tmp_path / "report.json"
    report_path.write_text(json.dumps(report.to_dict()), encoding="utf-8")
    out = tmp_path / "rendered"
    html = render_dual_contour_report(report_path, out)
    charts = sorted((out / "charts").glob("*.png"))
    assert html.exists()
    assert len(charts) >= 16
    text = html.read_text(encoding="utf-8")
    assert "SYNERGY CHAIN" in text
    assert "HardNAV" in text
