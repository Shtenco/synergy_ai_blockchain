import json
import subprocess
import sys
from pathlib import Path


def test_v8_cli_writes_json(tmp_path):
    out = tmp_path / 'v8.json'
    proc = subprocess.run(
        [sys.executable, 'run_stability_v8.py', '--blocks', '12', '--seed', '9', '--output', str(out)],
        cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr
    data = json.loads(out.read_text())
    assert data['blocks'] == 12
    assert data['stability_fund_initial_allocation'] == '4350.000000000000'


def test_v8_renderer_creates_total_wealth_first_chart(tmp_path):
    root = Path(__file__).resolve().parents[1]
    source = tmp_path / 'source.json'
    subprocess.run(
        [sys.executable, 'run_stability_v8.py', '--blocks', '20', '--seed', '3', '--output', str(source)],
        cwd=root, check=True, capture_output=True, text=True,
    )
    out = tmp_path / 'rendered'
    proc = subprocess.run(
        [sys.executable, 'scripts/render_stability_v8_report.py', str(source), str(out)],
        cwd=root, capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr
    assert (out / 'charts' / '01_total_system_wealth.png').exists()
    assert (out / 'stability_v8_report.html').exists()
