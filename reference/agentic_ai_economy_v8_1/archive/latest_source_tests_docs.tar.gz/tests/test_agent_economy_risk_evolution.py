import unittest
from decimal import Decimal

from agent_economy.credit import CreditMarket
from agent_economy.evolution import EvolutionEngine
from agent_economy.ledger import Ledger
from agent_economy.models import AgentGenome, AgentState
from agent_economy.reputation import ReputationEngine
from agent_economy.risk import BankruptcyEngine, InsuranceMarket


def mk(agent_id: str, cash_rep: float = 0.7, **genome) -> AgentState:
    return AgentState(
        agent_id=agent_id,
        name=agent_id,
        profession="finance",
        genome=AgentGenome(**genome),
        reputation=cash_rep,
    )


class InsuranceAndBankruptcyTests(unittest.TestCase):
    def setUp(self):
        self.ledger = Ledger()
        self.rep = ReputationEngine()
        self.credit = CreditMarket(self.ledger, self.rep, founder_account="founder:treasury")
        self.insurance = InsuranceMarket(self.ledger, founder_account="founder:treasury", platform_fee_bps=500)
        self.lender = mk("agent:lender")
        self.borrower = mk("agent:borrower", risk=0.9)
        self.insurer = mk("agent:insurer")
        self.ledger.seed(self.lender.agent_id, "100")
        self.ledger.seed(self.borrower.agent_id, "10")
        self.ledger.seed(self.insurer.agent_id, "20")

    def test_default_insurance_redistributes_cash_without_minting(self):
        loan = self.credit.originate_loan(
            self.lender, self.borrower, principal="20", term_ticks=5, collateral_ratio="0.10", tick=1
        )
        policy = self.insurance.purchase_loan_cover(
            self.lender, self.insurer, loan, coverage_ratio="0.50", premium_rate="0.05", tick=1
        )
        self.ledger.external_outflow(
            self.borrower.agent_id, self.ledger.balance(self.borrower.agent_id), "venture_loss", "loss"
        )
        self.credit.settle_loan(loan.loan_id, lender=self.lender, borrower=self.borrower, tick=6)
        before_claim = self.ledger.system_cash()

        self.insurance.settle_loan_policy(policy.policy_id, loan, holder=self.lender, insurer=self.insurer, tick=6)

        self.assertIn(policy.status, {"claimed", "insurer_default"})
        self.assertGreater(policy.claim_paid, Decimal("0"))
        self.assertEqual(self.ledger.system_cash(), before_claim)
        self.assertGreater(self.ledger.balance("founder:treasury"), Decimal("0"))

    def test_insurer_can_default_instead_of_printing_claim_cash(self):
        poor_insurer = mk("agent:poor-insurer")
        self.ledger.seed(poor_insurer.agent_id, "0.10")
        loan = self.credit.originate_loan(
            self.lender, self.borrower, principal="20", term_ticks=5, collateral_ratio="0", tick=1
        )
        policy = self.insurance.purchase_loan_cover(
            self.lender, poor_insurer, loan, coverage_ratio="1", premium_rate="0.01", tick=1
        )
        self.ledger.external_outflow(
            self.borrower.agent_id, self.ledger.balance(self.borrower.agent_id), "venture_loss", "loss2"
        )
        self.credit.settle_loan(loan.loan_id, lender=self.lender, borrower=self.borrower, tick=6)
        before = self.ledger.system_cash()

        self.insurance.settle_loan_policy(policy.policy_id, loan, holder=self.lender, insurer=poor_insurer, tick=6)

        self.assertEqual(policy.status, "insurer_default")
        self.assertGreater(policy.claim_shortfall, Decimal("0"))
        self.assertEqual(self.ledger.system_cash(), before)

    def test_bankruptcy_marks_insolvent_agent_inactive(self):
        engine = BankruptcyEngine()
        agent = mk("agent:failed")
        case = engine.evaluate(agent, net_worth=Decimal("-3.5"), tick=10)
        self.assertIsNotNone(case)
        self.assertFalse(agent.active)
        self.assertEqual(case.status, "opened")


class EvolutionTests(unittest.TestCase):
    def test_strategy_is_initialized_from_genome_and_adapts_to_history(self):
        agent = mk(
            "agent:adaptive",
            risk=0.8,
            curiosity=0.9,
            policy_curiosity=0.95,
            entrepreneurship=0.8,
            trust=0.6,
            patience=0.5,
            leverage_tolerance=0.8,
            liquidity_preference=0.3,
        )
        self.assertGreater(agent.strategy.research_intensity, 0.8)
        before_risk = agent.strategy.risk_budget
        before_hiring = agent.strategy.hiring_appetite
        agent.memory.loan_defaults = 2
        agent.memory.jobs_completed = 5
        agent.memory.research_reports = 3

        updates = EvolutionEngine().adapt(agent, wealth_change=Decimal("5"))

        self.assertGreater(updates, 0)
        self.assertLess(agent.strategy.risk_budget, before_risk)
        self.assertGreater(agent.strategy.hiring_appetite, before_hiring)
        self.assertGreaterEqual(agent.strategy.research_intensity, 0.8)


class RiskEvolutionIntegrationTests(unittest.TestCase):
    def test_engine_integrates_insurance_bankruptcy_and_strategy_updates(self):
        from agent_economy.engine import AgentEconomy
        from agent_economy.scenario import stress_credit_config

        economy = AgentEconomy(stress_credit_config(seed=3))
        report = economy.run()

        self.assertGreater(report.insurance_policies, 0)
        self.assertGreater(report.strategy_updates, 0)
        self.assertGreater(report.insurance_claims_paid, Decimal("0"))
        self.assertGreaterEqual(report.bankruptcy_cases, 0)
        self.assertEqual(report.conservation_gap, Decimal("0"))


if __name__ == "__main__":
    unittest.main()
