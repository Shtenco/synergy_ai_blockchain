import unittest
from decimal import Decimal

from agent_economy.ledger import InsufficientFunds, Ledger
from agent_economy.models import AgentGenome, AgentState, ExecutionMandate


class LedgerTests(unittest.TestCase):
    def test_internal_transfer_conserves_system_cash(self):
        ledger = Ledger()
        ledger.seed("agent:a", "100")
        ledger.seed("agent:b", "50")
        before = ledger.system_cash()

        ledger.transfer("agent:a", "agent:b", "25", "trade", contract_id="t-1")

        self.assertEqual(ledger.balance("agent:a"), Decimal("75"))
        self.assertEqual(ledger.balance("agent:b"), Decimal("75"))
        self.assertEqual(ledger.system_cash(), before)
        self.assertEqual(ledger.external_income(), Decimal("0"))

    def test_external_income_increases_system_cash_and_is_attributed(self):
        ledger = Ledger()
        ledger.seed("agent:a", "10")
        before = ledger.system_cash()

        ledger.external_inflow("agent:a", "12.50", "external_job", contract_id="job-1")

        self.assertEqual(ledger.system_cash() - before, Decimal("12.50"))
        self.assertEqual(ledger.external_income(), Decimal("12.50"))
        self.assertEqual(ledger.category_total("external_job", destination="agent:a"), Decimal("12.50"))

    def test_insufficient_internal_balance_is_rejected(self):
        ledger = Ledger()
        ledger.seed("agent:a", "1")
        with self.assertRaises(InsufficientFunds):
            ledger.transfer("agent:a", "agent:b", "1.01", "trade")

    def test_founder_revenue_categories_can_be_queried(self):
        ledger = Ledger()
        ledger.seed("agent:a", "10")
        ledger.transfer("agent:a", "founder:treasury", "0.25", "marketplace_fee", "job-1")
        ledger.transfer("agent:a", "founder:treasury", "0.10", "credit_origination_fee", "loan-1")

        self.assertEqual(
            ledger.category_total("marketplace_fee", destination="founder:treasury"), Decimal("0.25")
        )
        self.assertEqual(
            ledger.category_total("credit_origination_fee", destination="founder:treasury"), Decimal("0.10")
        )


class CoreModelTests(unittest.TestCase):
    def test_agent_genome_is_heterogeneous_and_bounded(self):
        genome = AgentGenome(
            risk=0.4,
            curiosity=0.8,
            policy_curiosity=0.9,
            entrepreneurship=0.7,
            trust=0.6,
            patience=0.5,
            leverage_tolerance=0.3,
            liquidity_preference=0.2,
        )
        agent = AgentState(
            agent_id="agent:1",
            name="Aster",
            profession="researcher",
            genome=genome,
            skills={"research": 0.9, "coding": 0.4},
        )
        self.assertEqual(agent.genome.policy_curiosity, 0.9)
        self.assertEqual(agent.skills["research"], 0.9)

    def test_execution_mandate_defaults_to_simulation_and_enforces_limits(self):
        mandate = ExecutionMandate()
        self.assertEqual(mandate.mode, "simulation")
        self.assertTrue(mandate.allows("job_payment", Decimal("100"), Decimal("0")))
        self.assertFalse(mandate.allows("job_payment", Decimal("1001"), Decimal("0")))
        self.assertFalse(mandate.allows("unknown_action", Decimal("1"), Decimal("0")))


if __name__ == "__main__":
    unittest.main()
