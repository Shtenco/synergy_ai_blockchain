import json
from pathlib import Path


def test_base_fork_manifest_encodes_one_way_inventory_design():
    p = Path(__file__).resolve().parents[1] / "synergy_chain" / "base_fork_manifest.json"
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["chain"]["name"] == "SYNERGY CHAIN"
    assert data["chain"]["parent_family"] == "Base / OP Stack"
    assert data["bridge"]["external_redemption_enabled"] is False
    assert len(data["assets"]) == 13
    assert "sRUBX" in data["assets"] and "sWETH" in data["assets"]
    assert data["accounting"]["synthetic_supply_counts_as_hard_nav"] is False
