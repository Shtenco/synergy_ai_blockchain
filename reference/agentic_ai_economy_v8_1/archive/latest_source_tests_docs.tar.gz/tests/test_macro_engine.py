import unittest
from decimal import Decimal

from macro_economy.engine import MacroConfig, MacroEconomy


class MacroEconomyEngineTests(unittest.TestCase):
    def test_reference_run_is_exactly_500_twelve_second_blocks(self):
        report = MacroEconomy(MacroConfig()).run()
        self.assertEqual(report.blocks, 500)
        self.assertEqual(report.block_seconds, 12)
        self.assertEqual(report.elapsed_seconds, 6000)
        self.assertEqual(len(report.snapshots), 500)
        self.assertEqual(report.snapshots[0]["time_seconds"], 12)
        self.assertEqual(report.snapshots[-1]["time_seconds"], 6000)

    def test_reference_run_is_deterministic(self):
        a = MacroEconomy(MacroConfig(seed=77)).run()
        b = MacroEconomy(MacroConfig(seed=77)).run()
        self.assertEqual(a.closing_system_real_wealth, b.closing_system_real_wealth)
        self.assertEqual(a.system_alpha_vs_hodl, b.system_alpha_vs_hodl)
        self.assertEqual(a.final_prices, b.final_prices)

    def test_capital_adjusted_wealth_and_hodl_alpha_are_explicit(self):
        report = MacroEconomy(MacroConfig(seed=77)).run()
        self.assertEqual(
            report.capital_adjusted_closing_wealth,
            report.closing_system_real_wealth - report.net_external_capital_flow,
        )
        self.assertEqual(
            report.system_alpha_vs_hodl,
            report.capital_adjusted_closing_wealth - report.closing_hodl_benchmark,
        )

    def test_founder_external_revenue_is_bounded_by_real_external_fee_value(self):
        report = MacroEconomy(MacroConfig(seed=77)).run()
        self.assertGreaterEqual(report.founder_external_revenue, Decimal("0"))
        self.assertLessEqual(report.founder_external_revenue, report.external_fee_value_usdc)

    def test_minting_rubx_cannot_raise_system_real_wealth(self):
        economy = MacroEconomy(MacroConfig(blocks=1, seed=77))
        before = economy.system_real_wealth()
        economy.triangle.mint_rubx(Decimal("100"))
        after = economy.system_real_wealth()
        self.assertEqual(after, before)


if __name__ == "__main__":
    unittest.main()
