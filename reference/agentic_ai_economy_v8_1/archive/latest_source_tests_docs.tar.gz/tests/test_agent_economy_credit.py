import unittest
from decimal import Decimal

from agent_economy.credit import CreditMarket
from agent_economy.ledger import Ledger
from agent_economy.models import AgentGenome, AgentState
from agent_economy.reputation import ReputationEngine


def mk(agent_id: str, rep: float) -> AgentState:
    return AgentState(agent_id=agent_id, name=agent_id, profession="finance", genome=AgentGenome(), reputation=rep)


class CreditMarketTests(unittest.TestCase):
    def setUp(self):
        self.ledger = Ledger()
        self.rep = ReputationEngine()
        self.market = CreditMarket(
            self.ledger,
            self.rep,
            founder_account="founder:treasury",
            base_rate="0.06",
            risk_spread="0.30",
            origination_fee_bps=100,
        )
        self.lender = mk("agent:lender", 0.9)
        self.safe = mk("agent:safe", 0.9)
        self.risky = mk("agent:risky", 0.2)
        self.ledger.seed(self.lender.agent_id, "100")
        self.ledger.seed(self.safe.agent_id, "30")
        self.ledger.seed(self.risky.agent_id, "30")

    def test_riskier_borrower_pays_higher_rate(self):
        self.assertLess(self.market.quote_rate(self.safe), self.market.quote_rate(self.risky))

    def test_loan_origination_locks_collateral_and_charges_founder_fee(self):
        before = self.ledger.system_cash()
        loan = self.market.originate_loan(
            self.lender,
            self.safe,
            principal="10",
            term_ticks=30,
            collateral_ratio="0.5",
            tick=1,
        )
        self.assertEqual(self.ledger.balance(loan.collateral_account), Decimal("5.0"))
        self.assertEqual(self.ledger.balance("founder:treasury"), Decimal("0.1"))
        self.assertEqual(self.ledger.system_cash(), before)
        self.assertEqual(loan.status, "active")

    def test_repayment_returns_collateral_and_updates_reputation(self):
        loan = self.market.originate_loan(
            self.lender,
            self.safe,
            principal="10",
            term_ticks=30,
            collateral_ratio="0.5",
            tick=1,
        )
        old_rep = self.safe.reputation
        self.market.settle_loan(loan.loan_id, lender=self.lender, borrower=self.safe, tick=31)

        self.assertEqual(loan.status, "repaid")
        self.assertEqual(self.ledger.balance(loan.collateral_account), Decimal("0.0"))
        self.assertGreater(self.safe.reputation, old_rep)
        self.assertEqual(self.safe.memory.loans_repaid, 1)

    def test_default_liquidates_collateral_and_records_real_lender_loss(self):
        loan = self.market.originate_loan(
            self.lender,
            self.risky,
            principal="20",
            term_ticks=10,
            collateral_ratio="0.25",
            tick=1,
        )
        spendable = self.ledger.balance(self.risky.agent_id)
        self.ledger.external_outflow(self.risky.agent_id, spendable, "business_loss", "loss-1")
        before_income = self.ledger.external_income()

        self.market.settle_loan(loan.loan_id, lender=self.lender, borrower=self.risky, tick=11)

        self.assertEqual(loan.status, "defaulted")
        self.assertGreater(loan.loss_given_default, Decimal("0"))
        self.assertEqual(self.risky.memory.loan_defaults, 1)
        self.assertEqual(self.ledger.external_income(), before_income)
        self.assertEqual(self.ledger.balance(loan.collateral_account), Decimal("0.00"))

    def test_term_deposit_moves_principal_and_pays_interest_only_from_institution_cash(self):
        bank = mk("agent:bank", 0.8)
        saver = mk("agent:saver", 0.7)
        self.ledger.seed(bank.agent_id, "50")
        self.ledger.seed(saver.agent_id, "20")
        dep = self.market.open_deposit(saver, bank, principal="10", annual_rate="0.10", term_ticks=36, tick=1)
        before = self.ledger.system_cash()

        self.market.settle_deposit(dep.deposit_id, depositor=saver, institution=bank, tick=37)

        self.assertEqual(dep.status, "repaid")
        self.assertEqual(self.ledger.system_cash(), before)
        self.assertGreater(self.ledger.balance(saver.agent_id), Decimal("20"))

    def test_deposit_default_does_not_mint_missing_cash(self):
        bank = mk("agent:bank2", 0.8)
        saver = mk("agent:saver2", 0.7)
        self.ledger.seed(bank.agent_id, "0.10")
        self.ledger.seed(saver.agent_id, "10")
        dep = self.market.open_deposit(saver, bank, principal="5", annual_rate="0.20", term_ticks=365, tick=1)
        self.ledger.external_outflow(bank.agent_id, self.ledger.balance(bank.agent_id), "bank_loss", "loss-2")
        before_cash = self.ledger.system_cash()

        self.market.settle_deposit(dep.deposit_id, depositor=saver, institution=bank, tick=366)

        self.assertEqual(dep.status, "defaulted")
        self.assertEqual(bank.memory.deposit_defaults, 1)
        self.assertEqual(self.ledger.system_cash(), before_cash)


if __name__ == "__main__":
    unittest.main()
