import unittest
from decimal import Decimal

from agent_economy.engine import AgentEconomy, EconomyConfig
from agent_economy.models import AgentGenome, AgentState
from agent_economy.policy_lab import PolicyLab


class PolicyLabTests(unittest.TestCase):
    def test_policy_research_is_neutral_protocol_scenario_analysis(self):
        researcher = AgentState(
            agent_id="agent:r",
            name="Researcher",
            profession="researcher",
            genome=AgentGenome(curiosity=0.9, policy_curiosity=0.95),
            skills={"research": 0.95, "economics": 0.8},
            reputation=0.7,
        )
        lab = PolicyLab(seed=3)
        report = lab.run_experiment(researcher, tick=10, system_metrics={"default_rate": 0.1, "liquidity": 0.7})

        self.assertIn(report.domain, {"credit", "fees", "liquidity", "labor_market", "treasury"})
        self.assertIn("baseline", report.scenario_metrics)
        self.assertIn("alternative", report.scenario_metrics)
        self.assertGreater(report.confidence, 0)
        self.assertEqual(researcher.memory.research_reports, 1)
        self.assertNotIn("candidate", report.notes.lower())
        self.assertNotIn("vote", report.notes.lower())


class AgentEconomyIntegrationTests(unittest.TestCase):
    def test_seeded_run_creates_living_multi_market_economy(self):
        config = EconomyConfig(
            agent_count=12,
            steps=72,
            seed=11,
            initial_cash=Decimal("30"),
            external_job_every=2,
            credit_every=5,
            deposit_every=7,
            investment_every=9,
            company_revenue_every=11,
            policy_research_every=4,
            subcontract_every=3,
        )
        economy = AgentEconomy(config)
        report = economy.run()

        self.assertGreater(report.jobs_completed, 0)
        self.assertGreater(report.subcontracts_completed, 0)
        self.assertGreater(report.loans_originated, 0)
        self.assertGreater(report.deposits_opened, 0)
        self.assertGreater(report.investments_opened, 0)
        self.assertGreater(report.policy_reports, 0)
        self.assertGreater(report.external_income, Decimal("0"))
        self.assertGreater(report.founder_total_revenue, Decimal("0"))
        self.assertGreater(report.founder_external_attributed_revenue, Decimal("0"))
        self.assertEqual(report.conservation_gap, Decimal("0"))
        self.assertTrue(any(a.memory.hired_agents > 0 for a in economy.agents.values()))
        self.assertTrue(any(c.employee_ids for c in economy.capital.companies.values()))

    def test_internal_finance_does_not_masquerade_as_external_profit(self):
        config = EconomyConfig(
            agent_count=10,
            steps=35,
            seed=5,
            initial_cash=Decimal("25"),
            external_job_every=10_000,
            company_revenue_every=10_000,
            credit_every=3,
            deposit_every=4,
            investment_every=5,
            policy_research_every=6,
            subcontract_every=2,
        )
        economy = AgentEconomy(config)
        report = economy.run()

        self.assertEqual(report.external_income, Decimal("0"))
        self.assertEqual(report.conservation_gap, Decimal("0"))
        self.assertGreater(report.loans_originated + report.deposits_opened + report.investments_opened, 0)
        self.assertGreaterEqual(report.founder_internal_fee_revenue, Decimal("0"))
        self.assertEqual(report.founder_external_attributed_revenue, Decimal("0"))

    def test_report_contains_agent_wealth_and_bad_debt_metrics(self):
        economy = AgentEconomy(EconomyConfig(agent_count=8, steps=24, seed=13, initial_cash=Decimal("20")))
        report = economy.run()

        self.assertEqual(len(report.agent_net_worth), 8)
        self.assertGreaterEqual(report.bad_debt_loss, Decimal("0"))
        self.assertEqual(
            report.closing_system_cash,
            report.opening_capital + report.external_income - report.external_expense,
        )


if __name__ == "__main__":
    unittest.main()
