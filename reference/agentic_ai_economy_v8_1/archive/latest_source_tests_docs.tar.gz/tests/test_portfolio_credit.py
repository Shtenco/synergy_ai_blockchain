import unittest
from decimal import Decimal

from macro_economy.agents import MarketAgent
from macro_economy.portfolio_credit import PortfolioCreditFacility
from macro_economy.securities import SecuritiesMarket
from macro_economy.yield_curve import YEAR_SECONDS

D = Decimal


class PortfolioCreditFacilityTests(unittest.TestCase):
    def setUp(self):
        self.borrower = MarketAgent('borrower', D('5'), risk=0.7, trend=0.3, mean_reversion=0.3)
        self.borrower.holdings['WETH'] = D('0.05')
        self.borrower.rubx = D('10')
        self.borrower.rubz = D('5')
        self.prices = {'WETH': D('2000')}
        self.facility = PortfolioCreditFacility(reserve_usdc=D('100'), block_seconds=12)
        self.securities = SecuritiesMarket(block_seconds=12)

    def collateral(self, prices=None):
        return self.facility.collateral_value(
            self.borrower,
            prices=prices or self.prices,
            rubx_price=D('1'),
            rubz_price=D('1'),
            securities=self.securities,
        )

    def test_collateral_capacity_uses_haircuts(self):
        gross = D('100') + D('10') + D('5')
        capacity = self.collateral()
        self.assertGreater(capacity, D('0'))
        self.assertLess(capacity, gross)

    def test_loan_is_funded_from_existing_reserve_cash(self):
        before = self.facility.reserve_usdc + self.borrower.cash_usdc
        loan = self.facility.originate(
            self.borrower,
            principal=D('20'),
            annual_rate=D('0.10'),
            current_block=0,
            maturity_block=300,
            prices=self.prices,
            rubx_price=D('1'),
            rubz_price=D('1'),
            securities=self.securities,
        )
        self.assertEqual(self.facility.reserve_usdc, D('80'))
        self.assertEqual(self.borrower.cash_usdc, D('25'))
        self.assertEqual(self.facility.reserve_usdc + self.borrower.cash_usdc, before)
        self.assertEqual(loan.status, 'active')

    def test_interest_accrues_using_literal_block_seconds(self):
        loan = self.facility.originate(
            self.borrower,
            principal=D('20'), annual_rate=D('0.12'), current_block=0, maturity_block=300,
            prices=self.prices, rubx_price=D('1'), rubz_price=D('1'), securities=self.securities,
        )
        due = loan.amount_due(current_block=100)
        expected = D('20') * (D('1') + D('0.12') * D(100 * 12) / YEAR_SECONDS)
        self.assertEqual(due, expected)

    def test_price_crash_triggers_margin_call(self):
        self.borrower.holdings = {'WETH': D('1')}
        prices = {'WETH': D('100')}
        loan = self.facility.originate(
            self.borrower,
            principal=D('60'), annual_rate=D('0.08'), current_block=0, maturity_block=300,
            prices=prices, rubx_price=D('1'), rubz_price=D('1'), securities=self.securities,
        )
        self.assertFalse(self.facility.needs_margin_call(loan.loan_id, self.borrower, current_block=1, prices=prices, rubx_price=D('1'), rubz_price=D('1'), securities=self.securities))
        crashed = {'WETH': D('50')}
        self.assertTrue(self.facility.needs_margin_call(loan.loan_id, self.borrower, current_block=2, prices=crashed, rubx_price=D('1'), rubz_price=D('1'), securities=self.securities))

    def test_liquidation_moves_real_assets_and_records_uncovered_bad_debt(self):
        self.borrower.holdings = {'WETH': D('1')}
        prices = {'WETH': D('100')}
        loan = self.facility.originate(
            self.borrower,
            principal=D('60'), annual_rate=D('0.08'), current_block=0, maturity_block=300,
            prices=prices, rubx_price=D('1'), rubz_price=D('1'), securities=self.securities,
        )
        # Borrowed cash is lost externally before liquidation; the facility cannot invent repayment.
        self.borrower.cash_usdc = D('0')
        crashed = {'WETH': D('20')}
        total_weth_before = self.borrower.holdings['WETH'] + self.facility.seized_assets.get('WETH', D('0'))
        result = self.facility.liquidate(
            loan.loan_id, self.borrower, current_block=10, prices=crashed,
            rubx_price=D('1'), rubz_price=D('1'), securities=self.securities,
        )
        total_weth_after = self.borrower.holdings.get('WETH', D('0')) + self.facility.seized_assets.get('WETH', D('0'))
        self.assertEqual(total_weth_after, total_weth_before)
        self.assertEqual(result.status, 'defaulted')
        self.assertGreater(result.bad_debt_usdc, D('0'))
        self.assertGreater(self.facility.total_bad_debt_usdc, D('0'))


if __name__ == '__main__':
    unittest.main()
