import unittest
from decimal import Decimal

from agent_economy.models import AgentGenome, AgentState
from agent_economy.protocols import (
    MachinePaymentRequest,
    PaymentMandateEnvelope,
    ProtocolRegistry,
    TaskEnvelope,
)


class ProtocolCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.agent = AgentState(
            agent_id="agent:researcher",
            name="Researcher",
            profession="researcher",
            genome=AgentGenome(policy_curiosity=0.9),
            skills={"research": 0.92, "economics": 0.8, "coding": 0.3},
            reputation=0.77,
        )

    def test_identity_card_exports_capabilities_without_secrets(self):
        card = ProtocolRegistry.identity_card(self.agent, endpoint="https://agent.invalid/a2a")
        payload = card.to_dict()
        self.assertIn("research", payload["capabilities"])
        self.assertIn("economics", payload["capabilities"])
        self.assertEqual(payload["reputation"], 0.77)
        serialized = str(payload).lower()
        self.assertNotIn("private_key", serialized)
        self.assertNotIn("seed_phrase", serialized)

    def test_task_envelope_round_trips_with_decimal_budget(self):
        task = TaskEnvelope(
            task_id="task:1",
            sender_id="agent:a",
            recipient_id="agent:b",
            capability="research",
            description="Analyze protocol liquidity policy",
            budget=Decimal("12.50"),
            status="offered",
        )
        recovered = TaskEnvelope.from_dict(task.to_dict())
        self.assertEqual(recovered, task)
        self.assertEqual(task.to_dict()["budget"], "12.50")

    def test_payment_mandate_is_bounded_by_action_amount_total_and_expiry(self):
        mandate = PaymentMandateEnvelope(
            mandate_id="mandate:1",
            payer_id="founder:treasury",
            allowed_actions=("job_payment", "research_purchase"),
            max_transaction=Decimal("10"),
            max_total=Decimal("20"),
            expires_tick=50,
        )
        self.assertTrue(mandate.consume("job_payment", Decimal("8"), tick=10))
        self.assertFalse(mandate.consume("job_payment", Decimal("11"), tick=11))
        self.assertFalse(mandate.consume("loan", Decimal("1"), tick=11))
        self.assertTrue(mandate.consume("research_purchase", Decimal("10"), tick=12))
        self.assertFalse(mandate.consume("job_payment", Decimal("3"), tick=13))
        self.assertFalse(mandate.consume("job_payment", Decimal("1"), tick=51))
        self.assertEqual(mandate.spent, Decimal("18"))

    def test_machine_payment_request_is_intent_only(self):
        request = MachinePaymentRequest(
            request_id="pay:1",
            payee_id="agent:api",
            amount=Decimal("0.25"),
            asset="USDC",
            resource="/research/report/42",
        )
        payload = request.to_dict()
        self.assertEqual(payload["amount"], "0.25")
        self.assertEqual(payload["protocol_hint"], "x402-compatible-intent")
        self.assertNotIn("private_key", payload)
        self.assertNotIn("signature", payload)

    def test_package_root_exports_v2_risk_evolution_and_protocol_interfaces(self):
        import agent_economy as ae

        public_names = {
            "InsuranceMarket",
            "BankruptcyEngine",
            "EvolutionEngine",
            "AgentIdentityCard",
            "TaskEnvelope",
            "PaymentMandateEnvelope",
            "MachinePaymentRequest",
            "ProtocolRegistry",
        }
        self.assertTrue(public_names.issubset(set(ae.__all__)))
        for name in public_names:
            self.assertTrue(hasattr(ae, name), name)


if __name__ == "__main__":
    unittest.main()
