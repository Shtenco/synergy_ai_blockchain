from synergy_chain.chain import SynergyChain, SynergyChainConfig


def test_synergy_chain_seals_linked_blocks_with_12_second_clock():
    chain = SynergyChain(SynergyChainConfig(block_seconds=12))
    chain.record("mint", {"asset": "sWETH", "amount": "1"})
    b1 = chain.seal_block()
    chain.record("burn", {"asset": "sWETH", "amount": "0.2"})
    b2 = chain.seal_block()
    assert b1.number == 1 and b1.timestamp_seconds == 12
    assert b2.number == 2 and b2.timestamp_seconds == 24
    assert b2.parent_hash == b1.block_hash
    assert b1.block_hash != b2.block_hash
    assert chain.height == 2


def test_synergy_chain_registry_contains_13_mirrored_assets_and_no_redemption():
    chain = SynergyChain(SynergyChainConfig())
    assert len(chain.asset_registry) == 13
    assert {"sRUBX", "sRUBZ", "sUSDC", "sWETH", "scbBTC"}.issubset(chain.asset_registry)
    assert chain.config.external_redemption_enabled is False
