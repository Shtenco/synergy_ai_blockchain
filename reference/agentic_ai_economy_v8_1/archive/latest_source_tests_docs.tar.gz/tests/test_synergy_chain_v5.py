from decimal import Decimal as D

import pytest

from macro_economy.amm import CPMMPool
from synergy_chain.ledger import ShadowChainLedger
from synergy_chain.bridge import InventoryBridge
from synergy_chain.ai_mm import AdaptiveAIMarketMaker


def test_shadow_mint_burn_never_counts_as_hard_nav():
    ledger = ShadowChainLedger(("sUSDC", "sWETH", "sRUBX"))
    assert ledger.hard_nav_effect() == D("0")
    ledger.mint("sWETH", D("1000000"), reason="policy")
    ledger.mint("sUSDC", D("5000000"), reason="liquidity")
    ledger.burn("sWETH", D("250000"), reason="buyback")
    assert ledger.supply("sWETH") == D("750000")
    assert ledger.hard_nav_effect() == D("0")
    assert ledger.total_minted("sWETH") == D("1000000")
    assert ledger.total_burned("sWETH") == D("250000")


def test_inventory_bridge_synthetic_capacity_is_bounded_by_real_inventory():
    bridge = InventoryBridge(max_synthetic_leverage=D("4"))
    bridge.deposit_real("WETH", D("2"), D("2500"), source="protocol")
    bridge.deposit_real("USDC", D("1000"), D("1"), source="protocol")
    assert bridge.real_nav({"WETH": D("2500"), "USDC": D("1")}) == D("6000")
    assert bridge.synthetic_capacity_usdc({"WETH": D("2500"), "USDC": D("1")}) == D("24000")
    bridge.reserve_synthetic_value(D("12000"))
    with pytest.raises(ValueError):
        bridge.reserve_synthetic_value(D("13000"))
    assert not hasattr(bridge, "redeem_to_external")


def test_ai_mm_exact_target_mint_sell_and_buy_burn():
    ledger = ShadowChainLedger(("sUSDC", "sWETH"))
    ledger.mint("sWETH", D("1000"), reason="seed")
    ledger.mint("sUSDC", D("1000000"), reason="seed")
    pool = CPMMPool("sWETH", "sUSDC", D("1"), D("120"), fee_bps=30)
    mm = AdaptiveAIMarketMaker(base_spread_bps=D("20"), band_bps=D("2"))

    action = mm.stabilize_internal_pool(
        symbol="WETH",
        pool=pool,
        ledger=ledger,
        external_price=D("100"),
        volatility=D("0"),
        inventory_skew=D("0"),
    )
    target = D("100") * (D("1") + action.target_spread_bps / D("10000"))
    assert action.kind == "mint_sell"
    assert abs(pool.price_a_in_b / target - D("1")) < D("0.00002")
    assert action.synthetic_minted > 0

    # Push the internal market far below target, then require buyback+burn.
    pool.swap_a_for_b(D("0.35"))
    action2 = mm.stabilize_internal_pool(
        symbol="WETH",
        pool=pool,
        ledger=ledger,
        external_price=D("100"),
        volatility=D("0"),
        inventory_skew=D("0"),
    )
    target2 = D("100") * (D("1") + action2.target_spread_bps / D("10000"))
    assert action2.kind == "buy_burn"
    assert abs(pool.price_a_in_b / target2 - D("1")) < D("0.00002")
    assert action2.synthetic_burned > 0


def test_delta_policy_sells_strength_and_restores_on_weakness():
    mm = AdaptiveAIMarketMaker(base_spread_bps=D("20"), band_bps=D("2"))
    neutral = mm.target_external_delta(momentum=D("0"), drawdown=D("0"), volatility=D("0.01"))
    strong = mm.target_external_delta(momentum=D("0.03"), drawdown=D("0"), volatility=D("0.01"))
    weak = mm.target_external_delta(momentum=D("-0.03"), drawdown=D("0.04"), volatility=D("0.01"))
    assert D("0.15") <= strong < neutral < weak <= D("0.90")


def test_ai_mm_countercyclical_spread_sells_strength_and_buys_weakness():
    up_ledger = ShadowChainLedger(("sUSDC", "sWETH"))
    up_ledger.mint("sWETH", D("1000"), reason="seed")
    up_ledger.mint("sUSDC", D("1000000"), reason="seed")
    up_pool = CPMMPool("sWETH", "sUSDC", D("1"), D("100.2"), fee_bps=30)
    mm = AdaptiveAIMarketMaker(base_spread_bps=D("20"), band_bps=D("2"))
    up = mm.stabilize_internal_pool(symbol="WETH", pool=up_pool, ledger=up_ledger,
        external_price=D("101"), volatility=D("0"), inventory_skew=D("0"), momentum=D("0.01"))
    assert up.kind == "mint_sell"
    assert up.target_spread_bps < 0

    down_ledger = ShadowChainLedger(("sUSDC", "sWETH"))
    down_ledger.mint("sWETH", D("1000"), reason="seed")
    down_ledger.mint("sUSDC", D("1000000"), reason="seed")
    down_pool = CPMMPool("sWETH", "sUSDC", D("1"), D("99.8"), fee_bps=30)
    mm2 = AdaptiveAIMarketMaker(base_spread_bps=D("20"), band_bps=D("2"))
    down = mm2.stabilize_internal_pool(symbol="WETH", pool=down_pool, ledger=down_ledger,
        external_price=D("99"), volatility=D("0"), inventory_skew=D("0"), momentum=D("-0.01"))
    assert down.kind == "buy_burn"
    assert down.target_spread_bps > 0
