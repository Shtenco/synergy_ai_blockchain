#!/usr/bin/env python3
"""BASE MAINNET FORK TEST - Anti-Ponzi P2P Economy
Ответ на вопрос: зарабатывают ли все участники в сумме или все в убытке?

Методология:
 1. Живые данные Base mainnet через public JSON-RPC (chainId, blockNumber, gasPrice, baseFee).
 2. Живая цена ETH (несколько публичных API с fallback).
 3. Реальный Aave V3 Base WETH supply APY = ~1.5-1.6% (Aavescan, верифицировано веб-поиском),
    а НЕ 15% как в UI-симуляции (ошибка в 10 раз).
 4. Точная реплика движка src/simulation/engine.ts (defaultConfig) - для доказательства,
    что "плюс" в UI является артефактом накачанных P2P-параметров.
 5. Честная Base-fork модель: блок 2с, реальный газ, реальный yield, реалистичный P2P-объём,
    учёт seedNAV как затрат, учёт газа как безвозвратной утечки.
 6. Строгий учёт закона сохранения денег.
"""
import urllib.request, json, time

RPCS = ["https://base.publicnode.com", "https://1rpc.io/base", "https://base.meowrpc.com"]

def rpc(method, params=[]):
    payload = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
    last = None
    for url in RPCS:
        try:
            req = urllib.request.Request(url, data=payload,
                headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
            return json.loads(urllib.request.urlopen(req, timeout=15).read().decode())["result"], url
        except Exception as e:
            last = e
    raise RuntimeError(f"all RPCs failed: {last}")

def get_eth_price():
    # пробуем несколько бесплатных источников
    urls = [
        "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd",
        "https://api.kraken.com/0/public/Ticker?pair=ETHUSD",
        "https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT",
    ]
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            raw = urllib.request.urlopen(req, timeout=15).read().decode()
            d = json.loads(raw)
            if "ethereum" in d: return float(d["ethereum"]["usd"]), u
            if "result" in d:
                k = list(d["result"].keys())[0]
                return float(d["result"][k]["c"][0]), u
            if "price" in d: return float(d["price"]), u
        except Exception as e:
            print(f"  price source {u} failed: {e}")
    return None, None

print("=" * 72)
print("BASE MAINNET FORK TEST - Anti-Ponzi P2P Economy")
print("=" * 72)

chain_id, rpc_used = rpc("eth_chainId")
block_hex, _ = rpc("eth_blockNumber")
gas_hex, _ = rpc("eth_gasPrice")
blk, _ = rpc("eth_getBlockByNumber", ["latest", False])

chain_id = int(chain_id, 16); block_n = int(block_hex, 16); gas_wei = int(gas_hex, 16)
base_fee_wei = int(blk["baseFeePerGas"], 16)
gas_gwei = gas_wei / 1e9; base_gwei = base_fee_wei / 1e9
print(f"RPC: {rpc_used}")
print(f"chainId={chain_id} ({'BASE MAINNET OK' if chain_id==8453 else '!!! НЕ BASE'})  block={block_n}")
print(f"gasPrice={gas_gwei:.4f} gwei  baseFee={base_gwei:.4f} gwei  blockTime~2s (Base sequencer)")

eth_price, src = get_eth_price()
if eth_price is None:
    eth_price, src = 3800.0, "FALLBACK (CoinGecko/Kraken/Binance недоступны)"
print(f"ETH price=${eth_price:,.2f}  (источник: {src})")

# Реальные параметры Base (верифицированы веб-поиском, сентябрь 2026)
AAVE_REAL_APY = 0.0156   # Aavescan: WETH Base V3 supply APR ~1.56%
AAVE_UI_APY   = 0.15     # что заложено в UI-симуляции (завышено в ~10 раз)
print(f"Aave V3 Base WETH supply APY (реальный): {AAVE_REAL_APY*100:.2f}%  |  в UI: {AAVE_UI_APY*100:.0f}% (завышен x{AAVE_UI_APY/AAVE_REAL_APY:.1f})")

# Газ: enter() делает SSTORE/SLOAD + mint + внешний вызов Aave supply ~ 150-200k gas.
# Берём консервативно 170k gas L2 execution. L1-data fee на Base при 0.005 gwei мизерный,
# но честно добавляем x1.3 запас на L1-fee.
GAS_ENTER = 170_000
l2_cost_eth = GAS_ENTER * gas_wei / 1e18
gas_cost_eth = l2_cost_eth * 1.3
gas_cost_usd = gas_cost_eth * eth_price
print(f"Оценка газа enter(): {GAS_ENTER} gas -> {gas_cost_eth*1e6:.1f} uETH (${gas_cost_usd:.4f}) за вызов")

ENTRY_ETH = 0.001
entry_usd = ENTRY_ETH * eth_price
print(f"Вход 0.001 ETH = ${entry_usd:.2f}")

results = {}

# ------------------------------------------------------------------
# ТЕСТ A: точная реплика движка UI (src/simulation/engine.ts, defaultConfig)
# ------------------------------------------------------------------
def run_engine_replica(cfg):
    P = cfg["participants"]; total = P * cfg["stepsPerParticipant"]
    SPY = 365.25*24*3600
    nav = cfg["seedNAV"]; supply = 0.0
    pool = 0.0; dist = 0.0; wd = 0.0; re = 0.0; p2p = 0.0; aave = 0.0
    bal = [0.0]*P; cred = [0.0]*P; inv = [0.0]*P; wdn = [0.0]*P; rei = [0.0]*P
    ci = 0
    for step in range(1, total+1):
        p = ci; ci = (ci+1) % P
        nav += cfg["entryCost"]*cfg["navPortion"]; pool += cfg["entryCost"]*cfg["dividendPortion"]; inv[p] += cfg["entryCost"]
        net = cfg["mintPerEntry"]*(1-cfg["burnRate"]); supply += net; bal[p] += net
        y = nav*cfg["aaveAPY"]*(cfg["stepDurationSec"]/SPY); nav += y; aave += y
        if step % cfg["p2pCreditEvery"] == 0:
            v = cfg["p2pCreditAmount"]*cfg["p2pCreditAPY"]*(cfg["p2pCreditEvery"]*cfg["stepDurationSec"]/SPY)
            nav += v; p2p += v
        if step % cfg["p2pDepositEvery"] == 0:
            v = cfg["p2pDepositAmount"]*cfg["p2pDepositAPY"]*(cfg["p2pDepositEvery"]*cfg["stepDurationSec"]/SPY)
            nav += v; p2p += v
        if step % cfg["p2pMarketEvery"] == 0:
            v = cfg["p2pMarketAmount"]*cfg["p2pMarketCommission"]; nav += v; p2p += v
        if step % 10 == 0 and pool > 0 and supply > 0:
            dist += pool
            for i in range(P): cred[i] += pool*bal[i]/supply
            pool = 0.0
        if step % P == 0:
            c = int(step/P - 1) % P
            if cred[c] > 0:
                r = cred[c]*cfg["reinvestRate"]; w = cred[c]-r
                if r > 0:
                    nav += r
                    t = (r/cfg["entryCost"])*cfg["mintPerEntry"]; b = t*cfg["burnRate"]
                    supply += t-b; bal[c] += t-b; re += r; rei[c] += r
                if w > 0: nav -= w; wdn[c] += w; wd += w
                cred[c] = 0.0
    px = nav/supply if supply else 0
    parts = []
    for i in range(P):
        pf = bal[i]*px; tv = pf+wdn[i]; pnl = tv-inv[i]
        parts.append(dict(inv=inv[i], pf=pf, w=wdn[i], tv=tv, pnl=pnl,
                          roi=(pnl/inv[i]*100 if inv[i] else 0)))
    TI = sum(inv); TV = sum(p["tv"] for p in parts)
    return dict(nav=nav, supply=supply, px=px, TI=TI, TV=TV, pnl=TV-TI,
                roi=(TV-TI)/TI*100 if TI else 0, wd=wd, re=re, p2p=p2p, aave=aave, dist=dist, parts=parts)

ui_cfg = dict(participants=10, stepsPerParticipant=200, entryCost=1.0, navPortion=0.8,
    dividendPortion=0.2, mintPerEntry=1.0, burnRate=0.01, reinvestRate=0.3, aaveAPY=0.15,
    stepDurationSec=12, p2pCreditEvery=100, p2pCreditAmount=20, p2pCreditAPY=0.2,
    p2pDepositEvery=150, p2pDepositAmount=15, p2pDepositAPY=0.15,
    p2pMarketEvery=75, p2pMarketAmount=1000, p2pMarketCommission=0.01, seedNAV=100)
A = run_engine_replica(ui_cfg)
results["A"] = A
print("\n" + "-"*72)
print("ТЕСТ A - реплика UI-движка (завышенные параметры: Aave 15%, P2P $1000/сделка)")
print(f"  Вложено=${A['TI']:.2f}  NAV=${A['nav']:.2f}  Выведено=${A['wd']:.2f}")
print(f"  P2P-доход=${A['p2p']:.2f} (из них маркет ~${A['p2p']*0.999:.2f})  Aave=${A['aave']:.6f}")
print(f"  Системный PnL=${A['pnl']:+.2f}  ROI={A['roi']:+.2f}%")
print(f"  Участников в плюсе: {sum(1 for p in A['parts'] if p['pnl']>0)}/10")
print("  -> 'Плюс' держится ТОЛЬКО на P2P-комиссиях $10 каждые 75 шагов ($260 за цикл) + seed $100.")

# ------------------------------------------------------------------
# ТЕСТ B: ЧЕСТНЫЙ BASE FORK (реальные параметры, учёт газа и seed как затрат)
# ------------------------------------------------------------------
# entry в USD по живому курсу; P2P-объём реалистичный: 10 участников со входом ~$4
# не могут генерировать сделки по $1000. Реалистично: редкие сделки ~$20 с комиссией 1%.
B_cfg = dict(ui_cfg)
B_cfg.update(entryCost=entry_usd,           # $ за 0.001 ETH по живому курсу
             aaveAPY=AAVE_REAL_APY,         # 1.56% вместо 15%
             stepDurationSec=2,             # Base блок 2с вместо 12с
             p2pMarketAmount=20.0,          # реалистичная сделка $20
             p2pMarketCommission=0.01,
             p2pMarketEvery=75,
             p2pCreditAmount=20, p2pCreditAPY=0.03,   # реальные кредитные ставки ниже
             p2pDepositAmount=15, p2pDepositAPY=0.03,
             seedNAV=100)
B = run_engine_replica(B_cfg)
# Честная бухгалтерия: газ - безвозвратная утечка майнерам/секвенсору;
# seed $100 - тоже чьи-то затраты (деплойер), а не "бесплатные деньги".
GAS_TOTAL = gas_cost_usd * (B_cfg["participants"]*B_cfg["stepsPerParticipant"])
honest_pnl = B["pnl"] - GAS_TOTAL - 100.0   # вычитаем seed как затрату основателя
honest_roi = honest_pnl / (B["TI"] + GAS_TOTAL + 100.0) * 100
results["B"] = dict(B, gas=GAS_TOTAL, honest_pnl=honest_pnl, honest_roi=honest_roi)
nprof = sum(1 for p in B["parts"] if (p["pnl"] - GAS_TOTAL/10) > 0)
print("\n" + "-"*72)
print("ТЕСТ B - ЧЕСТНЫЙ BASE FORK (живой курс, Aave 1.56%, блок 2с, P2P $20, газ вычтен)")
print(f"  Вложено участниками=${B['TI']:.2f}  Газ всего=${GAS_TOTAL:.2f}  Seed(затрата)=$100.00")
print(f"  NAV=${B['nav']:.2f}  Выведено дивидендов=${B['wd']:.2f}")
print(f"  Внешний доход: Aave=${B['aave']:.4f}  P2P-комиссии=${B['p2p']:.2f}")
print(f"  'Бумажный' PnL движка (без газа/seed)=${B['pnl']:+.2f}")
print(f"  ЧЕСТНЫЙ системный PnL (минус газ, минус seed)=${honest_pnl:+.2f}  ROI={honest_roi:+.2f}%")
print(f"  Участников в плюсе после вычета газа: {nprof}/10")

# ------------------------------------------------------------------
# ТЕСТ C: BASE FORK БЕЗ P2P-ВНЕШНИХ ВЛИВАНИЙ (чистый zero-sum + yield - газ)
# P2P-кредитные проценты - внутренний трансфер (заёмщик->кредитор), в NAV идёт
# лишь 0.5% fee - тоже внутреннее перераспределение, а не новые деньги.
# Единственные ВНЕШНИЕ деньги: Aave-yield. Утечки: газ.
# ------------------------------------------------------------------
C_cfg = dict(B_cfg); C_cfg.update(p2pMarketAmount=0.0, p2pCreditAmount=0.0, p2pDepositAmount=0.0)
C = run_engine_replica(C_cfg)
honest_C = C["pnl"] - GAS_TOTAL - 100.0
roi_C = honest_C / (C["TI"] + GAS_TOTAL + 100.0) * 100
results["C"] = dict(C, honest_pnl=honest_C)
print("\n" + "-"*72)
print("ТЕСТ C - BASE FORK, P2P-торговли нет (только входы + реальный Aave-yield - газ)")
print(f"  Aave-yield за весь цикл (6.7 мин при блоке 2с... точнее {2000*2/3600:.2f} ч)=${C['aave']:.6f}")
print(f"  Газ=${GAS_TOTAL:.2f}  Seed=$100.00")
print(f"  ЧЕСТНЫЙ системный PnL=${honest_C:+.2f}  ROI={roi_C:+.2f}%")
nprofC = sum(1 for p in C["parts"] if (p["pnl"] - GAS_TOTAL/10) > 0)
print(f"  Участников в плюсе после газа: {nprofC}/10")

# ------------------------------------------------------------------
# ТЕСТ D: стресс - тот же честный Base, но участники платят ещё и claim/distribute газ
# (каждый claim ~80k gas). 200 claim'ов за цикл.
# ------------------------------------------------------------------
CLAIM_GAS = 80_000
claim_eth = CLAIM_GAS * gas_wei / 1e18 * 1.3
claim_usd = claim_eth * eth_price
NCLAIMS = 200
extra = claim_usd * NCLAIMS
honest_D = honest_C - extra
print("\n" + "-"*72)
print("ТЕСТ D - как C + газ на claimDividends/distribute (200 вызовов)")
print(f"  Доп. газ=${extra:.2f}  Итоговый честный PnL=${honest_D:+.2f}")

print("\n" + "="*72)
print("ВЕРДИКТ")
print("="*72)
if honest_C < 0 and honest_pnl < 0:
    print("SISTEMA - OTRITSATELNAYA SUMMA (vse uchastniki v summe V UBYTKE).")
    print(f"  - Chestny Base-fork s realistichnym P2P: {honest_pnl:+.2f}$ ({honest_roi:+.2f}%).")
    print(f"  - Bez vneshnih P2P-vlivaniy: {honest_C:+.2f}$ ({roi_C:+.2f}%).")
    print("  Prichiny: (1) Aave-yield realen ~1.5%, za 1.1 chasa dayot tsenty;")
    print("           (2) UI 'plyus' narisovan P2P-sdelkami po $1000 pri vhodah $1 - nevozmozhno;")
    print("           (3) gaz Base hot i deshyovyy, no byot po mikrovhodam $1-$4;")
    print("           (4) 20% kazhdogo vhoda uhodit v divpul, 70% iz nego vyvoditsya -")
    print("               eto pereraspredelenie, a ne dohod; seed $100 - subsidiya, a ne pribyl.")
else:
    print("SISTEMA - POLOZHITELNAYA SUMMA (uchastniki v summe v plyuse).")

with open(r"C:\Users\Shtenco\AppData\Local\Temp\opencode\base_fork_result.json", "w") as f:
    json.dump(dict(
        chain_id=chain_id, block=block_n, gas_gwei=gas_gwei, base_fee_gwei=base_gwei,
        eth_price=eth_price, eth_src=src, aave_real=AAVE_REAL_APY,
        gas_per_enter_usd=gas_cost_usd, entry_usd=entry_usd,
        testA=dict(pnl=round(A["pnl"],2), roi=round(A["roi"],2), p2p=round(A["p2p"],2), aave=A["aave"]),
        testB=dict(pnl=round(honest_pnl,2), roi=round(honest_roi,2), gas=round(GAS_TOTAL,2)),
        testC=dict(pnl=round(honest_C,2), roi=round(roi_C,2)),
        testD=dict(pnl=round(honest_D,2)),
        verdict="NEGATIVE_SUM" if (honest_C<0 and honest_pnl<0) else "POSITIVE_SUM"
    ), f, indent=2)
print("\nJSON сохранён: base_fork_result.json")
