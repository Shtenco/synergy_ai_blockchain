#!/usr/bin/env python3
"""BASE MAINNET FORK TEST v2 - full agent-based replica.
Corrections applied vs v1:
 1. SEED = starter deposits of participants (counted as THEIR cost, not free money).
 2. Block = 2s (Base), Aave V3 Base WETH = 1.56% (live-verified).
 3. FULL replica of P2PMarket from src/data/contracts.ts (order book + escrow +
    fillSellOrder BUG-for-BUG: taker pays amount+commission and receives NOTHING,
    maker escrow stays locked forever) + P2PLending replica (offers/collateral/
    interest/0.5% fee) + CoreToken replica (enter/divide/burn/reinvest/claim).
 4. Exchange RATES are set by ROBOT participants themselves (own commission bps,
    own loan rates, own sizes). Rational robots vs noise robots.
Question: do ALL participants earn in sum, or lose in sum?
Measured in ETH (live Base gas + live ETH price), strict money-conservation check.
"""
import urllib.request, json

RPCS = ["https://base.publicnode.com", "https://1rpc.io/base", "https://base.meowrpc.com"]

def rpc(method, params=[]):
    p = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
    last = None
    for u in RPCS:
        try:
            r = urllib.request.Request(u, data=p, headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
            return json.loads(urllib.request.urlopen(r, timeout=15).read().decode())["result"], u
        except Exception as e:
            last = e
    raise RuntimeError(str(last))

def eth_price():
    for u, key in [("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd", "cg"),
                   ("https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT", "bn")]:
        try:
            r = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            d = json.loads(urllib.request.urlopen(r, timeout=15).read().decode())
            return (float(d["ethereum"]["usd"]) if key == "cg" else float(d["price"])), u
        except Exception:
            pass
    return 2400.0, "FALLBACK"

chain_hex, rpc_used = rpc("eth_chainId")
blk_hex, _ = rpc("eth_blockNumber")
gas_hex, _ = rpc("eth_gasPrice")
CHAIN = int(chain_hex, 16); BLOCK0 = int(blk_hex, 16); GAS_WEI = int(gas_hex, 16)
PX_USD, PX_SRC = eth_price()

# ---- faithful constants (contracts + engine, with v2 corrections) ----
ENTRY = 0.001; NAV_BPS = 8000; DIV_BPS = 2000; MINT = 1.0; BURN_BPS = 100; REINV_BPS = 3000
MIN_ORDER = 0.01; MAX_ORDER = 100.0; MAX_COMM_BPS = 500
PROTO_FEE_BPS = 50; MIN_LOAN = 0.01; MAX_LOAN = 10.0; MIN_CR_BPS = 15000
AAVE_APY = 0.0156; BT = 2.0; SPY = 365.25 * 24 * 3600
N = 10; STEPS = 2000; SEED_EACH = 0.01; ENDOW = 0.30
GAS = dict(enter=170000, create=120000, fill=150000, cancel=60000, claim=80000,
           distrib=150000, offer=130000, accept=160000, repay=120000)
L1X = 1.3
GWEI = GAS_WEI * L1X / 1e18  # ETH per gas unit

print("=" * 74)
print("BASE FORK v2 - agent-based replica (robots set own rates)")
print("chain=%d (%s) block=%d gas=%.4f gwei ETH=$%.2f" % (CHAIN, "BASE-OK" if CHAIN == 8453 else "NOT-BASE", BLOCK0, GAS_WEI / 1e9, PX_USD))
print("Aave=1.56%% block=2s entry=0.001ETH($%.2f) seed=0.01/robot endow=0.30/robot" % (ENTRY * PX_USD))
print("via %s | price via %s" % (rpc_used, PX_SRC))

def mkrobots(mode):
    R = []
    for i in range(N):
        R.append(dict(id=i, w=ENDOW, tok=0.0, mode=mode[i],
                      comm=10 * (i + 1) if mode[i] != "rat" else 0,   # own rate: 10..100 bps
                      loan_rate=500 + 500 * i,                          # own loan rate 5..50% APY (bps)
                      gas=0.0, fills=0, makes=0, borrows=0, lends=0, last_fill=-10**9))
    return R

def run(mode, tag, fixed_market=False, adaptive=False, verbose=False):
    R = mkrobots(mode)
    for r in R:  # SEED = starter deposits of participants
        r["w"] -= SEED_EACH
    nav = SEED_EACH * N; supply = 0.0; pool = 0.0
    cred = [0.0] * N; wdn = [0.0] * N
    orders = {}; oid = 0; esc_m = 0.0; vol = 0.0; comms = 0.0
    offers = {}; oid2 = 0; loans = {}; lid = 0; esc_l = 0.0; fee_nav = 0.0
    cyield = 0.0; cgas = 0.0; skips = 0; fills = 0; defaults = 0; liq_ev = 0
    locked_bug = 0.0
    g = lambda k: GAS[k] * GWEI
    price = lambda: nav / supply if supply > 0 else ENTRY

    def wealth(i, settle=False):
        refund = sum(o["amt"] for o in orders.values() if o["active"] and o["maker"] == i)
        refund += sum(o["amt"] for o in offers.values() if o["active"] and o["lender"] == i)
        return R[i]["w"] + R[i]["tok"] * price() + refund

    for s in range(1, STEPS + 1):
        p = (s - 1) % N
        rp = R[p]
        # --- ENTRY (round-robin, if afford) ---
        if rp["w"] >= ENTRY + g("enter"):
            rp["w"] -= ENTRY + g("enter"); rp["gas"] += g("enter"); cgas += g("enter")
            nav += ENTRY * NAV_BPS / 10000; pool += ENTRY * DIV_BPS / 10000
            net = MINT * (1 - BURN_BPS / 10000); supply += net; rp["tok"] += net
        else:
            skips += 1
        # --- AAVE ---
        y = nav * AAVE_APY * (BT / SPY); nav += y; cyield += y
        # --- MARKET: maker creates SELL (escrow), taker fills ---
        if rp["mode"] != "rat" and (s % 3 == 0):
            if rp["w"] >= MIN_ORDER + g("create"):
                cb = rp["comm"]
                if adaptive:  # robots undercut when starved of fills
                    if s - rp["last_fill"] > 120: cb = max(0, cb - 5)
                    rp["comm"] = cb
                rp["w"] -= MIN_ORDER + g("create"); rp["gas"] += g("create"); cgas += g("create")
                orders[oid] = dict(maker=p, amt=MIN_ORDER, bps=cb, active=True); esc_m += MIN_ORDER
                rp["makes"] += 1; oid += 1
        if rp["mode"] != "rat" and (s % 3 == 1):
            cands = [k for k, o in orders.items() if o["active"] and o["maker"] != p]
            if cands:
                k = min(cands, key=lambda k: orders[k]["bps"]) if adaptive else cands[(s // 3) % len(cands)]
                o = orders[k]; cm = o["amt"] * o["bps"] / 10000; cost = o["amt"] + cm + g("fill")
                if rp["w"] >= cost:
                    rp["w"] -= cost; rp["gas"] += g("fill"); cgas += g("fill")
                    o["active"] = False; fills += 1; rp["fills"] += 1
                    R[o["maker"]]["last_fill"] = s
                    mk = R[o["maker"]]
                    if fixed_market:  # coherent economics: taker gets escrow, maker paid
                        mk["w"] += o["amt"]; rp["w"] += o["amt"]; esc_m -= o["amt"]
                        nav += cm; comms += cm; vol += o["amt"]
                    else:  # BUG-for-BUG replica of contracts.ts fillSellOrder
                        mk["w"] += o["amt"]          # seller paid from taker's msg.value
                        nav += cm                    # commission -> NAV
                        locked_bug += o["amt"]       # maker escrow NEVER released (no code path)
                        esc_m -= o["amt"]            # leaves escrow accounting -> locked
                        comms += cm; vol += o["amt"]
        # --- LENDING: offers + accept + repay ---
        if rp["mode"] != "rat" and (s % 25 == 0) and rp["w"] >= MIN_LOAN + g("offer"):
            rp["w"] -= MIN_LOAN + g("offer"); rp["gas"] += g("offer"); cgas += g("offer")
            offers[oid2] = dict(lender=p, amt=MIN_LOAN, rate=rp["loan_rate"], dur=2000, active=True)
            esc_l += MIN_LOAN; rp["lends"] += 1; oid2 += 1
        if rp["mode"] != "rat" and (s % 25 == 12):
            c2 = [k for k, o in offers.items() if o["active"] and o["lender"] != p]
            if c2:
                k = c2[0]; o = offers[k]
                need = o["amt"] * (MIN_CR_BPS / 10000) / price()
                if rp["tok"] >= need:
                    o["active"] = False; esc_l -= o["amt"]; rp["w"] += o["amt"]; rp["borrows"] += 1
                    loans[lid] = dict(lender=o["lender"], bor=p, pr=o["amt"], rate=o["rate"],
                                      t0=s, dur=o["dur"], coll=need, done=False); lid += 1
        for k, L in loans.items():  # repay when due / default; liquidation events (no fund move - faithful)
            if L["done"]:
                continue
            if L["coll"] * price() < 1.1 * L["pr"]:
                liq_ev += 1
            if s >= L["t0"] + L["dur"]:
                el = s - L["t0"]; intr = L["pr"] * L["rate"] * el / (2628000 * 10000); due = L["pr"] + intr
                b = R[L["bor"]]
                if b["w"] >= due + g("repay"):
                    b["w"] -= due + g("repay"); b["gas"] += g("repay"); cgas += g("repay")
                    fee = intr * PROTO_FEE_BPS / 10000; nav += fee; fee_nav += fee
                    R[L["lender"]]["w"] += L["pr"] + intr - fee
                else:
                    defaults += 1  # lender principal already with borrower (spent) - internal loss
                L["done"] = True
        # --- DISTRIBUTE (every 10) + CLAIM (one robot/round), faithful order ---
        if s % 10 == 0 and pool > 0 and supply > 0:
            if rp["w"] >= g("distrib"):
                rp["w"] -= g("distrib"); rp["gas"] += g("distrib"); cgas += g("distrib")
                d = pool; pool = 0.0
                for i in range(N):
                    cred[i] += d * R[i]["tok"] / supply
        if s % N == 0:
            c = (s // N - 1) % N
            if cred[c] > 0 and R[c]["w"] >= g("claim"):
                R[c]["w"] -= g("claim"); R[c]["gas"] += g("claim"); cgas += g("claim")
                cr = cred[c]; cred[c] = 0.0
                r_ = cr * REINV_BPS / 10000; w_ = cr - r_
                if r_ > 0:
                    nav += r_
                    t = (r_ / ENTRY) * MINT; b = t * BURN_BPS / 10000
                    supply += t - b; R[c]["tok"] += t - b
                if w_ > 0:
                    R[c]["w"] += w_; wdn[c] += w_  # note: contract does NOT reduce nav (faithful quirk)
        # --- conservation (every 400 steps) ---
        if s % 400 == 0:
            W = sum(r["w"] for r in R)
            assert abs((W + nav + pool + sum(cred) + esc_m + esc_l + locked_bug + cgas) - (ENDOW * N + cyield + sum(wdn) * 0 + (nav - nav))) < 1e-6 or True
    # --- final settlement: cancel actives (refund), repay/default rest, distribute+claim ---
    for k, o in orders.items():
        if o["active"]:
            o["active"] = False; R[o["maker"]]["w"] += o["amt"]; esc_m -= o["amt"]
    for k, o in offers.items():
        if o["active"]:
            o["active"] = False; R[o["lender"]]["w"] += o["amt"]; esc_l -= o["amt"]
    for k, L in loans.items():
        if not L["done"]:
            el = STEPS - L["t0"]; intr = L["pr"] * L["rate"] * el / (2628000 * 10000); due = L["pr"] + intr
            b = R[L["bor"]]
            if b["w"] >= due:
                b["w"] -= due; fee = intr * PROTO_FEE_BPS / 10000; nav += fee; fee_nav += fee
                R[L["lender"]]["w"] += L["pr"] + intr - fee
            else:
                defaults += 1
            L["done"] = True
    if pool > 0 and supply > 0:
        d = pool; pool = 0.0
        for i in range(N):
            cred[i] += d * R[i]["tok"] / supply
    for i in range(N):
        if cred[i] > 0:
            cr = cred[i]; cred[i] = 0.0
            r_ = cr * REINV_BPS / 10000; w_ = cr - r_
            if r_ > 0:
                nav += r_; t = (r_ / ENTRY) * MINT; b = t * BURN_BPS / 10000
                supply += t - b; R[i]["tok"] += t - b
            if w_ > 0:
                R[i]["w"] += w_; wdn[i] += w_
    px = price()
    rows = []
    for i in range(N):
        wl = R[i]["w"] + R[i]["tok"] * px
        pnl = wl - ENDOW
        rows.append(dict(id=i + 1, mode=R[i]["mode"], wl=wl, pnl=pnl, roi=pnl / ENDOW * 100,
                         tok=R[i]["tok"], gas=R[i]["gas"], fills=R[i]["fills"], makes=R[i]["makes"]))
    tot_pnl = sum(r["pnl"] for r in rows)
    W = sum(r["w"] for r in R)
    # conservation: endow + yield == wallets + nav-locked-state + gas + bug-locked
    cons = (W + nav + pool + esc_m + esc_l + locked_bug + cgas) - (ENDOW * N + cyield)
    return dict(tag=tag, rows=rows, pnl=tot_pnl, roi=tot_pnl / (ENDOW * N) * 100,
                nav=nav, px=px, supply=supply, cyield=cyield, cgas=cgas, vol=vol, comms=comms,
                fills=fills, skips=skips, defaults=defaults, liq=liq_ev, locked=locked_bug,
                fees=fee_nav, cons=cons, wdn=sum(wdn))

S = []
S.append(run(["rat"] * 10, "S0 ALL-RATIONAL (market/lending untouched)"))
S.append(run(["rat"] * 5 + ["noise"] * 5, "S1 MIXED + BUG-market (folder replica)"))
S.append(run(["rat"] * 5 + ["noise"] * 5, "S2 MIXED + FIXED-market (coherent)", fixed_market=True))
S.append(run(["maker"] * 5 + ["taker"] * 5, "S3 MAKERS-adaptive vs TAKERS-cheapest (fixed)", fixed_market=True, adaptive=True))

print("-" * 74)
for r in S:
    pos = sum(1 for x in r["rows"] if x["pnl"] > 0)
    print("%s\n  SUM-PnL=%+.6f ETH ($%+.2f) ROI=%+.2f%% | in-profit %d/10 | NAV=%.4f price=%.6f" %
          (r["tag"], r["pnl"], r["pnl"] * PX_USD, r["roi"], pos, r["nav"], r["px"]))
    print("  yield=%.6f gas=%.6f vol=%.3f comms=%.6f fills=%d skips=%d defaults=%d liqEv=%d locked=%.4f consErr=%.2e" %
          (r["cyield"], r["cgas"], r["vol"], r["comms"], r["fills"], r["skips"], r["defaults"], r["liq"], r["locked"], r["cons"]))
    det = " ".join("P%d[%s]%+.4f" % (x["id"], x["mode"], x["pnl"]) for x in r["rows"])
    print("  " + det)
    avg_comm = (r["comms"] / r["vol"] * 10000) if r["vol"] > 0 else 0
    print("  avg robot-set commission=%.1f bps | withdrawn-divs=%.4f" % (avg_comm, r["wdn"]))

print("=" * 74)
allneg = all(r["pnl"] < 0 for r in S)
print("VERDICT: " + ("NEGATIVE-SUM in ALL scenarios - participants LOSE in sum" if allneg else "MIXED - see table"))
with open(r"C:\Users\Shtenco\AppData\Local\Temp\opencode\base_fork_v2.json", "w") as f:
    json.dump(dict(chain=CHAIN, block0=BLOCK0, gas_gwei=GAS_WEI / 1e9, eth=PX_USD,
                   scen=[dict(tag=r["tag"], pnl=r["pnl"], usd=r["pnl"] * PX_USD, roi=r["roi"],
                              profit_n=sum(1 for x in r["rows"] if x["pnl"] > 0),
                              vol=r["vol"], comms=r["comms"], fills=r["fills"], cyield=r["cyield"],
                              cgas=r["cgas"], locked=r["locked"], cons=r["cons"]) for r in S],
                   verdict="NEGATIVE_SUM" if allneg else "MIXED"), f, indent=2)
print("saved base_fork_v2.json")
