#!/usr/bin/env python3
"""Fetch REAL Base blocks (6 windows x 2400 = 80min each) + fresh Kraken candles."""
import urllib.request, json, os, time
HERE = os.path.dirname(os.path.abspath(__file__))
RPCS = ["https://base.publicnode.com", "https://1rpc.io/base", "https://base.meowrpc.com"]
STEPS = int(os.environ.get("STEPS", "2400"))
WINDOWS = 6

def rpc_batch(calls):
    out = [None] * len(calls)
    idx = list(range(len(calls)))
    for attempt in range(8):
        if not idx: break
        url = RPCS[attempt % len(RPCS)]
        todo = idx[:]
        idx = []
        for c in range(0, len(todo), 40):
            chunk = todo[c:c + 40]
            payload = json.dumps([{"jsonrpc": "2.0", "id": i, "method": calls[i][0], "params": calls[i][1]} for i in chunk]).encode()
            try:
                req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
                res = json.loads(urllib.request.urlopen(req, timeout=60).read().decode())
                byid = {r["id"]: r for r in res} if isinstance(res, list) else {}
                for i in chunk:
                    if "result" in byid.get(i, {}) and byid[i]["result"] is not None: out[i] = byid[i]["result"]
                    else: idx.append(i)
            except Exception as e:
                print("batch fail (%s): %s" % (url, str(e)[:80])); idx.extend(chunk)
            time.sleep(0.4)
    missing = [i for i in range(len(calls)) if out[i] is None]
    if missing: raise RuntimeError("missing %d headers" % len(missing))
    return out

def latest():
    for u in RPCS:
        try:
            p = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "eth_blockNumber", "params": []}).encode()
            r = urllib.request.Request(u, data=p, headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
            return int(json.loads(urllib.request.urlopen(r, timeout=20).read().decode())["result"], 16)
        except Exception: pass
    raise RuntimeError("no RPC")

tip = latest()
print("tip:", tip, flush=True)
end = tip - 50
starts = [51362571 + 2400 * k for k in range(6)]  # FIXED grid (cached windows are consecutive)
CK = os.path.join(HERE, "blocks2_ck.json")
try: done = json.load(open(CK))
except Exception: done = {}
windows = [None] * WINDOWS
for w, s in enumerate(starts):
    key = str(s)
    if key in done and len(done[key]) == STEPS:
        print("w%d cached" % w, flush=True); windows[w] = done[key]; continue
    calls = [("eth_getBlockByNumber", [hex(b), False]) for b in range(s, s + STEPS)]
    res = rpc_batch(calls)
    blks = [dict(n=int(r["number"], 16), ts=int(r["timestamp"], 16),
                  baseFee=int(r["baseFeePerGas"], 16), gasUsed=int(r["gasUsed"], 16)) for r in res]
    blks.sort(key=lambda b: b["n"])
    ts = [b["ts"] for b in blks]
    print("w%d %d..%d span %.1f min SAVED" % (w, blks[0]["n"], blks[-1]["n"], (ts[-1] - ts[0]) / 60), flush=True)
    done[key] = blks; windows[w] = blks
    json.dump(done, open(CK, "w"))
req = urllib.request.Request("https://api.kraken.com/0/public/OHLC?pair=ETHUSD&interval=1",
                             headers={"User-Agent": "Mozilla/5.0"})
candles = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())["result"]["XETHZUSD"]
candles = [dict(t=c[0], c=float(c[4])) for c in candles]
print("candles: %d %d..%d" % (len(candles), candles[0]["t"], candles[-1]["t"]))
fn = os.path.join(HERE, os.environ.get("OUT", "real_blocks2.json"))
json.dump(dict(windows=windows, candles=candles, tip=tip), open(fn, "w"))
print("saved", fn)
