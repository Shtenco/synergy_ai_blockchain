#!/usr/bin/env python3
"""Minimal deterministic replay of fuzz steps 0-3 to isolate SYNA gap."""
import os, sys
os.environ["SCALE"] = "1"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["MODE"] = "import"
import experiment_syna as X
print("=== replay with noise ===")

e = X.Env(X.WINS[0], 999)
print("genesis phys=%.4f supply=%.4f" % (e.phys_syna(), e.supply))
acts = [(0, 0, 21), (0, 1, 25), (0, 2, 0), (0, 3, 25), (0, 4, 15), (0, 5, 16),
        (1, 0, 20), (1, 1, 9), (1, 2, 31), (1, 3, 1), (1, 4, 8), (1, 5, 12),
        (2, 0, 18), (2, 1, 13), (2, 2, 4), (2, 3, 1), (2, 4, 0), (2, 5, 1),
        (3, 0, 4), (3, 1, 31), (3, 2, 6), (3, 3, 20), (3, 4, 24), (3, 5, 7)]
cur = 0
for (t, i, a) in acts:
    while cur < t:
        _pb, _sb = e.phys_syna(), e.supply
        e.noise_step()
        _pa, _sa = e.phys_syna(), e.supply
        if abs((_pa - _pb) - (_sa - _sb)) > 1e-9:
            print("NOISE-GAP at advance to %d: dphys=%+.4f dsupply=%+.4f" % (cur + 1, _pa - _pb, _sa - _sb))
        e.expire(); e.debt_step(); e.step_block(); cur += 1
        print("after step %d: phys=%.4f supply=%.4f" % (cur - 1, e.phys_syna(), e.supply))
    _p0, _s0 = e.phys_syna(), e.supply
    X.do_trader(e, i, a)
    _p1, _s1 = e.phys_syna(), e.supply
    flag = "" if abs((_p1 - _p0) - (_s1 - _s0)) < 1e-9 else "  <<< GAP!"
    if flag or a in (6, 7, 24):
        print("t=%d agent=%d act=%d dphys=%+.4f dsupply=%+.4f%s" % (t, i, a, _p1 - _p0, _s1 - _s0, flag))
_pb, _sb = e.phys_syna(), e.supply
e.noise_step()
_pa, _sa = e.phys_syna(), e.supply
print("final-noise: dphys=%+.4f dsupply=%+.4f" % (_pa - _pb, _sa - _sb))
print("after noise: phys=%.4f supply=%.4f" % (e.phys_syna(), e.supply))
e.expire(); e.debt_step(); e.step_block()
print("after exp/debt/step: phys=%.4f supply=%.4f" % (e.phys_syna(), e.supply))
print("final phys=%.4f supply=%.4f" % (e.phys_syna(), e.supply))
