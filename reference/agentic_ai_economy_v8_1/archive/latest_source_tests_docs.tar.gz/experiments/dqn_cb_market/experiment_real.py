#!/usr/bin/env python3
"""EXPERIMENT v3 - REAL Base blocks + full circuit.
Internal tok/USDC AMM + P2P spot book + P2P agent credit + CB credit/deposit facilities
+ external REAL USDC/WETH (Kraken 1m candles mapped by real block timestamps).
DQN traders (own rates) + DQN Central Bank (commission x liquidity x rate regime).
Metric: world-wealth delta with full decomposition. All output ASCII.
Deviations from contracts v1 (stated): liquidation SEIZES collateral (v1 moves nothing);
AMM for internal tok market (v1 has no tok venue); CB facilities are new (policy tools).
"""
import json, os
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(HERE, "real_blocks.json")))
CANDLES = sorted(D["candles"], key=lambda c: c["t"])
CTS = [c["t"] for c in CANDLES]; CPX = [c["c"] for c in CANDLES]
def price_at(ts):
    import bisect
    i = bisect.bisect_right(CTS, ts) - 1
    return CPX[max(0, i)]
WINS = D["windows"]
print("windows=%d steps=%d candles=%d" % (len(WINS), len(WINS[0]), len(CANDLES)))
for w in range(len(WINS)):
    ts0, ts1 = WINS[w][0]["ts"], WINS[w][-1]["ts"]
    assert CTS[0] <= ts0 and ts1 <= CTS[-1] + 120, "candle gap w%d" % w
print("price coverage OK: $%.2f..$%.2f" % (min(CPX), max(CPX)))

N_TR = 6; EP_TRAIN = 4; STEPS = 1200
GASU = dict(post=120000, take=150000, cancel=60000, swap=150000, loan=160000)
L1X = 1.3; AAVE = 0.0156; YR = 365.25 * 24 * 3600
MIN_SIZE = 0.005; ACT = 0.02; EXPIRY = 90
COMM_LV = [0, 10, 30, 60, 100]
RATES = [(0.02, 0.03), (0.08, 0.10), (0.18, 0.25)]  # (cb_loan, cb_dep) APY
P2P_AMT = 50.0; P2P_TERM = 120; CB_AMT = 100.0; CB_TERM = 240; DEP_AMT = 50.0
MARKUP = [0.02, 0.02, 0.05, 0.05, 0.10, 0.10]  # own P2P rate markup over CB loan rate
GAMMA = 0.99; HID = 64; BATCH = 48; BUF = 20000; SYNC = 500

class MLP:
    def __init__(self, inp, hid, out, seed):
        g = np.random.default_rng(seed)
        self.W1 = g.normal(0, np.sqrt(2 / inp), (inp, hid)); self.b1 = np.zeros(hid)
        self.W2 = g.normal(0, np.sqrt(2 / hid), (hid, hid)); self.b2 = np.zeros(hid)
        self.W3 = g.normal(0, 1 / hid, (hid, out)); self.b3 = np.zeros(out)
        self.m = [np.zeros_like(p) for p in self.p()]; self.v = [np.zeros_like(p) for p in self.p()]; self.t = 0
    def p(self): return [self.W1, self.b1, self.W2, self.b2, self.W3, self.b3]
    def fwd(self, x):
        z1 = x @ self.W1 + self.b1; a1 = np.maximum(z1, 0)
        z2 = a1 @ self.W2 + self.b2; a2 = np.maximum(z2, 0)
        return z1, a1, z2, a2, a2 @ self.W3 + self.b3
    def q(self, x): return self.fwd(x)[4]
    def fit(self, x, yt, lr=3e-4):
        z1, a1, z2, a2, out = self.fwd(x); n = len(x); d = (out - yt) / n
        gW3 = a2.T @ d; gb3 = d.sum(0); dz2 = (d @ self.W3.T) * (z2 > 0)
        gW2 = a1.T @ dz2; gb2 = dz2.sum(0); dz1 = (dz2 @ self.W2.T) * (z1 > 0)
        gW1 = x.T @ dz1; gb1 = dz1.sum(0); self.t += 1
        for i, gv in enumerate([gW1, gb1, gW2, gb2, gW3, gb3]):
            self.m[i] = 0.9 * self.m[i] + 0.1 * gv; self.v[i] = 0.999 * self.v[i] + 0.001 * gv * gv
            mh = self.m[i] / (1 - 0.9 ** self.t); vh = self.v[i] / (1 - 0.999 ** self.t)
            [self.W1, self.b1, self.W2, self.b2, self.W3, self.b3][i] -= lr * mh / (np.sqrt(vh) + 1e-8)
    def copy_from(self, o):
        for a, b in zip(self.p(), o.p()): a[:] = b

class DQN:
    def __init__(self, ns, na, seed):
        self.net = MLP(ns, HID, na, seed); self.tgt = MLP(ns, HID, na, seed + 777)
        self.tgt.copy_from(self.net); self.buf = []; self.na = na
        self.rg = np.random.default_rng(seed + 999); self.steps = 0
    def act(self, s, eps):
        if self.rg.random() < eps: return int(self.rg.integers(self.na))
        return int(np.argmax(self.net.q(s[None])[0]))
    def push(self, s, a, r, s2, d):
        self.buf.append((s, a, r, s2, d))
        if len(self.buf) > BUF: self.buf.pop(0)
    def upd(self):
        if len(self.buf) < BATCH * 2: return
        self.steps += 1
        idx = self.rg.integers(0, len(self.buf), BATCH)
        S = np.array([self.buf[i][0] for i in idx]); A = np.array([self.buf[i][1] for i in idx])
        R = np.array([self.buf[i][2] for i in idx]); S2 = np.array([self.buf[i][3] for i in idx])
        D = np.array([self.buf[i][4] for i in idx])
        tgt = self.net.q(S).copy()
        tgt[np.arange(BATCH), A] = R + GAMMA * (1 - D) * self.tgt.q(S2).max(1)
        self.net.fit(S, tgt)
        if self.steps % SYNC == 0: self.tgt.copy_from(self.net)

class Env:
    def __init__(self, win):
        self.blk = win; self.t = 0
        self.px = price_at(win[0]["ts"]); self.px0 = self.px
        self.rets = []; self.vols = []
        self.nav = 800.0; self.supply = 1800.0  # 800 USDC cash + AMM 400 USDC, 1800 tok
        self.amm = dict(tok=600.0, usdc=400.0)  # ammpx 0.667 == navpx 0.667 (calibrated)
        self.cumAave = 0.0; self.comm_bps = 100; self.rate_i = 1
        self.tr = [dict(usdc=1800.0, weth=0.5, tok=200.0, lu=0.0, lw=0.0, coll=0.0, esc=0.0) for _ in range(N_TR)]
        self.cb = dict(usdc=1500.0, weth=0.6, lu=0.0, lw=0.0)
        self.bids = []; self.asks = []; self.oid = 0
        self.offers = []; self.debts = []
        self.vol = 0.0; self.comms = 0.0; self.cgas = 0.0; self.trades = 0
        self.fees_amm = 0.0; self.int_p2p = 0.0; self.int_cb = 0.0
        self.funded_p2p = 0.0; self.funded_cb = 0.0; self.defaults = 0; self.liqs = 0
        self.provided = 0; self.defends = 0; self.swaps = 0
        self.cb_hist = []
    def gas_u(self, k):
        return GASU[k] * self.blk[self.t]["baseFee"] * L1X / 1e18 * self.px
    def navpx(self): return (self.nav + self.amm["usdc"]) / self.supply
    def ammpx(self): return self.amm["usdc"] / self.amm["tok"] if self.amm["tok"] > 0 else self.navpx()
    def wealth(self, i):
        a = self.tr[i]
        return a["usdc"] + a["lu"] + a["esc"] + (a["weth"] + a["lw"] + a["coll"]) * self.px + a["tok"] * self.navpx()
    def cbwealth(self):
        c = self.cb
        return c["usdc"] + c["lu"] + (c["weth"] + c["lw"]) * self.px
    def world(self):
        # NAV (cash + AMM usdc) is represented via ALL 1800 tok incl. pool's 600
        return sum(self.wealth(i) for i in range(N_TR)) + self.cbwealth() + self.amm["tok"] * self.navpx()
    def gini(self):
        w = np.sort(np.array([self.wealth(i) for i in range(N_TR)]))
        return float((2 * np.arange(1, N_TR + 1) @ w) / (N_TR * w.sum()) - (N_TR + 1) / N_TR)
    def best(self):
        return (max([o["price"] for o in self.bids], default=None), min([o["price"] for o in self.asks], default=None))
    def vol20(self):
        r = np.array(self.rets[-20:])
        return float(r.std() * 10000) if len(r) > 1 else 0.0
    def spread(self):
        bb, ba = self.best()
        if bb is None or ba is None: return 200.0
        return max(0.0, float((ba - bb) / self.px * 10000))
    # ----- spot book -----
    def post(self, who, side, price, size):
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("post")
        if side == "bid":
            if A["usdc"] < price * size + g or size < MIN_SIZE: return False
            A["usdc"] -= price * size + g; A["lu"] += price * size; self.cgas += g
            o = dict(id=self.oid, who=who, side=side, price=price, size=size, t=self.t, lock=price * size)
        else:
            if A["weth"] < size or A["usdc"] < g or size < MIN_SIZE: return False
            A["weth"] -= size; A["lw"] += size; A["usdc"] -= g; self.cgas += g
            o = dict(id=self.oid, who=who, side=side, price=price, size=size, t=self.t, lock=size)
        self.oid += 1
        (self.bids if side == "bid" else self.asks).append(o)
        self._match(o); return True
    def _freed(self, who, side, amt):
        if amt <= 1e-12: return
        A = self.cb if who == "cb" else self.tr[who]
        if side == "bid": A["lu"] -= amt; A["usdc"] += amt
        else: A["lw"] -= amt; A["weth"] += amt
    def _match(self, inc):
        opp = [o for o in (self.asks if inc["side"] == "bid" else self.bids) if o["who"] != inc["who"]]
        opp.sort(key=lambda o: (o["price"] if inc["side"] == "bid" else -o["price"], o["t"]))
        while inc["size"] > 1e-9 and opp:
            r = opp[0]
            cross = (inc["price"] >= r["price"]) if inc["side"] == "bid" else (inc["price"] <= r["price"])
            if not cross: break
            q = min(inc["size"], r["size"])
            rb0, rl0, ib0, il0 = r["size"], r["lock"], inc["size"], inc["lock"]
            if not self._exec(inc["who"] if inc["side"] == "bid" else r["who"],
                              r["who"] if inc["side"] == "bid" else inc["who"], r["price"], q, inc["who"]): break
            rr = rl0 * (q / rb0); ir = il0 * (q / ib0)
            r["size"] -= q; r["lock"] -= rr; self._freed(r["who"], r["side"], rr)
            inc["size"] -= q; inc["lock"] -= ir; self._freed(inc["who"], inc["side"], ir)
            if r["size"] <= 1e-9: opp.pop(0)
        if inc["size"] > 1e-9 and opp:
            bp = opp[0]["price"]
            cross = (inc["price"] >= bp) if inc["side"] == "bid" else (inc["price"] <= bp)
            if cross:
                self._freed(inc["who"], inc["side"], inc["lock"])
                inc["size"] = 0.0; inc["lock"] = 0.0
        if inc["size"] <= 1e-9:
            self._freed(inc["who"], inc["side"], inc["lock"]); inc["lock"] = 0.0
            self.bids = [o for o in self.bids if o["id"] != inc["id"]]
            self.asks = [o for o in self.asks if o["id"] != inc["id"]]
        self.bids = [o for o in self.bids if o["size"] > 1e-9]
        self.asks = [o for o in self.asks if o["size"] > 1e-9]
    def _exec(self, buyer, seller, price, size, taker):
        val = price * size; cm = val * self.comm_bps / 10000
        B = self.cb if buyer == "cb" else self.tr[buyer]
        S = self.cb if seller == "cb" else self.tr[seller]
        needB = val + (cm if taker == buyer else 0)
        needS = cm if taker == seller else 0
        if B["usdc"] < needB - 1e-9 or S["usdc"] < needS - 1e-9: return False
        B["usdc"] -= needB; S["usdc"] += val; S["usdc"] -= needS
        B["weth"] += size; S["weth"] -= size
        self.nav += cm; self.comms += cm; self.vol += val; self.trades += 1
        return True
    def take(self, who, side):
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("take"); bb, ba = self.best()
        if side == "buy" and ba is not None:
            o = min(self.asks, key=lambda o: (o["price"], o["t"])); q = min(ACT, o["size"])
            if A["usdc"] < ba * q * (1 + self.comm_bps / 10000) + g: return False
            A["usdc"] -= g; self.cgas += g
            inc = dict(id=self.oid, who=who, side="bid", price=ba * 1.2, size=q, t=self.t, lock=0.0)
            self.oid += 1; self._match(inc); return True
        if side == "sell" and bb is not None:
            o = max(self.bids, key=lambda o: (o["price"], -o["t"])); q = min(ACT, o["size"])
            if A["weth"] < q or A["usdc"] < g: return False
            A["usdc"] -= g; self.cgas += g
            inc = dict(id=self.oid, who=who, side="ask", price=bb * 0.8, size=q, t=self.t, lock=0.0)
            A["weth"] -= q; A["lw"] += q; inc["lock"] = q
            self.oid += 1; self._match(inc)
            if inc["size"] > 1e-9: self.asks.append(inc)
            elif inc["lock"] > 1e-9: A["lw"] -= inc["lock"]; A["weth"] += inc["lock"]
            return True
        return False
    def cancel_oldest(self, who):
        own = [o for o in self.bids + self.asks if o["who"] == who]
        if not own: return False
        o = min(own, key=lambda o: o["t"])
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("cancel")
        if A["usdc"] < g: return False
        A["usdc"] -= g; self.cgas += g
        if o["side"] == "bid": A["lu"] -= o["lock"]; A["usdc"] += o["lock"]
        else: A["lw"] -= o["lock"]; A["weth"] += o["lock"]
        self.bids = [x for x in self.bids if x["id"] != o["id"]]
        self.asks = [x for x in self.asks if x["id"] != o["id"]]
        return True
    def expire(self):
        for bk in ("bids", "asks"):
            keep = []
            for o in getattr(self, bk):
                if self.t - o["t"] > EXPIRY:
                    A = self.cb if o["who"] == "cb" else self.tr[o["who"]]
                    if o["side"] == "bid": A["lu"] -= o["lock"]; A["usdc"] += o["lock"]
                    else: A["lw"] -= o["lock"]; A["weth"] += o["lock"]
                else: keep.append(o)
            setattr(self, bk, keep)
    # ----- internal AMM tok/USDC -----
    def swap(self, i, buy):
        a = self.tr[i]; g = self.gas_u("swap")
        if a["usdc"] < g: return False
        if buy:
            u = 20.0
            if a["usdc"] < u + g: return False
            fee = u * 0.003; net = u - fee
            dx = self.amm["tok"] * net / (self.amm["usdc"] + net)
            a["usdc"] -= u + g; self.cgas += g
            self.amm["usdc"] += net; self.amm["tok"] -= dx; self.nav += fee
            a["tok"] += dx; self.swaps += 1; self.fees_amm += fee; return True
        else:
            q = 5.0
            if a["tok"] < q: return False
            a["usdc"] -= g; self.cgas += g
            gross = self.amm["usdc"] * q / (self.amm["tok"] + q)
            fee = gross * 0.003; dy = gross - fee  # fee stays in pool (no air-mint)
            a["tok"] -= q; a["usdc"] += dy
            self.amm["tok"] += q; self.amm["usdc"] -= dy
            self.swaps += 1; self.fees_amm += fee; return True
    # ----- P2P credit -----
    def p2p_offer(self, i):
        a = self.tr[i]; g = self.gas_u("loan")
        rate = RATES[self.rate_i][0] + MARKUP[i]  # own rate: CB policy + own markup
        if a["usdc"] < P2P_AMT + g: return False
        a["usdc"] -= P2P_AMT + g; a["esc"] += P2P_AMT; self.cgas += g
        self.offers.append(dict(lender=i, amt=P2P_AMT, rate=rate, t0=self.t)); return True
    def p2p_accept(self, i):
        a = self.tr[i]
        cands = [o for o in self.offers if o["lender"] != i]
        if not cands: return False
        o = min(cands, key=lambda o: o["rate"])
        need = o["amt"] * 1.5 / self.px
        if a["weth"] < need: return False
        g = self.gas_u("loan")
        if a["usdc"] < g: return False
        a["usdc"] -= g; self.cgas += g
        self.offers.remove(o)
        L = self.tr[o["lender"]]; L["esc"] -= o["amt"]
        a["weth"] -= need; a["coll"] += need; a["usdc"] += o["amt"]
        self.debts.append(dict(kind="p2p", bor=i, len=o["lender"], pr=o["amt"], rate=o["rate"],
                               t0=self.blk[self.t]["ts"], term=P2P_TERM, coll=need, done=False))
        self.funded_p2p += o["amt"]; return True
    # ----- CB facilities -----
    def cb_borrow(self, i):
        a = self.tr[i]; rl, rd = RATES[self.rate_i]; g = self.gas_u("loan")
        need = CB_AMT * 1.3 / self.px
        if a["weth"] < need or self.cb["usdc"] < CB_AMT or a["usdc"] < g: return False
        a["usdc"] -= g; self.cgas += g
        a["weth"] -= need; a["coll"] += need; a["usdc"] += CB_AMT; self.cb["usdc"] -= CB_AMT
        self.debts.append(dict(kind="cbloan", bor=i, len="cb", pr=CB_AMT, rate=rl,
                               t0=self.blk[self.t]["ts"], term=CB_TERM, coll=need, done=False))
        self.funded_cb += CB_AMT; return True
    def cb_deposit(self, i):
        a = self.tr[i]; rl, rd = RATES[self.rate_i]; g = self.gas_u("loan")
        if self.cb["usdc"] < DEP_AMT or a["usdc"] < g: return False
        a["usdc"] -= g; self.cgas += g
        a["usdc"] += DEP_AMT; self.cb["usdc"] -= DEP_AMT
        self.debts.append(dict(kind="cbdep", bor=i, len="cb", pr=DEP_AMT, rate=rd,
                               t0=self.blk[self.t]["ts"], term=CB_TERM, coll=0.0, done=False))
        self.funded_cb += DEP_AMT; return True
    def _settle_debt(self, L, now_ts, force=False):
        el = now_ts - L["t0"]; due_term = L["term"] * 2  # ~2s per step
        if not force and el < due_term: return False
        intr = L["pr"] * L["rate"] * el / YR; due = L["pr"] + intr
        b = self.tr[L["bor"]]
        if b["usdc"] >= due:
            b["usdc"] -= due
            if L["kind"] == "p2p":
                self.tr[L["len"]]["usdc"] += due; self.int_p2p += intr
                b["weth"] += L["coll"]; b["coll"] -= L["coll"]
            else:
                self.cb["usdc"] += due; self.int_cb += intr
                if L["coll"] > 0: b["weth"] += L["coll"]; b["coll"] -= L["coll"]
        else:
            self.defaults += 1
            if L["kind"] == "p2p":
                self.tr[L["len"]]["usdc"] += 0.0
                if L["coll"] > 0:  # seize (deviation from v1 noted in header)
                    self.tr[L["len"]]["weth"] += L["coll"]; b["coll"] -= L["coll"]
            else:
                if L["coll"] > 0: self.cb["weth"] += L["coll"]; b["coll"] -= L["coll"]
        L["done"] = True; return True
    def debt_step(self):
        now = self.blk[self.t]["ts"]
        for L in self.debts:
            if L["done"]: continue
            el = now - L["t0"]; acc = L["pr"] * L["rate"] * el / YR
            if L["coll"] > 0 and L["coll"] * self.px < 1.2 * (L["pr"] + acc):
                b = self.tr[L["bor"]]  # liquidate: seize collateral, close
                if L["kind"] == "p2p": self.tr[L["len"]]["weth"] += L["coll"]
                else: self.cb["weth"] += L["coll"]
                b["coll"] -= L["coll"]; L["done"] = True; self.liqs += 1; continue
            self._settle_debt(L, now)
    # ----- block step -----
    def step_block(self):
        a = self.blk[self.t]; b = self.blk[min(self.t + 1, STEPS - 1)]
        dt = max(1, b["ts"] - a["ts"])
        self.px = price_at(a["ts"])
        if self.t > 0: self.rets.append(np.log(self.px / self._pp))
        self._pp = self.px
        y = (self.nav + self.amm["usdc"]) * AAVE * dt / YR
        self.nav += y; self.cumAave += y
        self.t += 1
        return dt

def trader_state(e, i):
    a = e.tr[i]; w = e.wealth(i)
    r1 = e.rets[-1] * 100 if e.rets else 0.0
    debt = sum(L["pr"] for L in e.debts if not L["done"] and L["bor"] == i)
    offers = [o["rate"] for o in e.offers if o["lender"] != i]
    bo = min(offers) if offers else 0.3
    prem = (e.ammpx() / e.navpx() - 1) * 100
    return np.array([(a["weth"] * e.px) / w - 0.5, a["usdc"] / w - 0.5, r1 * 10, e.vol20() / 100,
                     min(e.spread(), 300) / 100, (w - 3192) / 3192, (e.navpx() - 1.0) * 100,
                     e.t / STEPS, (a["tok"] * e.navpx()) / w - 0.3, debt / 500,
                     bo * 5, RATES[e.rate_i][0] * 5, max(-5, min(5, prem)), (a["coll"] * e.px) / w], dtype=float)

def cb_state(e, w0):
    imb = sum(a["weth"] * e.px - a["usdc"] for a in e.tr) / 20000
    out = sum(L["pr"] for L in e.debts if not L["done"]) / 1000
    prem = max(-5, min(5, (e.ammpx() / e.navpx() - 1) * 100))
    return np.array([e.vol20() / 100, min(e.spread(), 300) / 100, np.log1p(e.vol) / 5,
                     ((e.nav + e.amm["usdc"]) - 1200) / 1200, e.gini() * 3, imb,
                     (e.cbwealth() - 4430) / 4430, e.t / STEPS, out, prem], dtype=float)

def do_trader(e, i, a):
    import os as _os
    _mask = _os.environ.get("MASK", "")
    if _mask and str(a) in _mask.split(","): return
    p = e.px
    if a == 1: e.post(i, "bid", p * (1 - 25 / 1e4), ACT)
    elif a == 2: e.post(i, "bid", p * (1 - 5 / 1e4), ACT)
    elif a == 3: e.post(i, "ask", p * (1 + 5 / 1e4), ACT)
    elif a == 4: e.post(i, "ask", p * (1 + 25 / 1e4), ACT)
    elif a == 5: e.take(i, "buy")
    elif a == 6: e.take(i, "sell")
    elif a == 7: e.cancel_oldest(i)
    elif a == 8: e.p2p_offer(i)
    elif a == 9: e.p2p_accept(i)
    elif a == 10: e.cb_borrow(i)
    elif a == 11: e.cb_deposit(i)
    elif a == 12: e.swap(i, True)
    elif a == 13: e.swap(i, False)

def do_cb(e, a):
    ci, rest = divmod(a, 9); liq, ri = divmod(rest, 3)
    e.comm_bps = COMM_LV[ci]; e.rate_i = ri; e.cb_hist.append((COMM_LV[ci], ri))
    p = e.px
    if liq == 1:
        e.provided += 1
        for o in list(e.bids) + list(e.asks):
            if o["who"] == "cb":
                if o["side"] == "bid": e.cb["lu"] -= o["lock"]; e.cb["usdc"] += o["lock"]
                else: e.cb["lw"] -= o["lock"]; e.cb["weth"] += o["lock"]
        e.bids = [o for o in e.bids if o["who"] != "cb"]; e.asks = [o for o in e.asks if o["who"] != "cb"]
        e.post("cb", "bid", p * (1 - 15 / 1e4), 0.05); e.post("cb", "ask", p * (1 + 15 / 1e4), 0.05)
    elif liq == 2:
        r5 = float(np.sum(e.rets[-5:])) if len(e.rets) >= 5 else 0.0
        if r5 > 0.003: e.take("cb", "sell"); e.defends += 1
        elif r5 < -0.003: e.take("cb", "buy"); e.defends += 1

def run_episode(win, traders, cb, eps_t, eps_c, train, random_cb=False, comm_fixed=None):
    e = Env(win); W0 = e.world()
    totW0 = sum(a["weth"] for a in e.tr) + e.cb["weth"]
    S_t = [trader_state(e, i) for i in range(N_TR)]; S_c = cb_state(e, W0)
    pw = [e.wealth(i) for i in range(N_TR)]; prevW = W0; prevG = e.gini()
    vols = []; maxdrift = 0.0; drift_t = -1
    totW = sum(a["weth"] + a["lw"] + a["coll"] for a in e.tr) + e.cb["weth"] + e.cb["lw"]
    for t in range(STEPS):
        acts = [traders[i].act(S_t[i], eps_t) for i in range(N_TR)]
        for i, a in enumerate(acts): do_trader(e, i, a)
        if random_cb and comm_fixed is None:
            a_c = int(np.random.default_rng(7 + t).integers(45)); do_cb(e, a_c)
        elif comm_fixed is None:
            a_c = cb.act(S_c, eps_c); do_cb(e, a_c)
        e.expire(); e.debt_step(); e.step_block()
        vols.append(e.vol20())
        dr = (e.world() + e.cgas - (W0 + e.cumAave)) - totW * (e.px - e.px0)
        if abs(dr) > abs(maxdrift): maxdrift = dr; drift_t = t
        S2 = [trader_state(e, i) for i in range(N_TR)]; w2 = [e.wealth(i) for i in range(N_TR)]
        done = (t == STEPS - 1)
        if train:
            for i in range(N_TR):
                r = (w2[i] - pw[i]) / 10.0 - 0.02 * abs(e.tr[i]["weth"] * e.px - e.tr[i]["usdc"]) / 2000
                traders[i].push(S_t[i], acts[i], r, S2[i], done); traders[i].upd()
            if comm_fixed is None and not random_cb:
                wW = e.world(); gN = e.gini()
                rcb = (wW - prevW) / 100.0 - 0.01 * e.vol20() - 5.0 * max(0.0, gN - prevG)
                cb.push(S_c, a_c, rcb, cb_state(e, W0), done); cb.upd()
                prevW = wW; prevG = gN
        S_t = S2
        if comm_fixed is None: S_c = cb_state(e, W0)
        pw = w2
    # settle open debts
    now = e.blk[STEPS - 1]["ts"]
    for L in e.debts:
        if not L["done"]: e._settle_debt(L, now, force=True)
    for k, o in list(enumerate(e.bids + e.asks)):
        A = e.cb if o["who"] == "cb" else e.tr[o["who"]]
        if o["side"] == "bid": A["lu"] -= o["lock"]; A["usdc"] += o["lock"]
        else: A["lw"] -= o["lock"]; A["weth"] += o["lock"]
    e.bids = []; e.asks = []
    for a in e.tr:
        if a["esc"] > 0: a["usdc"] += a["esc"]; a["esc"] = 0.0
    mtm = totW0 * (e.px - e.px0)
    dW = e.world() - W0
    edge = dW - mtm - e.cumAave + e.cgas
    weth1 = sum(a["weth"] + a["lw"] + a["coll"] for a in e.tr) + e.cb["weth"] + e.cb["lw"]
    return dict(dW=dW, mtm=mtm, edge=edge, volmean=float(np.mean(vols)), comms=e.comms,
                volume=e.vol, trades=e.trades, gini=e.gini(), gas=e.cgas, aave=e.cumAave,
                intp2p=e.int_p2p, intcb=e.int_cb, fp2p=e.funded_p2p, fcb=e.funded_cb,
                dflt=e.defaults, liq=e.liqs, swaps=e.swaps, fam=e.fees_amm,
                nav=e.nav + e.amm["usdc"], prem=(e.ammpx() / e.navpx() - 1) * 100,
                prov=e.provided, dfn=e.defends, w0=W0, w1=e.world(), cbw=e.cbwealth(),
                avgcomm=float(np.mean([c for c, _ in e.cb_hist])) if e.cb_hist else e.comm_bps,
                avgri=float(np.mean([r for _, r in e.cb_hist])) if e.cb_hist else e.rate_i,
                px0=e.px0, px1=e.px, maxdrift=maxdrift, drift_t=drift_t, weth0=totW0, weth1=weth1)

def train_scenario(name, cb_seed, use_cb, random_cb=False, comm_fixed=None):
    print("--- training %s ---" % name)
    traders = [DQN(14, 14, 1000 + 17 * i + 11) for i in range(N_TR)]
    cb = DQN(10, 45, 5000 + cb_seed) if use_cb else None
    for ep in range(EP_TRAIN):
        eps = max(0.05, 1.0 - ep / EP_TRAIN)
        m = run_episode(WINS[ep], traders, cb, eps, eps, True, random_cb, comm_fixed)
        print("ep%d blk%d dW=%+.1f edge=%+.1f loans(p2p/cb)=%.0f/%.0f dflt=%d maxdrift=%.2f@%d weth %.4f->%.4f" %
              (ep, WINS[ep][0]["n"], m["dW"], m["edge"], m["fp2p"], m["fcb"], m["dflt"], m["maxdrift"], m["drift_t"], m["weth0"], m["weth1"]))
    m = run_episode(WINS[4], traders, cb, 0.0, 0.0, False, random_cb, comm_fixed)
    m["name"] = name
    return m

if os.environ.get("MODE", "full") == "unit":
    # ---- matching-engine conservation unit tests (deterministic) ----
    fails = 0
    def check(tag, e, w0, g0, a0):
        global fails
        drift = (e.world() + (e.cgas - g0) - (w0 + (e.cumAave - a0))) - 3.6 * (e.px - e.px0)
        weth = sum(a["weth"] + a["lw"] + a["coll"] for a in e.tr) + e.cb["weth"] + e.cb["lw"]
        ok = abs(drift) < 1e-9 and abs(weth - 3.6) < 1e-9
        if not ok: fails += 1
        print("%s drift=%.3e weth=%.6f %s" % (tag, drift, weth, "OK" if ok else "FAIL"))
    e = Env(WINS[4]); w0 = e.world()
    e.comm_bps = 100
    def dump(tag):
        print("--- " + tag + " nav=%.4f cgas=%.4f" % (e.nav, e.cgas))
        for i in range(N_TR):
            a = e.tr[i]
            print("  P%d u=%.4f lu=%.4f w=%.6f lw=%.6f coll=%.4f esc=%.4f tok=%.3f" %
                  (i, a["usdc"], a["lu"], a["weth"], a["lw"], a["coll"], a["esc"], a["tok"]))
        print("  bids=%s asks=%s" % ([(o["who"], round(o["price"], 2), round(o["size"], 4), round(o["lock"], 4)) for o in e.bids],
                                      [(o["who"], round(o["price"], 2), round(o["size"], 4), round(o["lock"], 4)) for o in e.asks]))
    e.post(0, "ask", e.px * 0.99, 0.05); dump("post-ask"); check("post-ask", e, w0, 0, 0)
    e.post(1, "bid", e.px * 1.01, 0.05); dump("cross-bid"); check("cross-bid", e, w0, 0, 0)
    e.post(2, "bid", e.px * 0.98, 0.05); e.post(3, "ask", e.px * 1.02, 0.05)
    check("resting", e, w0, 0, 0)
    e.take(4, "buy"); check("take-buy", e, w0, 0, 0)
    e.take(5, "sell"); check("take-sell", e, w0, 0, 0)
    e.take(0, "sell"); check("take-sell2", e, w0, 0, 0)
    e.cancel_oldest(2); check("cancel", e, w0, 0, 0)
    e.t = 500; e.expire(); check("expire", e, w0, 0, 0)
    e.swap(0, True); check("swap-buy", e, w0, 0, 0)
    e.swap(1, False); check("swap-sell", e, w0, 0, 0)
    e.p2p_offer(0); check("offer", e, w0, 0, 0)
    e.p2p_accept(1); check("accept", e, w0, 0, 0)
    e.cb_borrow(2); check("cb-borrow", e, w0, 0, 0)
    e.cb_deposit(3); check("cb-deposit", e, w0, 0, 0)
    for L in e.debts: e._settle_debt(L, e.blk[100]["ts"], force=True)
    check("settle", e, w0, 0, 0)
    print("UNIT " + ("PASS" if fails == 0 else "FAIL(%d)" % fails))
    raise SystemExit
res = [train_scenario("A NO_CB", 11, False, comm_fixed=100),
       train_scenario("B DQN_CB", 22, True),
       train_scenario("C RAND_CB", 33, False, random_cb=True)]
print("=" * 78)
print("EVAL on REAL blocks %d..%d (~40min), REAL Kraken ETH $%.2f->$%s" % (WINS[4][0]["n"], WINS[4][-1]["n"], res[0]["px0"], "%.2f" % res[0]["px1"]))
for m in res:
    print("%s\n  dWorld=%+.2f = MTM%+.2f + edge%+.2f + aave%.3f - gas%.2f | volMean=%.0fbps TR=%d VOL=%.0f" %
          (m["name"], m["dW"], m["mtm"], m["edge"], m["aave"], m["gas"], m["volmean"], m["trades"], m["volume"]))
    print("  spotFees=%.2f ammFees=%.2f intP2P=%.4f intCB=%.4f fundP2P=%.0f fundCB=%.0f dflt=%d liq=%d swaps=%d" %
          (m["comms"], m["fam"], m["intp2p"], m["intcb"], m["fp2p"], m["fcb"], m["dflt"], m["liq"], m["swaps"]))
    print("  NAV=%.1f tokPrem=%+.2f%% gini=%.3f CB:comm=%.0f rateIdx=%.1f prov=%d def=%d treas=%.1f" %
          (m["nav"], m["prem"], m["gini"], m["avgcomm"], m["avgri"], m["prov"], m["dfn"], m["cbw"]))
b = res[1]; a = res[0]
print("CB effect vs NO_CB: dWorld %+.2f (edge %+.2f vs %+.2f)" % (b["dW"] - a["dW"], b["edge"], a["edge"]))
json.dump(dict(scen=[{k: float(v) for k, v in m.items() if k != "name"} | {"name": m["name"]} for m in res]),
          open(os.path.join(HERE, "results_real.json"), "w"), indent=2)
print("saved results_real.json")
