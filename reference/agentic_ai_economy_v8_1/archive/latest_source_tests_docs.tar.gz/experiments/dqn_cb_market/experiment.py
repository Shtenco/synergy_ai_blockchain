#!/usr/bin/env python3
"""
ECONOMIC EXPERIMENT: P2P market of DQN trader-agents + DQN Central Bank + external USDC/WETH.
Base: Anti-Ponzi P2P system (CoreToken NAV + P2PMarket order book), Base-mainnet params.
New vs v2: external price discovery exists (WETH/USDC oracle, GBM anchored at LIVE ETH price),
so gains-from-trade exist; robots set own quotes; DQN-CB regulates (commission + interventions).

Scenarios (same eval price path for fairness):
  A NO_CB    - fixed commission 100 bps, no interventions
  B DQN_CB   - DQN Central Bank: commission {0,10,30,60,100}bps x liquidity {none,provide,defend}
  C RAND_CB  - random CB actions (ablation)
Traders: 6 independent DQN agents, own reward = own wealth delta - gas.
CB reward = world-wealth growth - vol penalty - inequality penalty (formula below).
DQN implemented from scratch in numpy (MLP + Adam + replay + target net). No torch needed.
Money conservation checked every episode. All output ASCII.
"""
import urllib.request, json, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

def live_eth():
    try:
        r = urllib.request.Request("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd",
                                   headers={"User-Agent": "Mozilla/5.0"})
        return float(json.loads(urllib.request.urlopen(r, timeout=15).read().decode())["ethereum"]["usd"])
    except Exception:
        return 2400.0

P0 = live_eth()
print("LIVE ETH anchor: $%.2f" % P0)

# ---------------- hyperparams ----------------
N_TR = 6
EP_TRAIN = 4
STEPS = 2400          # 1 step = 1 min external time => 40 h per episode
DT_MIN = 1.0
SIGMA_ANN = 0.9
EVAL_SEED = 999
GAMMA = 0.99
HID = 48
BATCH = 48
BUF = 20000
SYNC = 500
# Base live gas (L2 + L1 factor), converted to USDC at oracle
GAS_WEI = 6e6         # 0.006 gwei
L1X = 1.3
GAS_UNITS = dict(post=120000, take=150000, cancel=60000)
MIN_SIZE = 0.005
ACT_SIZE = 0.02
EXPIRY = 90
AAVE_APY = 0.0156
SPY_MIN = 365.25 * 24 * 60

# ---------------- tiny DQN (numpy + Adam) ----------------
class MLP:
    def __init__(self, inp, hid, out, seed):
        g = np.random.default_rng(seed)
        self.W1 = g.normal(0, np.sqrt(2 / inp), (inp, hid)); self.b1 = np.zeros(hid)
        self.W2 = g.normal(0, np.sqrt(2 / hid), (hid, hid)); self.b2 = np.zeros(hid)
        self.W3 = g.normal(0, 1 / hid, (hid, out)); self.b3 = np.zeros(out)
        self.m = [np.zeros_like(p) for p in self.p()]; self.v = [np.zeros_like(p) for p in self.p()]
        self.t = 0
    def p(self): return [self.W1, self.b1, self.W2, self.b2, self.W3, self.b3]
    def fwd(self, x):
        z1 = x @ self.W1 + self.b1; a1 = np.maximum(z1, 0)
        z2 = a1 @ self.W2 + self.b2; a2 = np.maximum(z2, 0)
        return z1, a1, z2, a2, a2 @ self.W3 + self.b3
    def q(self, x): return self.fwd(x)[4]
    def fit(self, x, yt, lr=3e-4):
        z1, a1, z2, a2, out = self.fwd(x); n = len(x)
        d = (out - yt) / n
        gW3 = a2.T @ d; gb3 = d.sum(0)
        da2 = d @ self.W3.T; dz2 = da2 * (z2 > 0)
        gW2 = a1.T @ dz2; gb2 = dz2.sum(0)
        da1 = dz2 @ self.W2.T; dz1 = da1 * (z1 > 0)
        gW1 = x.T @ dz1; gb1 = dz1.sum(0)
        self.t += 1
        for i, gv in enumerate([gW1, gb1, gW2, gb2, gW3, gb3]):
            self.m[i] = 0.9 * self.m[i] + 0.1 * gv
            self.v[i] = 0.999 * self.v[i] + 0.001 * gv * gv
            mh = self.m[i] / (1 - 0.9 ** self.t); vh = self.v[i] / (1 - 0.999 ** self.t)
            for arr, name in ((self.W1, "W1"),):
                pass
            [self.W1, self.b1, self.W2, self.b2, self.W3, self.b3][i] -= lr * mh / (np.sqrt(vh) + 1e-8)
    def copy_from(self, o):
        for a, b in zip(self.p(), o.p()): a[:] = b

class DQN:
    def __init__(self, ns, na, seed):
        self.net = MLP(ns, HID, na, seed); self.tgt = MLP(ns, HID, na, seed + 777)
        self.tgt.copy_from(self.net); self.buf = []; self.na = na
        self.rg = np.random.default_rng(seed + 999); self.steps = 0
    def act(self, s, eps):
        if self.rg.random() < eps: return int(self.rg.integers(self.na))
        return int(np.argmax(self.net.q(s[None])[0]))
    def push(self, s, a, r, s2, d):
        self.buf.append((s, a, r, s2, d))
        if len(self.buf) > BUF: self.buf.pop(0)
    def upd(self):
        if len(self.buf) < BATCH * 2: return
        self.steps += 1
        idx = self.rg.integers(0, len(self.buf), BATCH)
        S = np.array([self.buf[i][0] for i in idx]); A = np.array([self.buf[i][1] for i in idx])
        R = np.array([self.buf[i][2] for i in idx]); S2 = np.array([self.buf[i][3] for i in idx])
        D = np.array([self.buf[i][4] for i in idx])
        q2 = self.tgt.q(S2); tgt = self.net.q(S).copy()
        tgt[np.arange(BATCH), A] = R + GAMMA * (1 - D) * q2.max(1)
        self.net.fit(S, tgt)
        if self.steps % SYNC == 0: self.tgt.copy_from(self.net)

# ---------------- market env ----------------
COMM_FREEZE = {0: 100}  # scenario A fixed commission
COMM_LEVELS = [0, 10, 30, 60, 100]

class Env:
    def __init__(self, seed, comm_fixed=None):
        self.rg = np.random.default_rng(seed)
        self.px = P0; self.t = 0
        self.rets = []
        self.nav = 1200.0; self.supply = 1200.0; self.cumAave = 0.0
        self.comm_bps = comm_fixed if comm_fixed is not None else 100
        self.tr = [dict(usdc=1800.0, weth=0.5, tok=200.0, lock_u=0.0, lock_w=0.0) for _ in range(N_TR)]
        self.cb = dict(usdc=1500.0, weth=0.6, lock_u=0.0, lock_w=0.0)
        self.bids = []; self.asks = []; self.oid = 0
        self.vol = 0.0; self.comms = 0.0; self.cgas = 0.0; self.trades = 0
        self.spreads = []; self.vols = []; self.provided = 0; self.defends = 0
        self.cb_comm_hist = []
    def gas_u(self, k): return GAS_UNITS[k] * GAS_WEI * L1X / 1e18 * self.px
    def navpx(self): return self.nav / self.supply
    def wealth(self, i):
        a = self.tr[i]
        return a["usdc"] + a["lock_u"] + (a["weth"] + a["lock_w"]) * self.px + a["tok"] * self.navpx()
    def cbwealth(self):
        c = self.cb
        return c["usdc"] + c["lock_u"] + (c["weth"] + c["lock_w"]) * self.px
    def world(self): return sum(self.wealth(i) for i in range(N_TR)) + self.cbwealth()
    def gini(self):
        w = np.array([self.wealth(i) for i in range(N_TR)])
        w = np.sort(w); n = len(w); m = w.mean()
        return (2 * np.arange(1, n + 1) @ w) / (n * w.sum()) - (n + 1) / n if m > 0 else 0.0
    def best(self):
        bb = max([o["price"] for o in self.bids], default=None)
        ba = min([o["price"] for o in self.asks], default=None)
        return bb, ba
    def post(self, who, side, price, size):
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("post")
        if side == "bid":
            need = price * size + g
            if A["usdc"] < need or size < MIN_SIZE: return False
            A["usdc"] -= need; A["lock_u"] += price * size; self.cgas += g
            o = dict(id=self.oid, who=who, side=side, price=price, size=size, t=self.t, lock=price * size)
        else:
            if A["weth"] < size or A["usdc"] < g or size < MIN_SIZE: return False
            A["weth"] -= size; A["lock_w"] += size; A["usdc"] -= g; self.cgas += g
            o = dict(id=self.oid, who=who, side=side, price=price, size=size, t=self.t, lock=size)
        self.oid += 1
        (self.bids if side == "bid" else self.asks).append(o)
        self._match(o)
        return True
    def _release(self, o):
        A = self.cb if o["who"] == "cb" else self.tr[o["who"]]
        if o["side"] == "bid": A["lock_u"] -= o["lock"]; A["usdc"] += o["lock"]
        else: A["lock_w"] -= o["lock"]; A["weth"] += o["lock"]
    def _match(self, inc):
        opp = self.asks if inc["side"] == "bid" else self.bids
        opp.sort(key=lambda o: (o["price"] if inc["side"] == "bid" else -o["price"], o["t"]))
        while inc["size"] > 1e-9 and opp:
            r = opp[0]
            cross = (inc["price"] >= r["price"]) if inc["side"] == "bid" else (inc["price"] <= r["price"])
            if not cross: break
            q = min(inc["size"], r["size"])
            px = r["price"]
            buyer = inc["who"] if inc["side"] == "bid" else r["who"]
            seller = r["who"] if inc["side"] == "bid" else inc["who"]
            if not self._exec(buyer, seller, px, q, inc["who"]): break
            inc["size"] -= q; r["size"] -= q
            if inc["side"] == "bid": inc["lock"] -= px * q
            else: inc["lock"] -= q
            if r["side"] == "bid": r["lock"] -= px * q
            else: r["lock"] -= q
            if r["size"] <= 1e-9:
                self._release(dict(who=r["who"], side=r["side"], lock=0.0)) if False else None
                opp.pop(0)
        # cancel marketable remainder the taker cannot afford (else crossed-book artifact)
        if inc["size"] > 1e-9 and opp:
            bp = opp[0]["price"]
            cross = (inc["price"] >= bp) if inc["side"] == "bid" else (inc["price"] <= bp)
            if cross:
                A2 = self.cb if inc["who"] == "cb" else self.tr[inc["who"]]
                if inc["side"] == "bid": A2["lock_u"] -= inc["lock"]; A2["usdc"] += inc["lock"]
                else: A2["lock_w"] -= inc["lock"]; A2["weth"] += inc["lock"]
                inc["size"] = 0.0; inc["lock"] = 0.0
        # clean residual lock of incoming if fully filled
        if inc["size"] <= 1e-9 and inc["lock"] > 1e-9:
            A = self.cb if inc["who"] == "cb" else self.tr[inc["who"]]
            if inc["side"] == "bid": A["lock_u"] -= inc["lock"]; A["usdc"] += inc["lock"]
            else: A["lock_w"] -= inc["lock"]; A["weth"] += inc["lock"]
            inc["lock"] = 0.0
        # remove filled incoming from book
        bk = self.bids if inc["side"] == "bid" else self.asks
        if inc["size"] <= 1e-9:
            self.bids = [o for o in self.bids if o["id"] != inc["id"]]
            self.asks = [o for o in self.asks if o["id"] != inc["id"]]
    def _exec(self, buyer, seller, price, size, taker):
        val = price * size; cm = val * self.comm_bps / 10000
        B = self.cb if buyer == "cb" else self.tr[buyer]
        S = self.cb if seller == "cb" else self.tr[seller]
        need_u = val + (cm if taker == buyer else 0)
        if B["usdc"] < need_u - 1e-9: return False
        B["usdc"] -= need_u; S["usdc"] += val
        if taker == seller:
            if S["usdc"] < cm:  # seller-taker pays commission too
                B["usdc"] += need_u; S["usdc"] -= val; return False
            S["usdc"] -= cm
        B["weth"] += size; S["weth"] -= size
        self.nav += cm; self.comms += cm; self.vol += val; self.trades += 1
        return True
    def take(self, who, side):
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("take")
        bb, ba = self.best()
        if side == "buy" and ba is not None:
            o = min(self.asks, key=lambda o: (o["price"], o["t"]))
            q = min(ACT_SIZE, o["size"])
            if A["usdc"] < ba * q * (1 + self.comm_bps / 10000) + g: return False
            A["usdc"] -= g; self.cgas += g
            inc = dict(id=self.oid, who=who, side="bid", price=ba * 1.2, size=q, t=self.t, lock=0.0)
            self.oid += 1; self._match(inc); return True
        if side == "sell" and bb is not None:
            o = max(self.bids, key=lambda o: (o["price"], -o["t"]))
            q = min(ACT_SIZE, o["size"])
            if A["weth"] < q or A["usdc"] < g: return False
            A["usdc"] -= g; self.cgas += g
            inc = dict(id=self.oid, who=who, side="ask", price=bb * 0.8, size=q, t=self.t, lock=0.0)
            A["weth"] -= q; A["lock_w"] += q; inc["lock"] = q
            self.oid += 1; self._match(inc)
            if inc["size"] > 1e-9:  # unfilled remainder -> resting
                self.asks.append(inc)
            else:
                if inc["lock"] > 1e-9: A["lock_w"] -= inc["lock"]; A["weth"] += inc["lock"]
            return True
        return False
    def cancel_oldest(self, who):
        own = [o for o in self.bids + self.asks if o["who"] == who]
        if not own: return False
        o = min(own, key=lambda o: o["t"])
        A = self.cb if who == "cb" else self.tr[who]
        g = self.gas_u("cancel")
        if A["usdc"] < g: return False
        A["usdc"] -= g; self.cgas += g
        self._release(o)
        self.bids = [x for x in self.bids if x["id"] != o["id"]]
        self.asks = [x for x in self.asks if x["id"] != o["id"]]
        return True
    def expire(self):
        for bk in ("bids", "asks"):
            keep = []
            for o in getattr(self, bk):
                if self.t - o["t"] > EXPIRY:
                    A = self.cb if o["who"] == "cb" else self.tr[o["who"]]
                    if o["side"] == "bid": A["lock_u"] -= o["lock"]; A["usdc"] += o["lock"]
                    else: A["lock_w"] -= o["lock"]; A["weth"] += o["lock"]
                else: keep.append(o)
            setattr(self, bk, keep)
    def step_ext(self):
        z = self.rg.normal()
        dt_y = DT_MIN / SPY_MIN
        self.px *= float(np.exp(-0.5 * SIGMA_ANN ** 2 * dt_y + SIGMA_ANN * np.sqrt(dt_y) * z))
        if self.rets or True:
            self.rets.append(np.log(self.px / getattr(self, "_pp", self.px)))
        self._pp = self.px
        y = self.nav * AAVE_APY * dt_y; self.nav += y; self.cumAave += y
        self.t += 1
    def vol20(self):
        r = np.array(self.rets[-20:]) if len(self.rets) >= 2 else np.array([0.0])
        return float(r.std() * 10000) if len(r) > 1 else 0.0
    def spread(self):
        bb, ba = self.best()
        if bb is None or ba is None: return 200.0
        return float((ba - bb) / self.px * 10000)

# ---------------- state builders ----------------
def trader_state(e, i):
    a = e.tr[i]; w = e.wealth(i)
    r1 = e.rets[-1] * 100 if len(e.rets) else 0.0
    r5 = float(np.sum(e.rets[-5:])) * 100 if len(e.rets) >= 5 else 0.0
    return np.array([(a["weth"] * e.px) / w - 0.5, a["usdc"] / w - 0.5, r1 * 10, r5 * 10,
                     e.vol20() / 100, min(e.spread(), 300) / 100, (w - 3192) / 3192,
                     (e.navpx() - 1.0) * 100, e.t / STEPS, (a["tok"] * e.navpx()) / w - 0.3], dtype=float)

def cb_state(e, w0):
    imb = sum(a["weth"] * e.px - a["usdc"] for a in e.tr) / 20000
    return np.array([e.vol20() / 100, min(e.spread(), 300) / 100, np.log1p(e.vol) / 5,
                     (e.nav - 1200) / 1200, e.gini() * 3, imb,
                     (e.cbwealth() - 4430) / 4430, e.t / STEPS], dtype=float)

# trader actions: 0 hold,1 bid-25,2 bid-5,3 ask+5,4 ask+25,5 buy-take,6 sell-take,7 cancel,8 hold2
def do_trader(e, i, a):
    p = e.px
    if a == 1: e.post(i, "bid", p * (1 - 25 / 1e4), ACT_SIZE)
    elif a == 2: e.post(i, "bid", p * (1 - 5 / 1e4), ACT_SIZE)
    elif a == 3: e.post(i, "ask", p * (1 + 5 / 1e4), ACT_SIZE)
    elif a == 4: e.post(i, "ask", p * (1 + 25 / 1e4), ACT_SIZE)
    elif a == 5: e.take(i, "buy")
    elif a == 6: e.take(i, "sell")
    elif a == 7: e.cancel_oldest(i)

# CB actions: 0..4 commission idx x 0..2 liquidity(none,provide,defend) = 15
def do_cb(e, a):
    ci, liq = divmod(a, 3)
    e.comm_bps = COMM_LEVELS[ci]; e.cb_comm_hist.append(COMM_LEVELS[ci])
    p = e.px
    if liq == 1:
        e.provided += 1
        for o in list(e.bids) + list(e.asks):
            if o["who"] == "cb":  # refresh quotes
                if o["side"] == "bid": e.cb["lock_u"] -= o["lock"]; e.cb["usdc"] += o["lock"]
                else: e.cb["lock_w"] -= o["lock"]; e.cb["weth"] += o["lock"]
        e.bids = [o for o in e.bids if o["who"] != "cb"]; e.asks = [o for o in e.asks if o["who"] != "cb"]
        e.post("cb", "bid", p * (1 - 15 / 1e4), 0.05); e.post("cb", "ask", p * (1 + 15 / 1e4), 0.05)
    elif liq == 2:
        r5 = float(np.sum(e.rets[-5:])) if len(e.rets) >= 5 else 0.0
        if r5 > 0.003: e.take("cb", "sell"); e.defends += 1
        elif r5 < -0.003: e.take("cb", "buy"); e.defends += 1

def run_episode(seed, traders, cb, eps_t, eps_c, train, random_cb=False, comm_fixed=None):
    e = Env(seed, comm_fixed=comm_fixed)
    W0 = e.world()
    S_t = [trader_state(e, i) for i in range(N_TR)]
    S_c = cb_state(e, W0)
    pw = [e.wealth(i) for i in range(N_TR)]
    prev_world = W0; prev_gini = e.gini()
    for t in range(STEPS):
        acts = [traders[i].act(S_t[i], eps_t) for i in range(N_TR)]
        for i, a in enumerate(acts): do_trader(e, i, a)
        if random_cb and comm_fixed is None:
            a_c = int(np.random.default_rng(seed + t).integers(15)); do_cb(e, a_c)
        elif comm_fixed is None:
            a_c = cb.act(S_c, eps_c); do_cb(e, a_c)
        else:
            a_c = -1
        e.expire(); e.step_ext(); e.spreads.append(e.spread()); e.vols.append(e.vol20())
        S2_t = [trader_state(e, i) for i in range(N_TR)]
        w2 = [e.wealth(i) for i in range(N_TR)]
        done = (t == STEPS - 1)
        if train:
            for i in range(N_TR):
                r = (w2[i] - pw[i]) / 10.0 - 0.02 * abs(e.tr[i]["weth"] * e.px - e.tr[i]["usdc"]) / 2000
                traders[i].push(S_t[i], acts[i], r, S2_t[i], done); traders[i].upd()
            if comm_fixed is None and not random_cb:
                wW = e.world(); g_now = e.gini()
                # CB reward: world growth (per $100) - vol penalty - inequality penalty
                rcb = (wW - prev_world) / 100.0 - 0.01 * e.vol20() - 5.0 * max(0.0, g_now - prev_gini)
                cb.push(S_c, a_c, rcb, cb_state(e, W0), done); cb.upd()
                prev_world = wW; prev_gini = g_now
        S_t = S2_t
        if comm_fixed is None and (random_cb or train): S_c = cb_state(e, W0)
        pw = w2
    cons = e.world() + e.cgas - (W0 + e.cumAave)
    totW = sum(a["weth"] + a["lock_w"] for a in e.tr) + e.cb["weth"] + e.cb["lock_w"]
    mtm = totW * (e.px - P0)
    edge = (e.world() - W0) - mtm - e.cumAave + e.cgas  # trading edge net of drift/yield/costs
    return dict(dW=e.world() - W0, dTr=sum(e.wealth(i) for i in range(N_TR)) - sum(pw) * 0 - (W0 - e.cbwealth()),
                vol=np.mean([]) if False else e.vol20(), volmean=float(np.mean(e.vols)) if e.vols else 0.0,
                comms=e.comms, volume=e.vol, trades=e.trades,
                gini=e.gini(), gas=e.cgas, aave=e.cumAave, cons=cons, spread=np.mean(e.spreads) if e.spreads else e.spread(),
                provided=e.provided, defends=e.defends, avgcomm=float(np.mean(e.cb_comm_hist)) if e.cb_comm_hist else e.comm_bps,
                w0=W0, w1=e.world(), cbw=e.cbwealth(), px0=P0, px1=e.px, mtm=mtm, edge=edge, totW=totW)

def train_scenario(name, cb_seed, use_cb, random_cb=False, comm_fixed=None):
    print("--- training %s ---" % name)
    # SAME trader population + SAME train price paths in all scenarios: only CB regime differs
    traders = [DQN(10, 9, 1000 + 17 * i + 11) for i in range(N_TR)]
    cb = DQN(8, 15, 5000 + cb_seed) if use_cb else None
    for ep in range(EP_TRAIN):
        eps = max(0.05, 1.0 - ep / EP_TRAIN)
        m = run_episode(100 + ep, traders, cb, eps, eps, True, random_cb, comm_fixed)
        print("ep%d eps=%.2f dWorld=%+.1f volEnd=%.0fbps trades=%d" % (ep, eps, m["dW"], m["vol"], m["trades"]))
    m = run_episode(EVAL_SEED, traders, cb, 0.0, 0.0, False, random_cb, comm_fixed)
    m["name"] = name
    return m

res = []
res.append(train_scenario("A NO_CB", 11, False, comm_fixed=100))
res.append(train_scenario("B DQN_CB", 22, True))
res.append(train_scenario("C RAND_CB", 33, False, random_cb=True))

print("=" * 78)
print("EVAL on SAME price path (seed %d), anchor $%.2f, 2400 steps=40h" % (EVAL_SEED, P0))
for m in res:
    print("%s\n  dWorld=%+.1f (MTM %+.1f + edge %+.1f + aave %.2f - gas %.2f) | volMean=%.0f volEnd=%.0fbps trades=%d vol$=%.0f" %
          (m["name"], m["dW"], m["mtm"], m["edge"], m["aave"], m["gas"], m["volmean"], m["vol"], m["trades"], m["volume"]))
    print("  spreadMean=%.0fbps comms->NAV=$%.1f gini=%.3f avgCBcomm=%.0fbps provide=%d defend=%d consErr=%.2e" %
          (m["spread"], m["comms"], m["gini"], m["avgcomm"], m["provided"], m["defends"], m["cons"] - m["mtm"]))
b = res[1]; a = res[0]
print("CB effect vs NO_CB: dWorld %+.1f | vol %.0f -> %.0f bps | gini %.3f -> %.3f" %
      (b["dW"] - a["dW"], a["vol"], b["vol"], a["gini"], b["gini"]))
with open(os.path.join(HERE, "results.json"), "w") as f:
    json.dump(dict(anchor=P0, eval_seed=EVAL_SEED,
                   scen=[{k: (float(v) if isinstance(v, (np.floating,)) else v) for k, v in m.items() if k != "name"} | {"name": m["name"]} for m in res]), f, indent=2)
print("saved results.json")
