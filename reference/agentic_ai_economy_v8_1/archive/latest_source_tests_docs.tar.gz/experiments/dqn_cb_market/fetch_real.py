#!/usr/bin/env python3
"""Fetch REAL Base blocks + REAL ETH/USD candles into local cache."""
import urllib.request, json, os, time
HERE = os.path.dirname(os.path.abspath(__file__))
RPCS = ["https://base.publicnode.com", "https://1rpc.io/base", "https://base.meowrpc.com"]
STEPS = 1200
WINDOWS = 5  # 4 train + 1 eval, consecutive non-overlapping, eval = most recent

def rpc_batch(calls):
    """calls: list of (method, params). Returns list of results, round-robin RPCs with retry."""
    out = [None] * len(calls)
    idx = list(range(len(calls)))
    for attempt in range(6):
        if not idx: break
        url = RPCS[attempt % len(RPCS)]
        # chunk into 60
        todo = idx[:]
        idx = []
        for c in range(0, len(todo), 60):
            chunk = todo[c:c + 60]
            payload = json.dumps([{"jsonrpc": "2.0", "id": i, "method": calls[i][0], "params": calls[i][1]} for i in chunk]).encode()
            try:
                req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
                res = json.loads(urllib.request.urlopen(req, timeout=60).read().decode())
                byid = {r["id"]: r for r in res}
                for i in chunk:
                    if "result" in byid.get(i, {}) and byid[i]["result"] is not None: out[i] = byid[i]["result"]
                    else: idx.append(i)
            except Exception as e:
                print("batch fail (%s): %s" % (url, str(e)[:100])); idx.extend(chunk)
            time.sleep(0.3)
    missing = [i for i in range(len(calls)) if out[i] is None]
    if missing: raise RuntimeError("missing %d block headers after retries" % len(missing))
    return out

def latest():
    for u in RPCS:
        try:
            p = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "eth_blockNumber", "params": []}).encode()
            r = urllib.request.Request(u, data=p, headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"})
            return int(json.loads(urllib.request.urlopen(r, timeout=20).read().decode())["result"], 16)
        except Exception: pass
    raise RuntimeError("no RPC")

tip = latest()
print("tip:", tip)
end = tip - 50
starts = [end - (WINDOWS - w) * STEPS for w in range(WINDOWS)]
print("windows:", starts)
calls = []
owners = []
for w, s in enumerate(starts):
    for b in range(s, s + STEPS):
        calls.append(("eth_getBlockByNumber", [hex(b), False])); owners.append((w, b))
res = rpc_batch(calls)
print("fetched %d headers" % len(res))
windows = []
for w, s in enumerate(starts):
    blks = []
    for i, (ow, ob) in enumerate(owners):
        if ow == w:
            r = res[i]
            blks.append(dict(n=int(r["number"], 16), ts=int(r["timestamp"], 16),
                             baseFee=int(r["baseFeePerGas"], 16), gasUsed=int(r["gasUsed"], 16)))
    blks.sort(key=lambda b: b["n"])
    ts = [b["ts"] for b in blks]
    print("w%d blocks %d..%d span %.1f min mediandt %.2fs medbasefee %.4f gwei" %
          (w, blks[0]["n"], blks[-1]["n"], (ts[-1] - ts[0]) / 60,
           float(sorted([b - a for a, b in zip(ts, ts[1:])])[len(ts) // 2]),
           float(sorted([b["baseFee"] for b in blks])[len(blks) // 2]) / 1e9))
    windows.append(blks)

req = urllib.request.Request("https://api.kraken.com/0/public/OHLC?pair=ETHUSD&interval=1",
                             headers={"User-Agent": "Mozilla/5.0"})
candles = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())["result"]["XETHZUSD"]
candles = [dict(t=c[0], c=float(c[4])) for c in candles]
print("candles: %d  %d..%d" % (len(candles), candles[0]["t"], candles[-1]["t"]))
with open(os.path.join(HERE, "real_blocks.json"), "w") as f:
    json.dump(dict(windows=windows, candles=candles, tip=tip), f)
print("saved real_blocks.json")
