# Legacy market laboratory

The original Base/DQN experiments are retained unchanged as a regression and market-mechanics laboratory. The new multi-market agent economy lives in `agent_economy/`; see the repository root `README.md`.

# Experiments — форк-тесты и DQN-экономика SYNERGY на Base Mainnet

| Папка | Содержание |
|---|---|
| `base_fork/` | Этап 1: статический форк-тест (входы/дивиденды/Aave/P2P) + агентная реплика. Вердикт: отрицательная сумма. |
| `dqn_cb_market/` | Этапы 2–4: DQN-трейдеры + DQN-ЦБ + SYNA + flash loans + LP. Вердикт: +12% за 80 мин. Полная документация: `dqn_cb_market/README.md`. |

Быстрый старт: см. раздел 4 в `dqn_cb_market/README.md` (нужны только Python 3.11 + numpy).
