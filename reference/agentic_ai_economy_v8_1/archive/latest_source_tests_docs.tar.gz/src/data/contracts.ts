export const coreTokenCode = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@aave/v3-core/contracts/interfaces/IPool.sol";
import "@aave/v3-core/contracts/interfaces/IPoolAddressesProvider.sol";

contract CoreToken is ERC20, ERC20Burnable, ReentrancyGuard, Pausable, Ownable {
    // ============ CONSTANTS ============
    uint256 public constant ENTRY_COST = 0.001 ether; // ~$1
    uint256 public constant NAV_PORTION_BPS = 8000; // 80%
    uint256 public constant DIVIDEND_PORTION_BPS = 2000; // 20%
    uint256 public constant MINT_PER_ENTRY = 1e18; // 1 token
    uint256 public constant BURN_RATE_BPS = 100; // 1%
    uint256 public constant REINVEST_RATE_BPS = 3000; // 30%
    uint256 public constant MAX_PARTICIPANTS = 10;
    uint256 public constant BASIS_POINTS = 10000;

    // ============ STATE ============
    uint256 public nav; // Net Asset Value in wei
    uint256 public totalDividends; // Accumulated dividends
    uint256 public totalSteps; // Block counter
    uint256 public lastHarvestBlock;
    
    address public p2pLending;
    address public p2pMarket;
    address public aavePool;
    
    // Participant tracking
    address[] public participants;
    mapping(address => uint256) public participantIndex;
    mapping(address => bool) public isParticipant;
    mapping(address => uint256) public dividendCredit;
    mapping(address => uint256) public totalInvested;
    
    // Round-robin
    uint256 public currentParticipantIndex;

    // ============ EVENTS ============
    event ParticipantEntered(address indexed participant, uint256 step, uint256 navAfter);
    event DividendsClaimed(address indexed participant, uint256 amount);
    event YieldHarvested(uint256 amount, uint256 newNav);
    event NavUpdated(uint256 oldNav, uint256 newNav, string reason);
    event P2PIncomeReceived(uint256 amount, string source);

    // ============ CONSTRUCTOR ============
    constructor(
        address _aavePool,
        address[] memory _initialParticipants
    ) ERC20("AntiPonzi P2P Token", "AP2P") {
        require(_initialParticipants.length <= MAX_PARTICIPANTS, "Too many participants");
        aavePool = _aavePool;
        
        for (uint256 i = 0; i < _initialParticipants.length; i++) {
            participants.push(_initialParticipants[i]);
            isParticipant[_initialParticipants[i]] = true;
            participantIndex[_initialParticipants[i]] = i;
        }
        
        // Seed NAV with initial deposit
        nav = 0.1 ether; // ~$100 seed
        lastHarvestBlock = block.number;
    }

    // ============ CORE FUNCTIONS ============
    
    /// @notice Enter the system - costs ENTRY_COST ETH
    function enter() external payable nonReentrant whenNotPaused {
        require(isParticipant[msg.sender], "Not a participant");
        require(msg.value == ENTRY_COST, "Wrong entry cost");
        
        totalSteps++;
        
        // Split payment
        uint256 navPortion = (msg.value * NAV_PORTION_BPS) / BASIS_POINTS;
        uint256 dividendPortion = msg.value - navPortion;
        
        // Add to NAV
        nav += navPortion;
        
        // Add to dividend pool
        totalDividends += dividendPortion;
        
        // Mint tokens
        _mint(msg.sender, MINT_PER_ENTRY);
        
        // Burn 1% of minted
        uint256 burnAmount = (MINT_PER_ENTRY * BURN_RATE_BPS) / BASIS_POINTS;
        _burn(msg.sender, burnAmount);
        
        // Update investment tracking
        totalInvested[msg.sender] += msg.value;
        
        // Round-robin: next participant
        currentParticipantIndex = (currentParticipantIndex + 1) % participants.length;
        
        // Deposit to Aave
        _depositToAave(navPortion);
        
        emit ParticipantEntered(msg.sender, totalSteps, nav);
    }

    /// @notice Claim accumulated dividends
    function claimDividends() external nonReentrant whenNotPaused {
        uint256 credit = dividendCredit[msg.sender];
        require(credit > 0, "No dividends to claim");
        
        uint256 reinvestAmount = (credit * REINVEST_RATE_BPS) / BASIS_POINTS;
        uint256 withdrawAmount = credit - reinvestAmount;
        
        // Reinvest portion goes back to NAV
        if (reinvestAmount > 0) {
            nav += reinvestAmount;
            _mint(msg.sender, (reinvestAmount * MINT_PER_ENTRY) / ENTRY_COST);
        }
        
        // Reset credit
        dividendCredit[msg.sender] = 0;
        
        // Send withdrawable portion
        if (withdrawAmount > 0) {
            (bool success, ) = msg.sender.call{value: withdrawAmount}("");
            require(success, "Transfer failed");
        }
        
        emit DividendsClaimed(msg.sender, credit);
    }

    /// @notice Harvest yield from Aave
    function harvestYield() external whenNotPaused {
        require(block.number > lastHarvestBlock + 100, "Too frequent");
        
        uint256 aTokenBalance = _getATokenBalance();
        uint256 deposited = _getDepositedAmount();
        
        if (aTokenBalance > deposited) {
            uint256 yieldAmount = aTokenBalance - deposited;
            
            // Withdraw yield from Aave
            IPool(aavePool).withdraw(
                address(this),
                yieldAmount,
                address(this)
            );
            
            nav += yieldAmount;
            lastHarvestBlock = block.number;
            
            emit YieldHarvested(yieldAmount, nav);
        }
    }

    /// @notice Receive P2P income (called by P2P contracts)
    function receiveP2PIncome(uint256 amount, string calldata source) external payable {
        require(
            msg.sender == p2pLending || msg.sender == p2pMarket,
            "Only P2P contracts"
        );
        nav += amount;
        emit P2PIncomeReceived(amount, source);
    }

    /// @notice Distribute dividends to participants proportionally
    function distributeDividends() external {
        uint256 amount = totalDividends;
        if (amount == 0) return;
        
        totalDividends = 0;
        
        uint256 totalSupply_ = totalSupply();
        if (totalSupply_ == 0) return;
        
        for (uint256 i = 0; i < participants.length; i++) {
            address p = participants[i];
            uint256 share = (amount * balanceOf(p)) / totalSupply_;
            dividendCredit[p] += share;
        }
    }

    // ============ VIEW FUNCTIONS ============
    
    function getTokenPrice() public view returns (uint256) {
        uint256 supply = totalSupply();
        if (supply == 0) return ENTRY_COST / MINT_PER_ENTRY;
        return (nav * 1e18) / supply;
    }
    
    function getParticipantCount() external view returns (uint256) {
        return participants.length;
    }
    
    function getParticipantInfo(address p) external view returns (
        uint256 tokenBalance,
        uint256 dividends,
        uint256 invested,
        uint256 portfolioValue
    ) {
        tokenBalance = balanceOf(p);
        dividends = dividendCredit[p];
        invested = totalInvested[p];
        portfolioValue = (tokenBalance * getTokenPrice()) / 1e18;
    }

    // ============ INTERNAL ============
    
    function _depositToAave(uint256 amount) internal {
        if (amount > 0 && aavePool != address(0)) {
            IPool(aavePool).supply(address(this), amount, address(this), 0);
        }
    }
    
    function _getATokenBalance() internal view returns (uint256) {
        // Implementation depends on Aave integration
        return 0; // Placeholder
    }
    
    function _getDepositedAmount() internal view returns (uint256) {
        return 0; // Placeholder
    }

    // ============ ADMIN ============
    
    function setP2PContracts(address _lending, address _market) external onlyOwner {
        p2pLending = _lending;
        p2pMarket = _market;
    }
    
    function pause() external onlyOwner {
        _pause();
    }
    
    function unpause() external onlyOwner {
        _unpause();
    }
    
    receive() external payable {}
}`;

export const p2pLendingCode = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

interface ICoreToken {
    function balanceOf(address) external view returns (uint256);
    function getTokenPrice() external view returns (uint256);
    function receiveP2PIncome(uint256 amount, string calldata source) external payable;
    function isParticipant(address) external view returns (bool);
}

contract P2PLending is ReentrancyGuard, Pausable, Ownable {
    // ============ STRUCTS ============
    struct Loan {
        uint256 id;
        address lender;
        address borrower;
        uint256 principal;
        uint256 interestRate; // APY in basis points
        uint256 duration; // in blocks
        uint256 startBlock;
        uint256 collateral; // CoreToken amount
        bool active;
        bool repaid;
    }
    
    struct Deposit {
        uint256 id;
        address depositor;
        address recipient;
        uint256 amount;
        uint256 interestRate; // APY in basis points
        uint256 startBlock;
        uint256 duration; // in blocks
        bool active;
        bool withdrawn;
    }

    // ============ CONSTANTS ============
    uint256 public constant MIN_COLLATERAL_RATIO_BPS = 15000; // 150%
    uint256 public constant LIQUIDATION_RATIO_BPS = 11000; // 110%
    uint256 public constant MIN_LOAN_AMOUNT = 0.01 ether;
    uint256 public constant MAX_LOAN_AMOUNT = 10 ether;
    uint256 public constant MIN_DURATION = 100; // blocks (~20 min)
    uint256 public constant MAX_DURATION = 2628000; // blocks (~1 year)
    uint256 public constant PROTOCOL_FEE_BPS = 50; // 0.5%

    // ============ STATE ============
    ICoreToken public coreToken;
    uint256 public nextLoanId;
    uint256 public nextDepositId;
    
    mapping(uint256 => Loan) public loans;
    mapping(uint256 => Deposit) public deposits;
    mapping(address => uint256[]) public lenderLoans;
    mapping(address => uint256[]) public borrowerLoans;
    mapping(address => uint256[]) public depositorDeposits;
    
    // Credit offers (open for anyone to accept)
    struct CreditOffer {
        uint256 id;
        address lender;
        uint256 amount;
        uint256 interestRate;
        uint256 duration;
        bool active;
    }
    mapping(uint256 => CreditOffer) public creditOffers;
    uint256 public nextOfferId;

    // ============ EVENTS ============
    event CreditOfferCreated(uint256 indexed offerId, address indexed lender, uint256 amount, uint256 rate);
    event LoanCreated(uint256 indexed loanId, address indexed lender, address indexed borrower, uint256 amount, uint256 rate);
    event LoanRepaid(uint256 indexed loanId, uint256 interestPaid);
    event LoanLiquidated(uint256 indexed loanId, address indexed liquidator);
    event DepositCreated(uint256 indexed depositId, address indexed depositor, address indexed recipient, uint256 amount);
    event DepositWithdrawn(uint256 indexed depositId, uint256 interestEarned);

    // ============ CONSTRUCTOR ============
    constructor(address _coreToken) {
        coreToken = ICoreToken(_coreToken);
    }

    // ============ CREDIT OFFERS ============
    
    /// @notice Create an open credit offer
    function createCreditOffer(
        uint256 amount,
        uint256 interestRate,
        uint256 duration
    ) external payable nonReentrant whenNotPaused {
        require(amount >= MIN_LOAN_AMOUNT && amount <= MAX_LOAN_AMOUNT, "Invalid amount");
        require(duration >= MIN_DURATION && duration <= MAX_DURATION, "Invalid duration");
        require(interestRate >= 100 && interestRate <= 10000, "Invalid rate"); // 1-100% APY
        require(msg.value == amount, "Send exact amount");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        
        creditOffers[nextOfferId] = CreditOffer({
            id: nextOfferId,
            lender: msg.sender,
            amount: amount,
            interestRate: interestRate,
            duration: duration,
            active: true
        });
        
        lenderLoans[msg.sender].push(nextOfferId);
        nextOfferId++;
        
        emit CreditOfferCreated(nextOfferId - 1, msg.sender, amount, interestRate);
    }

    /// @notice Accept a credit offer (borrower provides collateral)
    function acceptCreditOffer(uint256 offerId) external payable nonReentrant whenNotPaused {
        CreditOffer storage offer = creditOffers[offerId];
        require(offer.active, "Offer not active");
        require(offer.lender != msg.sender, "Cannot borrow from self");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        
        // Calculate required collateral
        uint256 tokenPrice = coreToken.getTokenPrice();
        uint256 requiredCollateral = (offer.amount * MIN_COLLATERAL_RATIO_BPS) / (tokenPrice * 10000 / 1e18);
        
        require(
            coreToken.balanceOf(msg.sender) >= requiredCollateral,
            "Insufficient collateral"
        );
        
        // Deactivate offer
        offer.active = false;
        
        // Create loan
        uint256 loanId = nextLoanId++;
        loans[loanId] = Loan({
            id: loanId,
            lender: offer.lender,
            borrower: msg.sender,
            principal: offer.amount,
            interestRate: offer.interestRate,
            duration: offer.duration,
            startBlock: block.number,
            collateral: requiredCollateral,
            active: true,
            repaid: false
        });
        
        borrowerLoans[msg.sender].push(loanId);
        
        // Transfer funds to borrower
        (bool success, ) = msg.sender.call{value: offer.amount}("");
        require(success, "Transfer failed");
        
        emit LoanCreated(loanId, offer.lender, msg.sender, offer.amount, offer.interestRate);
    }

    // ============ LOAN MANAGEMENT ============
    
    /// @notice Repay a loan with interest
    function repayLoan(uint256 loanId) external payable nonReentrant whenNotPaused {
        Loan storage loan = loans[loanId];
        require(loan.active, "Loan not active");
        require(msg.sender == loan.borrower, "Not the borrower");
        
        // Calculate interest
        uint256 blocksElapsed = block.number - loan.startBlock;
        uint256 interest = (loan.principal * loan.interestRate * blocksElapsed) / (365 days / 12 * 10000);
        uint256 totalDue = loan.principal + interest;
        
        require(msg.value >= totalDue, "Insufficient repayment");
        
        // Protocol fee
        uint256 fee = (interest * PROTOCOL_FEE_BPS) / 10000;
        uint256 lenderReceives = interest - fee;
        
        // Mark as repaid
        loan.active = false;
        loan.repaid = true;
        
        // Return principal + interest to lender
        (bool success1, ) = loan.lender.call{value: loan.principal + lenderReceives}("");
        require(success1, "Lender transfer failed");
        
        // Send fee to CoreToken NAV
        if (fee > 0) {
            coreToken.receiveP2PIncome{value: fee}(fee, "lending_fee");
        }
        
        // Refund excess
        if (msg.value > totalDue) {
            (bool success2, ) = msg.sender.call{value: msg.value - totalDue}("");
            require(success2, "Refund failed");
        }
        
        emit LoanRepaid(loanId, interest);
    }

    /// @notice Liquidate an undercollateralized loan
    function liquidateLoan(uint256 loanId) external nonReentrant whenNotPaused {
        Loan storage loan = loans[loanId];
        require(loan.active, "Loan not active");
        
        // Check collateralization
        uint256 tokenPrice = coreToken.getTokenPrice();
        uint256 collateralValue = (loan.collateral * tokenPrice) / 1e18;
        uint256 requiredValue = (loan.principal * LIQUIDATION_RATIO_BPS) / 10000;
        
        require(collateralValue < requiredValue, "Loan is sufficiently collateralized");
        
        // Liquidate
        loan.active = false;
        
        // Transfer collateral to liquidator as reward
        // In practice, this would involve token transfers
        // Simplified: liquidator gets a bonus
        
        emit LoanLiquidated(loanId, msg.sender);
    }

    // ============ DEPOSITS ============
    
    /// @notice Create a deposit with another participant
    function createDeposit(
        address recipient,
        uint256 interestRate,
        uint256 duration
    ) external payable nonReentrant whenNotPaused {
        require(msg.value > 0, "Zero amount");
        require(recipient != msg.sender, "Cannot deposit to self");
        require(coreToken.isParticipant(recipient), "Recipient not participant");
        require(interestRate >= 50 && interestRate <= 5000, "Invalid rate"); // 0.5-50% APY
        require(duration >= MIN_DURATION && duration <= MAX_DURATION, "Invalid duration");
        
        uint256 depositId = nextDepositId++;
        deposits[depositId] = Deposit({
            id: depositId,
            depositor: msg.sender,
            recipient: recipient,
            amount: msg.value,
            interestRate: interestRate,
            startBlock: block.number,
            duration: duration,
            active: true,
            withdrawn: false
        });
        
        depositorDeposits[msg.sender].push(depositId);
        
        // Transfer to recipient
        (bool success, ) = recipient.call{value: msg.value}("");
        require(success, "Transfer failed");
        
        emit DepositCreated(depositId, msg.sender, recipient, msg.value);
    }

    /// @notice Withdraw deposit with interest
    function withdrawDeposit(uint256 depositId) external nonReentrant whenNotPaused {
        Deposit storage deposit = deposits[depositId];
        require(deposit.active, "Deposit not active");
        require(msg.sender == deposit.depositor, "Not the depositor");
        require(block.number >= deposit.startBlock + deposit.duration, "Too early");
        
        // Calculate interest
        uint256 blocksElapsed = block.number - deposit.startBlock;
        uint256 interest = (deposit.amount * deposit.interestRate * blocksElapsed) / (365 days / 12 * 10000);
        
        deposit.active = false;
        deposit.withdrawn = true;
        
        // Request funds from recipient
        // In practice, recipient should have funds available
        (bool success, ) = msg.sender.call{value: deposit.amount + interest}("");
        require(success, "Withdrawal failed");
        
        emit DepositWithdrawn(depositId, interest);
    }

    // ============ VIEW FUNCTIONS ============
    
    function getLoanInfo(uint256 loanId) external view returns (
        address lender,
        address borrower,
        uint256 principal,
        uint256 interestRate,
        uint256 blocksRemaining,
        bool active
    ) {
        Loan storage loan = loans[loanId];
        uint256 endBlock = loan.startBlock + loan.duration;
        uint256 remaining = block.number < endBlock ? endBlock - block.number : 0;
        
        return (
            loan.lender,
            loan.borrower,
            loan.principal,
            loan.interestRate,
            remaining,
            loan.active
        );
    }
    
    function getActiveLoansCount() external view returns (uint256) {
        uint256 count = 0;
        for (uint256 i = 0; i < nextLoanId; i++) {
            if (loans[i].active) count++;
        }
        return count;
    }

    // ============ ADMIN ============
    
    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }
    
    receive() external payable {}
}`;

export const p2pMarketCode = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

interface ICoreTokenMarket {
    function getTokenPrice() external view returns (uint256);
    function receiveP2PIncome(uint256 amount, string calldata source) external payable;
    function isParticipant(address) external view returns (bool);
}

contract P2PMarket is ReentrancyGuard, Pausable, Ownable {
    // ============ STRUCTS ============
    struct Order {
        uint256 id;
        address maker;
        OrderSide side; // BUY or SELL
        uint256 ethAmount; // ETH amount
        uint256 pricePerEth; // Price in USD per ETH (from oracle or fixed)
        uint256 commissionBps; // Commission in basis points
        uint256 createdAt;
        bool active;
        bool filled;
    }
    
    struct Trade {
        uint256 id;
        uint256 orderId;
        address buyer;
        address seller;
        uint256 ethAmount;
        uint256 commission;
        uint256 timestamp;
    }
    
    enum OrderSide { BUY, SELL }

    // ============ CONSTANTS ============
    uint256 public constant MIN_ORDER_SIZE = 0.01 ether;
    uint256 public constant MAX_ORDER_SIZE = 100 ether;
    uint256 public constant DEFAULT_COMMISSION_BPS = 100; // 1%
    uint256 public constant MAX_COMMISSION_BPS = 500; // 5%
    uint256 public constant PRICE_DEVIATION_BPS = 500; // 5% max deviation from oracle

    // ============ STATE ============
    ICoreTokenMarket public coreToken;
    uint256 public nextOrderId;
    uint256 public nextTradeId;
    uint256 public totalVolume; // Total ETH traded
    uint256 public totalCommissions; // Total commissions collected
    
    mapping(uint256 => Order) public orders;
    mapping(uint256 => Trade) public trades;
    mapping(address => uint256[]) public makerOrders;
    mapping(address => uint256[]) public traderHistory;
    
    // Price oracle (simplified - in production use Chainlink)
    uint256 public ethPriceUSD; // Set by owner or oracle
    uint256 public lastPriceUpdate;

    // ============ EVENTS ============
    event OrderCreated(uint256 indexed orderId, address indexed maker, OrderSide side, uint256 amount, uint256 commission);
    event OrderFilled(uint256 indexed orderId, address indexed taker, uint256 amount, uint256 commission);
    event OrderCancelled(uint256 indexed orderId);
    event TradeExecuted(uint256 indexed tradeId, address buyer, address seller, uint256 amount, uint256 commission);
    event PriceUpdated(uint256 newPrice);

    // ============ CONSTRUCTOR ============
    constructor(address _coreToken, uint256 _initialEthPrice) {
        coreToken = ICoreTokenMarket(_coreToken);
        ethPriceUSD = _initialEthPrice; // e.g., 2000 * 1e6 (USDC decimals)
        lastPriceUpdate = block.timestamp;
    }

    // ============ ORDER FUNCTIONS ============
    
    /// @notice Create a SELL order (selling ETH for ETH + commission)
    function createSellOrder(
        uint256 ethAmount,
        uint256 commissionBps
    ) external payable nonReentrant whenNotPaused {
        require(msg.value == ethAmount, "Send exact ETH amount");
        require(ethAmount >= MIN_ORDER_SIZE && ethAmount <= MAX_ORDER_SIZE, "Invalid amount");
        require(commissionBps <= MAX_COMMISSION_BPS, "Commission too high");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        
        uint256 orderId = nextOrderId++;
        orders[orderId] = Order({
            id: orderId,
            maker: msg.sender,
            side: OrderSide.SELL,
            ethAmount: ethAmount,
            pricePerEth: ethPriceUSD,
            commissionBps: commissionBps,
            createdAt: block.timestamp,
            active: true,
            filled: false
        });
        
        makerOrders[msg.sender].push(orderId);
        
        emit OrderCreated(orderId, msg.sender, OrderSide.SELL, ethAmount, commissionBps);
    }

    /// @notice Create a BUY order
    function createBuyOrder(
        uint256 ethAmount,
        uint256 commissionBps
    ) external payable nonReentrant whenNotPaused {
        require(msg.value >= ethAmount, "Insufficient ETH");
        require(ethAmount >= MIN_ORDER_SIZE && ethAmount <= MAX_ORDER_SIZE, "Invalid amount");
        require(commissionBps <= MAX_COMMISSION_BPS, "Commission too high");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        
        uint256 orderId = nextOrderId++;
        orders[orderId] = Order({
            id: orderId,
            maker: msg.sender,
            side: OrderSide.BUY,
            ethAmount: ethAmount,
            pricePerEth: ethPriceUSD,
            commissionBps: commissionBps,
            createdAt: block.timestamp,
            active: true,
            filled: false
        });
        
        makerOrders[msg.sender].push(orderId);
        
        // Refund excess
        if (msg.value > ethAmount) {
            (bool refund, ) = msg.sender.call{value: msg.value - ethAmount}("");
            require(refund, "Refund failed");
        }
        
        emit OrderCreated(orderId, msg.sender, OrderSide.BUY, ethAmount, commissionBps);
    }

    /// @notice Fill a SELL order (buyer takes ETH, pays commission to NAV)
    function fillSellOrder(uint256 orderId) external payable nonReentrant whenNotPaused {
        Order storage order = orders[orderId];
        require(order.active, "Order not active");
        require(order.side == OrderSide.SELL, "Not a sell order");
        require(order.maker != msg.sender, "Cannot fill own order");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        
        // Calculate commission
        uint256 commission = (order.ethAmount * order.commissionBps) / 10000;
        uint256 totalCost = order.ethAmount + commission;
        
        require(msg.value >= totalCost, "Insufficient ETH");
        
        // Mark as filled
        order.active = false;
        order.filled = true;
        
        // Transfer ETH to seller
        (bool success1, ) = order.maker.call{value: order.ethAmount}("");
        require(success1, "Seller transfer failed");
        
        // Commission goes to CoreToken NAV
        if (commission > 0) {
            coreToken.receiveP2PIncome{value: commission}(commission, "market_commission");
        }
        
        // Record trade
        uint256 tradeId = nextTradeId++;
        trades[tradeId] = Trade({
            id: tradeId,
            orderId: orderId,
            buyer: msg.sender,
            seller: order.maker,
            ethAmount: order.ethAmount,
            commission: commission,
            timestamp: block.timestamp
        });
        
        traderHistory[msg.sender].push(tradeId);
        traderHistory[order.maker].push(tradeId);
        
        totalVolume += order.ethAmount;
        totalCommissions += commission;
        
        // Refund excess
        if (msg.value > totalCost) {
            (bool success2, ) = msg.sender.call{value: msg.value - totalCost}("");
            require(success2, "Refund failed");
        }
        
        emit OrderFilled(orderId, msg.sender, order.ethAmount, commission);
        emit TradeExecuted(tradeId, msg.sender, order.maker, order.ethAmount, commission);
    }

    /// @notice Fill a BUY order (seller provides ETH, buyer pays commission to NAV)
    function fillBuyOrder(uint256 orderId) external payable nonReentrant whenNotPaused {
        Order storage order = orders[orderId];
        require(order.active, "Order not active");
        require(order.side == OrderSide.BUY, "Not a buy order");
        require(order.maker != msg.sender, "Cannot fill own order");
        require(coreToken.isParticipant(msg.sender), "Not a participant");
        require(msg.value >= order.ethAmount, "Insufficient ETH");
        
        // Calculate commission (paid by buyer from their escrowed funds)
        uint256 commission = (order.ethAmount * order.commissionBps) / 10000;
        
        // Mark as filled
        order.active = false;
        order.filled = true;
        
        // Transfer ETH to seller (from order's escrowed funds)
        (bool success1, ) = msg.sender.call{value: order.ethAmount}("");
        require(success1, "Seller transfer failed");
        
        // Commission from escrow to NAV
        if (commission > 0) {
            coreToken.receiveP2PIncome{value: commission}(commission, "market_commission");
        }
        
        // Record trade
        uint256 tradeId = nextTradeId++;
        trades[tradeId] = Trade({
            id: tradeId,
            orderId: orderId,
            buyer: order.maker,
            seller: msg.sender,
            ethAmount: order.ethAmount,
            commission: commission,
            timestamp: block.timestamp
        });
        
        totalVolume += order.ethAmount;
        totalCommissions += commission;
        
        emit OrderFilled(orderId, msg.sender, order.ethAmount, commission);
        emit TradeExecuted(tradeId, order.maker, msg.sender, order.ethAmount, commission);
    }

    /// @notice Cancel an active order
    function cancelOrder(uint256 orderId) external nonReentrant {
        Order storage order = orders[orderId];
        require(order.active, "Order not active");
        require(order.maker == msg.sender, "Not the maker");
        
        order.active = false;
        
        // Return escrowed ETH
        if (order.ethAmount > 0) {
            (bool success, ) = msg.sender.call{value: order.ethAmount}("");
            require(success, "Return failed");
        }
        
        emit OrderCancelled(orderId);
    }

    // ============ VIEW FUNCTIONS ============
    
    function getActiveOrders() external view returns (Order[] memory) {
        uint256 count = 0;
        for (uint256 i = 0; i < nextOrderId; i++) {
            if (orders[i].active) count++;
        }
        
        Order[] memory active = new Order[](count);
        uint256 idx = 0;
        for (uint256 i = 0; i < nextOrderId; i++) {
            if (orders[i].active) {
                active[idx] = orders[i];
                idx++;
            }
        }
        return active;
    }
    
    function getOrderBook() external view returns (Order[] memory sells, Order[] memory buys) {
        uint256 sellCount = 0;
        uint256 buyCount = 0;
        
        for (uint256 i = 0; i < nextOrderId; i++) {
            if (!orders[i].active) continue;
            if (orders[i].side == OrderSide.SELL) sellCount++;
            else buyCount++;
        }
        
        sells = new Order[](sellCount);
        buys = new Order[](buyCount);
        
        uint256 sIdx = 0;
        uint256 bIdx = 0;
        for (uint256 i = 0; i < nextOrderId; i++) {
            if (!orders[i].active) continue;
            if (orders[i].side == OrderSide.SELL) {
                sells[sIdx] = orders[i];
                sIdx++;
            } else {
                buys[bIdx] = orders[i];
                bIdx++;
            }
        }
    }
    
    function getMarketStats() external view returns (
        uint256 _totalVolume,
        uint256 _totalCommissions,
        uint256 _activeOrders,
        uint256 _totalTrades
    ) {
        uint256 activeCount = 0;
        for (uint256 i = 0; i < nextOrderId; i++) {
            if (orders[i].active) activeCount++;
        }
        return (totalVolume, totalCommissions, activeCount, nextTradeId);
    }

    // ============ ADMIN ============
    
    function updateEthPrice(uint256 _newPrice) external onlyOwner {
        ethPriceUSD = _newPrice;
        lastPriceUpdate = block.timestamp;
        emit PriceUpdated(_newPrice);
    }
    
    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }
    
    receive() external payable {}
}`;

export const deployScript = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "hardhat/deploy";
import { CoreToken } from "../contracts/CoreToken.sol";
import { P2PLending } from "../contracts/P2PLending.sol";
import { P2PMarket } from "../contracts/P2PMarket.sol";

// Deploy script for Arbitrum One / Base
async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying with:", deployer.address);
    
    // === CONFIGURATION ===
    const AAVE_POOL_ARBITRUM = "0x794a61358D6845594F94dc1DB02A252b5b4814aD";
    const INITIAL_ETH_PRICE = 2000 * 1e6; // $2000 in USDC decimals
    
    // 10 participants
    const participants = [
        "0x1111...", "0x2222...", "0x3333...", "0x4444...", "0x5555...",
        "0x6666...", "0x7777...", "0x8888...", "0x9999...", "0xAAAA..."
    ];
    
    // === DEPLOY CORE TOKEN ===
    console.log("\\n1. Deploying CoreToken...");
    const CoreToken = await ethers.getContractFactory("CoreToken");
    const coreToken = await CoreToken.deploy(
        AAVE_POOL_ARBITRUM,
        participants
    );
    await coreToken.deployed();
    console.log("   CoreToken deployed at:", coreToken.address);
    
    // === DEPLOY P2P LENDING ===
    console.log("\\n2. Deploying P2PLending...");
    const P2PLending = await ethers.getContractFactory("P2PLending");
    const p2pLending = await P2PLending.deploy(coreToken.address);
    await p2pLending.deployed();
    console.log("   P2PLending deployed at:", p2pLending.address);
    
    // === DEPLOY P2P MARKET ===
    console.log("\\n3. Deploying P2PMarket...");
    const P2PMarket = await ethers.getContractFactory("P2PMarket");
    const p2pMarket = await P2PMarket.deploy(
        coreToken.address,
        INITIAL_ETH_PRICE
    );
    await p2pMarket.deployed();
    console.log("   P2PMarket deployed at:", p2pMarket.address);
    
    // === LINK CONTRACTS ===
    console.log("\\n4. Linking contracts...");
    await coreToken.setP2PContracts(
        p2pLending.address,
        p2pMarket.address
    );
    console.log("   Contracts linked successfully!");
    
    // === VERIFICATION ===
    console.log("\\n5. Verifying contracts on explorer...");
    // run: npx hardhat verify --network arbitrum <address> <constructor args>
    
    // === SUMMARY ===
    console.log("\\n✅ DEPLOYMENT COMPLETE!");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("CoreToken:  ", coreToken.address);
    console.log("P2PLending: ", p2pLending.address);
    console.log("P2PMarket:  ", p2pMarket.address);
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("Network: Arbitrum One");
    console.log("Participants: 10");
    console.log("Entry cost: 0.001 ETH (~$1)");
    console.log("Block time: 12 seconds");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });`;

export const testScript = `// Test suite for the Anti-Ponzi P2P System
import { expect } from "chai";
import { ethers } from "hardhat";

describe("Anti-Ponzi P2P System", function () {
    let coreToken: any;
    let p2pLending: any;
    let p2pMarket: any;
    let owner: any;
    let participants: any[];
    
    const ENTRY_COST = ethers.utils.parseEther("0.001");
    const AAVE_POOL = ethers.constants.AddressZero; // Mock for tests
    
    beforeEach(async function () {
        [owner, ...participants] = await ethers.getSigners();
        const participantAddresses = participants.slice(0, 10).map(p => p.address);
        
        // Deploy CoreToken
        const CoreToken = await ethers.getContractFactory("CoreToken");
        coreToken = await CoreToken.deploy(AAVE_POOL, participantAddresses);
        
        // Deploy P2PLending
        const P2PLending = await ethers.getContractFactory("P2PLending");
        p2pLending = await P2PLending.deploy(coreToken.address);
        
        // Deploy P2PMarket
        const P2PMarket = await ethers.getContractFactory("P2PMarket");
        p2pMarket = await P2PMarket.deploy(coreToken.address, 2000_000000);
        
        // Link contracts
        await coreToken.setP2PContracts(p2pLending.address, p2pMarket.address);
    });
    
    describe("CoreToken", function () {
        it("should initialize with correct participants", async function () {
            expect(await coreToken.getParticipantCount()).to.equal(10);
        });
        
        it("should allow participant to enter", async function () {
            await coreToken.connect(participants[0]).enter({ value: ENTRY_COST });
            expect(await coreToken.balanceOf(participants[0].address)).to.be.gt(0);
        });
        
        it("should reject non-participants", async function () {
            const [_, ..._, stranger] = await ethers.getSigners();
            await expect(
                coreToken.connect(stranger).enter({ value: ENTRY_COST })
            ).to.be.revertedWith("Not a participant");
        });
        
        it("should increase NAV on entry", async function () {
            const navBefore = await coreToken.nav();
            await coreToken.connect(participants[0]).enter({ value: ENTRY_COST });
            const navAfter = await coreToken.nav();
            expect(navAfter).to.be.gt(navBefore);
        });
        
        it("should burn 1% of minted tokens", async function () {
            await coreToken.connect(participants[0]).enter({ value: ENTRY_COST });
            const balance = await coreToken.balanceOf(participants[0].address);
            // 1 token minted, 1% burned = 0.99 tokens
            expect(balance).to.equal(ethers.utils.parseEther("0.99"));
        });
        
        it("should distribute dividends correctly", async function () {
            // Enter multiple times
            for (let i = 0; i < 5; i++) {
                await coreToken.connect(participants[0]).enter({ value: ENTRY_COST });
            }
            
            await coreToken.distributeDividends();
            const credit = await coreToken.dividendCredit(participants[0].address);
            expect(credit).to.be.gt(0);
        });
        
        it("should calculate token price correctly", async function () {
            const price = await coreToken.getTokenPrice();
            expect(price).to.be.gt(0);
        });
        
        it("should handle 2000 entries (full cycle)", async function () {
            for (let i = 0; i < 200; i++) {
                for (let j = 0; j < 10; j++) {
                    await coreToken.connect(participants[j]).enter({ value: ENTRY_COST });
                }
            }
            
            const steps = await coreToken.totalSteps();
            expect(steps).to.equal(2000);
            
            const nav = await coreToken.nav();
            console.log("NAV after 2000 steps:", ethers.utils.formatEther(nav));
            expect(nav).to.be.gt(ethers.utils.parseEther("1.6")); // At least entries
        });
    });
    
    describe("P2PLending", function () {
        beforeEach(async function () {
            // Give participants some tokens
            for (let i = 0; i < 5; i++) {
                await coreToken.connect(participants[i]).enter({ value: ENTRY_COST });
            }
        });
        
        it("should create credit offer", async function () {
            const amount = ethers.utils.parseEther("0.1");
            await p2pLending.connect(participants[0]).createCreditOffer(
                amount, 2000, 1000, { value: amount }
            );
            
            const offer = await p2pLending.creditOffers(0);
            expect(offer.active).to.be.true;
            expect(offer.lender).to.equal(participants[0].address);
        });
        
        it("should accept credit offer with collateral", async function () {
            const amount = ethers.utils.parseEther("0.01");
            await p2pLending.connect(participants[0]).createCreditOffer(
                amount, 2000, 1000, { value: amount }
            );
            
            // Borrower needs tokens for collateral
            for (let i = 0; i < 10; i++) {
                await coreToken.connect(participants[1]).enter({ value: ENTRY_COST });
            }
            
            await p2pLending.connect(participants[1]).acceptCreditOffer(0);
            
            const loan = await p2pLending.loans(0);
            expect(loan.active).to.be.true;
        });
        
        it("should repay loan with interest", async function () {
            const amount = ethers.utils.parseEther("0.01");
            await p2pLending.connect(participants[0]).createCreditOffer(
                amount, 2000, 1000, { value: amount }
            );
            
            for (let i = 0; i < 10; i++) {
                await coreToken.connect(participants[1]).enter({ value: ENTRY_COST });
            }
            
            await p2pLending.connect(participants[1]).acceptCreditOffer(0);
            
            // Mine some blocks
            await ethers.provider.send("evm_mine", []);
            await ethers.provider.send("evm_mine", []);
            
            // Repay
            const loan = await p2pLending.loans(0);
            const interest = amount.mul(2000).mul(10).div(365 * 24 * 300).div(10000);
            const totalDue = amount.add(interest);
            
            await p2pLending.connect(participants[1]).repayLoan(0, { 
                value: totalDue.mul(2) // Overpay to be safe
            });
            
            const loanAfter = await p2pLending.loans(0);
            expect(loanAfter.repaid).to.be.true;
        });
    });
    
    describe("P2PMarket", function () {
        beforeEach(async function () {
            for (let i = 0; i < 3; i++) {
                await coreToken.connect(participants[i]).enter({ value: ENTRY_COST });
            }
        });
        
        it("should create sell order", async function () {
            const amount = ethers.utils.parseEther("0.1");
            await p2pMarket.connect(participants[0]).createSellOrder(
                amount, 100, { value: amount }
            );
            
            const order = await p2pMarket.orders(0);
            expect(order.active).to.be.true;
            expect(order.side).to.equal(0); // SELL
        });
        
        it("should fill sell order and collect commission", async function () {
            const amount = ethers.utils.parseEther("0.1");
            const commission = amount.mul(100).div(10000); // 1%
            
            await p2pMarket.connect(participants[0]).createSellOrder(
                amount, 100, { value: amount }
            );
            
            const navBefore = await coreToken.nav();
            
            await p2pMarket.connect(participants[1]).fillSellOrder(0, { 
                value: amount.add(commission) 
            });
            
            const navAfter = await coreToken.nav();
            expect(navAfter).to.be.gt(navBefore); // NAV increased by commission
            
            const order = await p2pMarket.orders(0);
            expect(order.filled).to.be.true;
        });
        
        it("should cancel order and return funds", async function () {
            const amount = ethers.utils.parseEther("0.1");
            await p2pMarket.connect(participants[0]).createSellOrder(
                amount, 100, { value: amount }
            );
            
            const balanceBefore = await ethers.provider.getBalance(participants[0].address);
            await p2pMarket.connect(participants[0]).cancelOrder(0);
            const balanceAfter = await ethers.provider.getBalance(participants[0].address);
            
            // Balance should increase (minus gas)
            expect(balanceAfter).to.be.gt(balanceBefore.sub(ethers.utils.parseEther("0.01")));
        });
        
        it("should track market statistics", async function () {
            const amount = ethers.utils.parseEther("0.1");
            const commission = amount.mul(100).div(10000);
            
            await p2pMarket.connect(participants[0]).createSellOrder(
                amount, 100, { value: amount }
            );
            await p2pMarket.connect(participants[1]).fillSellOrder(0, { 
                value: amount.add(commission) 
            });
            
            const stats = await p2pMarket.getMarketStats();
            expect(stats._totalVolume).to.equal(amount);
            expect(stats._totalCommissions).to.equal(commission);
            expect(stats._totalTrades).to.equal(1);
        });
    });
    
    describe("Integration: Full 2000-step cycle with P2P", function () {
        it("should complete full cycle and show positive NAV growth", async function () {
            const navInitial = await coreToken.nav();
            
            // Simulate 2000 steps (200 per participant)
            for (let round = 0; round < 200; round++) {
                for (let p = 0; p < 10; p++) {
                    await coreToken.connect(participants[p]).enter({ value: ENTRY_COST });
                }
                
                // Every 10 rounds, create a P2P trade
                if (round % 10 === 0) {
                    const tradeAmount = ethers.utils.parseEther("0.05");
                    const commission = tradeAmount.mul(100).div(10000);
                    
                    await p2pMarket.connect(participants[0]).createSellOrder(
                        tradeAmount, 100, { value: tradeAmount }
                    );
                    await p2pMarket.connect(participants[1]).fillSellOrder(
                        round / 10, { value: tradeAmount.add(commission) }
                    );
                }
            }
            
            const navFinal = await coreToken.nav();
            const steps = await coreToken.totalSteps();
            const tokenPrice = await coreToken.getTokenPrice();
            
            console.log("=== FINAL RESULTS ===");
            console.log("Steps:", steps.toString());
            console.log("Initial NAV:", ethers.utils.formatEther(navInitial));
            console.log("Final NAV:", ethers.utils.formatEther(navFinal));
            console.log("Token Price:", ethers.utils.formatEther(tokenPrice));
            console.log("P2P Commissions:", ethers.utils.formatEther(await p2pMarket.totalCommissions()));
            
            expect(steps).to.equal(2000);
            expect(navFinal).to.be.gt(navInitial);
        });
    });
});`;
