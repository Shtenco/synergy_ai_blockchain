import { useState } from 'react';
import { 
  Shield, Code, Layers, Coins, ArrowRightLeft, Clock, 
  DollarSign, Users, Lock, Calendar, FileText, ChevronRight,
  Zap, TrendingUp, Database, AlertTriangle, CheckCircle,
  Copy, ChevronDown, ChevronUp, Activity
} from 'lucide-react';
import { coreTokenCode, p2pLendingCode, p2pMarketCode, deployScript, testScript } from './data/contracts';
import TestSection from './components/TestSection';

type Section = 'overview' | 'architecture' | 'coretoken' | 'p2plending' | 'p2pmarket' | 'params' | 'security' | 'deploy' | 'tests' | 'timeline' | 'simulation';

function App() {
  const [activeSection, setActiveSection] = useState<Section>('simulation');
  const [expandedCode, setExpandedCode] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const sections = [
    { id: 'simulation' as Section, label: '🧪 Симуляция', icon: Activity },
    { id: 'overview' as Section, label: 'Обзор', icon: FileText },
    { id: 'architecture' as Section, label: 'Архитектура', icon: Layers },
    { id: 'coretoken' as Section, label: 'CoreToken', icon: Coins },
    { id: 'p2plending' as Section, label: 'P2PLending', icon: ArrowRightLeft },
    { id: 'p2pmarket' as Section, label: 'P2PMarket', icon: TrendingUp },
    { id: 'params' as Section, label: 'Параметры', icon: Database },
    { id: 'security' as Section, label: 'Безопасность', icon: Lock },
    { id: 'deploy' as Section, label: 'Деплой', icon: Zap },
    { id: 'tests' as Section, label: 'Тесты', icon: CheckCircle },
    { id: 'timeline' as Section, label: 'Сроки', icon: Calendar },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-72 bg-gray-900 border-r border-gray-800 fixed h-full overflow-y-auto hidden lg:block">
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-sm">Anti-Ponzi P2P</h1>
              <p className="text-xs text-gray-400">ТЗ v1.0</p>
            </div>
          </div>
        </div>
        <nav className="p-4 space-y-1">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm transition-all ${
                activeSection === s.id
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800'
              }`}
            >
              <s.icon className="w-4 h-4" />
              {s.label}
              {activeSection === s.id && <ChevronRight className="w-4 h-4 ml-auto" />}
            </button>
          ))}
        </nav>
        <div className="p-4 mx-4 mb-4 rounded-lg bg-gray-800/50 border border-gray-700">
          <p className="text-xs text-gray-400 mb-2">Статус проекта</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></div>
            <span className="text-xs text-yellow-300">В разработке</span>
          </div>
          <p className="text-xs text-gray-500 mt-2">3 контракта • Solidity 0.8.20</p>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-gray-900 border-b border-gray-800 z-50 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <h1 className="font-bold text-sm">Anti-Ponzi P2P System</h1>
        </div>
        <div className="flex gap-1 mt-3 overflow-x-auto pb-1">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`px-3 py-1.5 rounded text-xs whitespace-nowrap ${
                activeSection === s.id
                  ? 'bg-purple-600/20 text-purple-300'
                  : 'text-gray-400'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 lg:ml-72 pt-28 lg:pt-0">
        <div className="max-w-5xl mx-auto p-6 lg:p-10">
          {activeSection === 'simulation' && <TestSection />}
          {activeSection === 'overview' && <OverviewSection />}
          {activeSection === 'architecture' && <ArchitectureSection />}
          {activeSection === 'coretoken' && <ContractSection 
            title="CoreToken" 
            subtitle="Основной токен системы"
            description="ERC20 токен с управлением NAV, минтингом, сжиганием, дивидендами и интеграцией с Aave V3"
            code={coreTokenCode}
            language="solidity"
            id="coretoken"
            expandedCode={expandedCode}
            setExpandedCode={setExpandedCode}
            copiedCode={copiedCode}
            copyToClipboard={copyToClipboard}
            features={[
              'ERC20 + ERC20Burnable',
              'NAV tracking (on-chain)',
              'Round-robin дивиденды',
              'Aave V3 yield harvesting',
              '1% burn на каждый вход',
              'ReentrancyGuard + Pausable'
            ]}
          />}
          {activeSection === 'p2plending' && <ContractSection 
            title="P2PLending" 
            subtitle="P2P кредитование и депозиты"
            description="Система P2P кредитов с залогом в токенах CoreToken и депозитов между участниками"
            code={p2pLendingCode}
            language="solidity"
            id="p2plending"
            expandedCode={expandedCode}
            setExpandedCode={setExpandedCode}
            copiedCode={copiedCode}
            copyToClipboard={copyToClipboard}
            features={[
              'Credit offers (открытые оферты)',
              'Collateralized loans (150% CR)',
              'Автоматическая ликвидация (110%)',
              'P2P депозиты (10-50% APY)',
              'Protocol fee 0.5% → NAV',
              'Rate limiting по блокам'
            ]}
          />}
          {activeSection === 'p2pmarket' && <ContractSection 
            title="P2PMarket" 
            subtitle="P2P рынок ETH"
            description="Order-book рынок для торговли ETH между участниками с комиссией, идущей в NAV системы"
            code={p2pMarketCode}
            language="solidity"
            id="p2pmarket"
            expandedCode={expandedCode}
            setExpandedCode={setExpandedCode}
            copiedCode={copiedCode}
            copyToClipboard={copyToClipboard}
            features={[
              'Order book (buy/sell)',
              'Комиссия 0.5-5% → NAV',
              'Мин. ордер 0.01 ETH',
              'Макс. ордер 100 ETH',
              'Price oracle integration',
              'Trade history tracking'
            ]}
          />}
          {activeSection === 'params' && <ParamsSection />}
          {activeSection === 'security' && <SecuritySection />}
          {activeSection === 'deploy' && <DeploySection 
            code={deployScript}
            expandedCode={expandedCode}
            setExpandedCode={setExpandedCode}
            copiedCode={copiedCode}
            copyToClipboard={copyToClipboard}
          />}
          {activeSection === 'tests' && <TestsSection 
            code={testScript}
            expandedCode={expandedCode}
            setExpandedCode={setExpandedCode}
            copiedCode={copiedCode}
            copyToClipboard={copyToClipboard}
          />}
          {activeSection === 'timeline' && <TimelineSection />}
        </div>
      </main>
    </div>
  );
}

// ============ SECTION COMPONENTS ============

function OverviewSection() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
          Техническое задание
        </h2>
        <p className="text-gray-400 text-lg">DeFi-система «Anti-Ponzi P2P Economy» — 3 смарт-контракта</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="px-3 py-1 bg-purple-600/20 text-purple-300 rounded-full text-xs border border-purple-500/30">Solidity 0.8.20</span>
          <span className="px-3 py-1 bg-blue-600/20 text-blue-300 rounded-full text-xs border border-blue-500/30">Arbitrum One</span>
          <span className="px-3 py-1 bg-green-600/20 text-green-300 rounded-full text-xs border border-green-500/30">Aave V3</span>
          <span className="px-3 py-1 bg-orange-600/20 text-orange-300 rounded-full text-xs border border-orange-500/30">12 сек/блок</span>
        </div>
      </div>

      {/* Key metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard icon={Users} label="Участники" value="10" color="purple" />
        <MetricCard icon={Clock} label="Шаг" value="12 сек" color="blue" />
        <MetricCard icon={DollarSign} label="Вход" value="$1" color="green" />
        <MetricCard icon={TrendingUp} label="Цель NAV" value="+18%" color="orange" />
      </div>

      {/* Goals */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-400" />
          Цели проекта
        </h3>
        <div className="space-y-3">
          {[
            'Замкнутая DeFi-экономика на базе Ethereum L2',
            'Положительная доходность из yield + P2P комиссий',
            'Блок-ориентированная архитектура (1 шаг = 1 блок)',
            'Полная прозрачность — все параметры on-chain',
            '3 взаимосвязанных смарт-контракта',
            'P2P кредитование, депозиты и рынок ETH'
          ].map((goal, i) => (
            <div key={i} className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 shrink-0" />
              <span className="text-gray-300">{goal}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Three contracts overview */}
      <div className="grid md:grid-cols-3 gap-4">
        <ContractCard
          number={1}
          title="CoreToken"
          description="ERC20 токен с NAV, минтингом, сжиганием, дивидендами и Aave yield"
          icon={Coins}
          color="purple"
        />
        <ContractCard
          number={2}
          title="P2PLending"
          description="P2P кредиты с залогом и депозиты между участниками"
          icon={ArrowRightLeft}
          color="blue"
        />
        <ContractCard
          number={3}
          title="P2PMarket"
          description="Order-book рынок ETH с комиссией в NAV"
          icon={TrendingUp}
          color="green"
        />
      </div>

      {/* Flow diagram */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Поток средств</h3>
        <div className="flex flex-col md:flex-row items-center gap-4 text-sm">
          <FlowNode label="Участник" sublabel="0.001 ETH" />
          <FlowArrow />
          <FlowNode label="CoreToken" sublabel="80% → NAV, 20% → Div" color="purple" />
          <FlowArrow />
          <div className="flex flex-col gap-2">
            <FlowNode label="Aave V3" sublabel="15% APY" color="green" />
            <FlowNode label="P2PLending" sublabel="20-50% APY" color="blue" />
            <FlowNode label="P2PMarket" sublabel="1-5% fee" color="orange" />
          </div>
        </div>
      </div>

      {/* Warning */}
      <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-xl p-4 flex gap-3">
        <AlertTriangle className="w-5 h-5 text-yellow-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-yellow-200 text-sm font-medium">Юридическая оговорка</p>
          <p className="text-yellow-300/70 text-xs mt-1">
            Данная система должна быть зарегистрирована как экспериментальное DeFi-приложение. 
            Выплата дивидендов может подпадать под регулирование ценных бумаг (SEC Howey Test). 
            Рекомендуется юридическая консультация перед деплоем.
          </p>
        </div>
      </div>
    </div>
  );
}

function ArchitectureSection() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Архитектура системы</h2>
        <p className="text-gray-400">Взаимодействие 3 смарт-контрактов</p>
      </div>

      {/* Architecture diagram */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6 overflow-x-auto">
        <h3 className="text-lg font-semibold mb-6">Диаграмма компонентов</h3>
        <div className="min-w-[600px]">
          <svg viewBox="0 0 800 500" className="w-full">
            {/* CoreToken */}
            <rect x="280" y="20" width="240" height="120" rx="12" fill="#1e1b4b" stroke="#7c3aed" strokeWidth="2"/>
            <text x="400" y="55" textAnchor="middle" fill="#c4b5fd" fontSize="16" fontWeight="bold">CoreToken</text>
            <text x="400" y="80" textAnchor="middle" fill="#9ca3af" fontSize="11">NAV • Mint • Burn • Dividends</text>
            <text x="400" y="100" textAnchor="middle" fill="#9ca3af" fontSize="11">Aave V3 Integration</text>
            <text x="400" y="120" textAnchor="middle" fill="#7c3aed" fontSize="10">ERC20 + ReentrancyGuard</text>
            
            {/* P2PLending */}
            <rect x="50" y="220" width="220" height="120" rx="12" fill="#0c1a3d" stroke="#3b82f6" strokeWidth="2"/>
            <text x="160" y="255" textAnchor="middle" fill="#93c5fd" fontSize="16" fontWeight="bold">P2PLending</text>
            <text x="160" y="280" textAnchor="middle" fill="#9ca3af" fontSize="11">Credits • Deposits</text>
            <text x="160" y="300" textAnchor="middle" fill="#9ca3af" fontSize="11">Collateral 150% • Liq. 110%</text>
            <text x="160" y="320" textAnchor="middle" fill="#3b82f6" fontSize="10">Fee 0.5% → NAV</text>
            
            {/* P2PMarket */}
            <rect x="530" y="220" width="220" height="120" rx="12" fill="#052e16" stroke="#22c55e" strokeWidth="2"/>
            <text x="640" y="255" textAnchor="middle" fill="#86efac" fontSize="16" fontWeight="bold">P2PMarket</text>
            <text x="640" y="280" textAnchor="middle" fill="#9ca3af" fontSize="11">Order Book • ETH Trading</text>
            <text x="640" y="300" textAnchor="middle" fill="#9ca3af" fontSize="11">Commission 1-5%</text>
            <text x="640" y="320" textAnchor="middle" fill="#22c55e" fontSize="10">Fee → NAV</text>
            
            {/* Participants */}
            <rect x="280" y="400" width="240" height="70" rx="12" fill="#1c1917" stroke="#78716c" strokeWidth="2"/>
            <text x="400" y="430" textAnchor="middle" fill="#d6d3d1" fontSize="14" fontWeight="bold">10 Participants</text>
            <text x="400" y="450" textAnchor="middle" fill="#9ca3af" fontSize="11">Round-robin • Equal access</text>
            
            {/* Aave */}
            <rect x="620" y="20" width="140" height="60" rx="8" fill="#1a1a2e" stroke="#a855f7" strokeWidth="1.5"/>
            <text x="690" y="48" textAnchor="middle" fill="#c084fc" fontSize="12" fontWeight="bold">Aave V3 Pool</text>
            <text x="690" y="65" textAnchor="middle" fill="#9ca3af" fontSize="10">15% APY</text>
            
            {/* Arrows */}
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#7c3aed"/>
              </marker>
              <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6"/>
              </marker>
              <marker id="arrowhead-green" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#22c55e"/>
              </marker>
            </defs>
            
            {/* CoreToken -> P2PLending */}
            <line x1="320" y1="140" x2="200" y2="220" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowhead-blue)"/>
            <text x="230" y="185" fill="#60a5fa" fontSize="9" transform="rotate(-30, 230, 185)">setP2PContracts()</text>
            
            {/* CoreToken -> P2PMarket */}
            <line x1="480" y1="140" x2="600" y2="220" stroke="#22c55e" strokeWidth="2" markerEnd="url(#arrowhead-green)"/>
            <text x="560" y="185" fill="#4ade80" fontSize="9" transform="rotate(30, 560, 185)">receiveP2PIncome()</text>
            
            {/* CoreToken -> Aave */}
            <line x1="520" y1="60" x2="620" y2="50" stroke="#a855f7" strokeWidth="1.5" strokeDasharray="5,5"/>
            <text x="570" y="42" fill="#a855f7" fontSize="9">supply()</text>
            
            {/* Participants -> CoreToken */}
            <line x1="400" y1="400" x2="400" y2="140" stroke="#78716c" strokeWidth="2" markerEnd="url(#arrowhead)"/>
            <text x="410" y="280" fill="#a8a29e" fontSize="9">enter() / claimDividends()</text>
            
            {/* Participants -> P2PLending */}
            <line x1="320" y1="400" x2="200" y2="340" stroke="#3b82f6" strokeWidth="1.5" markerEnd="url(#arrowhead-blue)"/>
            
            {/* Participants -> P2PMarket */}
            <line x1="480" y1="400" x2="600" y2="340" stroke="#22c55e" strokeWidth="1.5" markerEnd="url(#arrowhead-green)"/>
          </svg>
        </div>
      </div>

      {/* Data flow */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Поток данных на каждом шаге</h3>
        <div className="space-y-3">
          {[
            { step: '1', text: 'Участник вызывает enter() с 0.001 ETH', bg: 'bg-gray-600/20 text-gray-300 border-gray-500/30' },
            { step: '2', text: '80% → NAV, 20% → Dividend Pool', bg: 'bg-purple-600/20 text-purple-300 border-purple-500/30' },
            { step: '3', text: 'Минтится 1 токен, сжигается 1%', bg: 'bg-blue-600/20 text-blue-300 border-blue-500/30' },
            { step: '4', text: 'Средства депозитятся в Aave V3', bg: 'bg-green-600/20 text-green-300 border-green-500/30' },
            { step: '5', text: 'P2P контракты генерируют комиссии', bg: 'bg-orange-600/20 text-orange-300 border-orange-500/30' },
            { step: '6', text: 'Комиссии идут в NAV через receiveP2PIncome()', bg: 'bg-yellow-600/20 text-yellow-300 border-yellow-500/30' },
            { step: '7', text: 'Дивиденды распределяются пропорционально балансу', bg: 'bg-pink-600/20 text-pink-300 border-pink-500/30' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border ${item.bg}`}>
                {item.step}
              </div>
              <span className="text-gray-300 text-sm">{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Roles */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Роли и доступы</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-3 px-4 text-gray-400">Контракт</th>
                <th className="text-left py-3 px-4 text-gray-400">Роль</th>
                <th className="text-left py-3 px-4 text-gray-400">Доступ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              <tr>
                <td className="py-3 px-4 text-purple-300">CoreToken</td>
                <td className="py-3 px-4">Owner</td>
                <td className="py-3 px-4 text-gray-400">setP2PContracts, pause/unpause</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-purple-300">CoreToken</td>
                <td className="py-3 px-4">Participants</td>
                <td className="py-3 px-4 text-gray-400">enter, claimDividends, harvestYield</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-blue-300">P2PLending</td>
                <td className="py-3 px-4">Participants</td>
                <td className="py-3 px-4 text-gray-400">createCreditOffer, acceptCreditOffer, repayLoan</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-blue-300">P2PLending</td>
                <td className="py-3 px-4">Anyone</td>
                <td className="py-3 px-4 text-gray-400">liquidateLoan (if undercollateralized)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-green-300">P2PMarket</td>
                <td className="py-3 px-4">Participants</td>
                <td className="py-3 px-4 text-gray-400">createOrder, fillOrder, cancelOrder</td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-green-300">P2PMarket</td>
                <td className="py-3 px-4">Owner</td>
                <td className="py-3 px-4 text-gray-400">updateEthPrice, pause/unpause</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

interface ContractSectionProps {
  title: string;
  subtitle: string;
  description: string;
  code: string;
  language: string;
  id: string;
  expandedCode: string | null;
  setExpandedCode: (id: string | null) => void;
  copiedCode: string | null;
  copyToClipboard: (code: string, id: string) => void;
  features: string[];
}

function ContractSection({ title, subtitle, description, code, id, expandedCode, setExpandedCode, copiedCode, copyToClipboard, features }: ContractSectionProps) {
  const isExpanded = expandedCode === id;
  const lines = code.split('\n');
  const displayLines = isExpanded ? lines : lines.slice(0, 30);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">{title}</h2>
        <p className="text-gray-400 text-lg">{subtitle}</p>
        <p className="text-gray-500 mt-2">{description}</p>
      </div>

      {/* Features */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Ключевые возможности</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {features.map((f, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <Code className="w-4 h-4 text-purple-400" />
              <span className="text-gray-300">{f}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Code */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-800/50">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-3 text-sm text-gray-400">{title}.sol</span>
          </div>
          <button
            onClick={() => copyToClipboard(code, id)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-gray-700 hover:bg-gray-600 text-xs text-gray-300 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            {copiedCode === id ? 'Скопировано!' : 'Копировать'}
          </button>
        </div>
        <div className="overflow-x-auto">
          <pre className="p-4 text-xs leading-5">
            <code>
              {displayLines.map((line, i) => (
                <div key={i} className="flex">
                  <span className="w-10 text-right pr-4 text-gray-600 select-none">{i + 1}</span>
                  <span className={`${getLineColor(line)}`}>{highlightSolidity(line)}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>
        {lines.length > 30 && (
          <button
            onClick={() => setExpandedCode(isExpanded ? null : id)}
            className="w-full py-3 border-t border-gray-800 text-sm text-purple-400 hover:text-purple-300 flex items-center justify-center gap-2 transition-colors"
          >
            {isExpanded ? (
              <><ChevronUp className="w-4 h-4" /> Свернуть</>
            ) : (
              <><ChevronDown className="w-4 h-4" /> Показать весь код ({lines.length} строк)</>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function ParamsSection() {
  const params = [
    { name: 'ENTRY_COST', value: '0.001 ETH (~$1)', desc: 'Стоимость входа', group: 'Core' },
    { name: 'NAV_PORTION', value: '80%', desc: 'Доля в NAV', group: 'Core' },
    { name: 'DIVIDEND_PORTION', value: '20%', desc: 'Доля в дивиденды', group: 'Core' },
    { name: 'MINT_PER_ENTRY', value: '1 токен', desc: 'Минтинг за вход', group: 'Core' },
    { name: 'BURN_RATE', value: '1%', desc: 'Сжигание токенов', group: 'Core' },
    { name: 'REINVEST_RATE', value: '30%', desc: 'Реинвест дивидендов', group: 'Core' },
    { name: 'MAX_PARTICIPANTS', value: '10', desc: 'Макс. участников', group: 'Core' },
    { name: 'Aave APY', value: '15%', desc: 'Ожидаемый yield', group: 'Yield' },
    { name: 'CREDIT_RATE', value: '20-50% APY', desc: 'Ставка кредитов', group: 'P2P' },
    { name: 'DEPOSIT_RATE', value: '10-30% APY', desc: 'Ставка депозитов', group: 'P2P' },
    { name: 'MIN_COLLATERAL_RATIO', value: '150%', desc: 'Мин. обеспечение', group: 'P2P' },
    { name: 'LIQUIDATION_RATIO', value: '110%', desc: 'Порог ликвидации', group: 'P2P' },
    { name: 'PROTOCOL_FEE', value: '0.5%', desc: 'Комиссия протокола', group: 'P2P' },
    { name: 'MARKET_COMMISSION', value: '0.5-5%', desc: 'Комиссия рынка', group: 'Market' },
    { name: 'MIN_ORDER_SIZE', value: '0.01 ETH', desc: 'Мин. ордер', group: 'Market' },
    { name: 'MAX_ORDER_SIZE', value: '100 ETH', desc: 'Макс. ордер', group: 'Market' },
    { name: 'BLOCK_TIME', value: '12 сек', desc: 'Ethereum block', group: 'System' },
  ];

  const groups = [...new Set(params.map(p => p.group))];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Параметры системы</h2>
        <p className="text-gray-400">Сводная таблица всех конфигурируемых параметров</p>
      </div>

      {groups.map(group => (
        <div key={group} className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
          <div className="px-6 py-3 bg-gray-800/50 border-b border-gray-800">
            <h3 className="font-semibold text-sm text-gray-300">{group}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left py-3 px-6 text-gray-500 font-medium">Параметр</th>
                  <th className="text-left py-3 px-6 text-gray-500 font-medium">Значение</th>
                  <th className="text-left py-3 px-6 text-gray-500 font-medium">Описание</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/50">
                {params.filter(p => p.group === group).map((p, i) => (
                  <tr key={i} className="hover:bg-gray-800/30">
                    <td className="py-3 px-6 font-mono text-purple-300">{p.name}</td>
                    <td className="py-3 px-6 font-mono text-green-300">{p.value}</td>
                    <td className="py-3 px-6 text-gray-400">{p.desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {/* Network addresses */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Адреса контрактов (Arbitrum One)</h3>
        <div className="space-y-3">
          {[
            { name: 'Aave V3 Pool', address: '0x794a61358D6845594F94dc1DB02A252b5b4814aD' },
            { name: 'USDC', address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831' },
            { name: 'Chainlink ETH/USD', address: '0x639Fe6ab55C921f74e7fac1ee960C0B6293ba612' },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between bg-gray-800/50 rounded-lg px-4 py-3">
              <span className="text-gray-300 text-sm">{item.name}</span>
              <code className="text-xs text-gray-400 font-mono">{item.address}</code>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SecuritySection() {
  const threats = [
    { threat: 'Flash loan атака', defense: 'nonReentrant, проверка block.number', severity: 'high' },
    { threat: 'Oracle manipulation', defense: 'Chainlink + TWAP + deviation check', severity: 'high' },
    { threat: 'Front-running', defense: 'Commit-reveal для крупных сделок', severity: 'medium' },
    { threat: 'Reentrancy', defense: 'ReentrancyGuard на всех внешних вызовах', severity: 'high' },
    { threat: 'DOS gas bomb', defense: 'Лимиты на итерации, gas stipends', severity: 'medium' },
    { threat: 'Залоговый кризис', defense: 'Автоматическая ликвидация при 110%', severity: 'high' },
    { threat: 'Манипуляция ценой токена', defense: 'Цена = NAV/Supply, полностью on-chain', severity: 'low' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Безопасность</h2>
        <p className="text-gray-400">Векторы атак, защита и процесс аудита</p>
      </div>

      {/* Threats table */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="px-6 py-3 bg-gray-800/50 border-b border-gray-800">
          <h3 className="font-semibold text-sm text-gray-300">Векторы атак и защита</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-6 text-gray-500">Угроза</th>
                <th className="text-left py-3 px-6 text-gray-500">Защита</th>
                <th className="text-left py-3 px-6 text-gray-500">Severity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/50">
              {threats.map((t, i) => (
                <tr key={i} className="hover:bg-gray-800/30">
                  <td className="py-3 px-6 text-gray-300">{t.threat}</td>
                  <td className="py-3 px-6 text-gray-400">{t.defense}</td>
                  <td className="py-3 px-6">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      t.severity === 'high' ? 'bg-red-600/20 text-red-300' :
                      t.severity === 'medium' ? 'bg-yellow-600/20 text-yellow-300' :
                      'bg-green-600/20 text-green-300'
                    }`}>
                      {t.severity}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Audit process */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Процесс аудита</h3>
        <div className="space-y-4">
          {[
            { phase: 'Этап 1', title: 'Внутренний аудит', duration: '2 недели', desc: 'Ручной review + автоматические анализаторы (Slither, Mythril)' },
            { phase: 'Этап 2', title: 'Внешний аудит', duration: '4-6 недель', desc: 'Trail of Bits / OpenZeppelin / Spearbit' },
            { phase: 'Этап 3', title: 'Bug Bounty', duration: 'Постоянно', desc: 'Immunefi — max reward $50,000' },
          ].map((item, i) => (
            <div key={i} className="flex gap-4 items-start">
              <div className="w-20 shrink-0">
                <span className="text-xs text-purple-400 font-medium">{item.phase}</span>
                <p className="text-xs text-gray-500">{item.duration}</p>
              </div>
              <div className="flex-1 bg-gray-800/50 rounded-lg p-4">
                <p className="font-medium text-gray-200 text-sm">{item.title}</p>
                <p className="text-gray-400 text-xs mt-1">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Governance */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Governance & Time-lock</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <span className="text-sm font-medium text-gray-200">TimelockController</span>
            </div>
            <p className="text-xs text-gray-400">Все критические параметры изменяются с задержкой 48 часов</p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Lock className="w-4 h-4 text-green-400" />
              <span className="text-sm font-medium text-gray-200">Multi-sig Pause</span>
            </div>
            <p className="text-xs text-gray-400">Экстренная пауза: 3/5 Gnosis Safe</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DeploySection({ code, expandedCode, setExpandedCode, copiedCode, copyToClipboard }: { 
  code: string; expandedCode: string | null; setExpandedCode: (id: string | null) => void; 
  copiedCode: string | null; copyToClipboard: (code: string, id: string) => void 
}) {
  const isExpanded = expandedCode === 'deploy';
  const lines = code.split('\n');
  const displayLines = isExpanded ? lines : lines.slice(0, 25);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Деплой</h2>
        <p className="text-gray-400">Скрипт развёртывания на Arbitrum One / Base</p>
      </div>

      {/* Environments */}
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { env: 'Local', network: 'Hardhat Fork', purpose: 'Разработка', badge: 'bg-gray-600/20 text-gray-300' },
          { env: 'Testnet', network: 'Arbitrum Sepolia', purpose: 'Тестирование', badge: 'bg-yellow-600/20 text-yellow-300' },
          { env: 'Mainnet', network: 'Arbitrum One', purpose: 'Production', badge: 'bg-green-600/20 text-green-300' },
        ].map((e, i) => (
          <div key={i} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <span className={`text-xs px-2 py-0.5 rounded ${e.badge}`}>{e.env}</span>
            <p className="font-medium text-gray-200 mt-2 text-sm">{e.network}</p>
            <p className="text-xs text-gray-400 mt-1">{e.purpose}</p>
          </div>
        ))}
      </div>

      {/* Deploy script */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-800/50">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-3 text-sm text-gray-400">deploy.ts</span>
          </div>
          <button
            onClick={() => copyToClipboard(code, 'deploy')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-gray-700 hover:bg-gray-600 text-xs text-gray-300 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            {copiedCode === 'deploy' ? 'Скопировано!' : 'Копировать'}
          </button>
        </div>
        <div className="overflow-x-auto">
          <pre className="p-4 text-xs leading-5">
            <code>
              {displayLines.map((line, i) => (
                <div key={i} className="flex">
                  <span className="w-10 text-right pr-4 text-gray-600 select-none">{i + 1}</span>
                  <span className={`${getLineColor(line)}`}>{highlightSolidity(line)}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>
        {lines.length > 25 && (
          <button
            onClick={() => setExpandedCode(isExpanded ? null : 'deploy')}
            className="w-full py-3 border-t border-gray-800 text-sm text-purple-400 hover:text-purple-300 flex items-center justify-center gap-2 transition-colors"
          >
            {isExpanded ? (
              <><ChevronUp className="w-4 h-4" /> Свернуть</>
            ) : (
              <><ChevronDown className="w-4 h-4" /> Показать весь код ({lines.length} строк)</>
            )}
          </button>
        )}
      </div>

      {/* Deploy steps */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Порядок деплоя</h3>
        <div className="space-y-3">
          {[
            'Деплой CoreToken с Aave Pool address и списком участников',
            'Деплой P2PLending с адресом CoreToken',
            'Деплой P2PMarket с адресом CoreToken и начальной ценой ETH',
            'Вызов coreToken.setP2PContracts(lending, market)',
            'Верификация контрактов на block explorer',
            'Передача ownership на TimelockController',
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-xs text-purple-300 shrink-0">
                {i + 1}
              </div>
              <span className="text-gray-300 text-sm">{step}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TestsSection({ code, expandedCode, setExpandedCode, copiedCode, copyToClipboard }: { 
  code: string; expandedCode: string | null; setExpandedCode: (id: string | null) => void; 
  copiedCode: string | null; copyToClipboard: (code: string, id: string) => void 
}) {
  const isExpanded = expandedCode === 'tests';
  const lines = code.split('\n');
  const displayLines = isExpanded ? lines : lines.slice(0, 30);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Тестирование</h2>
        <p className="text-gray-400">Тест-кейсы с покрытием {'>'}95%</p>
      </div>

      {/* Test categories */}
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { category: 'Unit Tests', count: '45+', desc: 'CoreToken, P2PLending, P2PMarket' },
          { category: 'Integration', count: '12', desc: 'Межконтрактное взаимодействие' },
          { category: 'E2E Simulation', count: '3', desc: 'Полный цикл 2000 шагов' },
        ].map((t, i) => (
          <div key={i} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <p className="text-2xl font-bold text-purple-300">{t.count}</p>
            <p className="font-medium text-gray-200 text-sm mt-1">{t.category}</p>
            <p className="text-xs text-gray-400 mt-1">{t.desc}</p>
          </div>
        ))}
      </div>

      {/* Test cases */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Ключевые тест-кейсы</h3>
        <div className="space-y-2">
          {[
            { name: 'Инициализация с 10 участниками', status: 'pass' },
            { name: 'Вход участника (enter)', status: 'pass' },
            { name: 'Отказ не-участникам', status: 'pass' },
            { name: 'Рост NAV на каждом входе', status: 'pass' },
            { name: 'Сжигание 1% токенов', status: 'pass' },
            { name: 'Распределение дивидендов', status: 'pass' },
            { name: 'Расчёт цены токена', status: 'pass' },
            { name: '2000 входов (полный цикл)', status: 'pass' },
            { name: 'Создание кредитного оффера', status: 'pass' },
            { name: 'Принятие кредита с залогом', status: 'pass' },
            { name: 'Погашение кредита с процентами', status: 'pass' },
            { name: 'Ликвидация при 110% CR', status: 'pass' },
            { name: 'Создание sell ордера', status: 'pass' },
            { name: 'Исполнение ордера + комиссия', status: 'pass' },
            { name: 'Отмена ордера + возврат средств', status: 'pass' },
            { name: 'Интеграция: полный цикл с P2P', status: 'pass' },
          ].map((tc, i) => (
            <div key={i} className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-800/30">
              <span className="text-gray-300 text-sm">{tc.name}</span>
              <CheckCircle className="w-4 h-4 text-green-400" />
            </div>
          ))}
        </div>
      </div>

      {/* Test code */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-800/50">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-3 text-sm text-gray-400">AntiPonzi.test.ts</span>
          </div>
          <button
            onClick={() => copyToClipboard(code, 'tests')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-gray-700 hover:bg-gray-600 text-xs text-gray-300 transition-colors"
          >
            <Copy className="w-3.5 h-3.5" />
            {copiedCode === 'tests' ? 'Скопировано!' : 'Копировать'}
          </button>
        </div>
        <div className="overflow-x-auto">
          <pre className="p-4 text-xs leading-5">
            <code>
              {displayLines.map((line, i) => (
                <div key={i} className="flex">
                  <span className="w-10 text-right pr-4 text-gray-600 select-none">{i + 1}</span>
                  <span className={`${getLineColor(line)}`}>{highlightSolidity(line)}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>
        {lines.length > 30 && (
          <button
            onClick={() => setExpandedCode(isExpanded ? null : 'tests')}
            className="w-full py-3 border-t border-gray-800 text-sm text-purple-400 hover:text-purple-300 flex items-center justify-center gap-2 transition-colors"
          >
            {isExpanded ? (
              <><ChevronUp className="w-4 h-4" /> Свернуть</>
            ) : (
              <><ChevronDown className="w-4 h-4" /> Показать весь код ({lines.length} строк)</>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function TimelineSection() {
  const phases = [
    { phase: 'Проектирование', duration: '2 недели', status: 'done', desc: 'Архитектура, UML, спецификация' },
    { phase: 'CoreToken', duration: '3 недели', status: 'done', desc: 'Контракт + тесты' },
    { phase: 'P2PLending', duration: '2 недели', status: 'done', desc: 'Контракт + тесты' },
    { phase: 'P2PMarket', duration: '2 недели', status: 'done', desc: 'Контракт + тесты' },
    { phase: 'Интеграция', duration: '1 неделя', status: 'current', desc: 'Связка контрактов' },
    { phase: 'Внутренний аудит', duration: '2 недели', status: 'pending', desc: 'Исправление багов' },
    { phase: 'Внешний аудит', duration: '4-6 недель', status: 'pending', desc: 'Отчёт аудитора' },
    { phase: 'Testnet deploy', duration: '1 неделя', status: 'pending', desc: 'Публичное тестирование' },
    { phase: 'Mainnet deploy', duration: '1 неделя', status: 'pending', desc: 'Production' },
  ];

  const budget = [
    { item: 'Разработка (3 контракта)', cost: '$60,000 - $90,000', percent: 30 },
    { item: 'Внутренний аудит', cost: '$10,000', percent: 4 },
    { item: 'Внешний аудит', cost: '$80,000 - $150,000', percent: 40 },
    { item: 'Bug bounty (резерв)', cost: '$50,000', percent: 15 },
    { item: 'Frontend (dashboard)', cost: '$25,000 - $40,000', percent: 8 },
    { item: 'Деплой + gas reserves', cost: '$10,000', percent: 3 },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">Сроки и бюджет</h2>
        <p className="text-gray-400">План разработки и оценка стоимости</p>
      </div>

      {/* Timeline */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-6">Этапы разработки</h3>
        <div className="space-y-4">
          {phases.map((p, i) => (
            <div key={i} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-4 h-4 rounded-full border-2 ${
                  p.status === 'done' ? 'bg-green-500 border-green-400' :
                  p.status === 'current' ? 'bg-purple-500 border-purple-400 animate-pulse' :
                  'bg-gray-700 border-gray-600'
                }`}></div>
                {i < phases.length - 1 && (
                  <div className={`w-0.5 h-12 ${
                    p.status === 'done' ? 'bg-green-500/50' : 'bg-gray-700'
                  }`}></div>
                )}
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-200 text-sm">{p.phase}</span>
                  <span className="text-xs text-gray-500">{p.duration}</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-4 border-t border-gray-800 flex items-center justify-between">
          <span className="text-gray-300 font-medium">Итого</span>
          <span className="text-purple-300 font-bold">~18-20 недель</span>
        </div>
      </div>

      {/* Budget */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Бюджет</h3>
        <div className="space-y-4">
          {budget.map((b, i) => (
            <div key={i}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-gray-300">{b.item}</span>
                <span className="text-sm text-gray-400 font-mono">{b.cost}</span>
              </div>
              <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
                  style={{ width: `${b.percent}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-4 border-t border-gray-800">
          <div className="flex items-center justify-between">
            <span className="text-gray-300 font-medium">Итого</span>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              $235,000 - $350,000
            </span>
          </div>
        </div>
      </div>

      {/* Team */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold mb-4">Команда</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-gray-800/50 rounded-lg p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
              <Users className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-200">Product Owner</p>
              <p className="text-xs text-gray-500">Ожидает назначения</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
              <Users className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-200">Tech Lead</p>
              <p className="text-xs text-gray-500">Ожидает назначения</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
              <Users className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-200">Smart Contract Dev</p>
              <p className="text-xs text-gray-500">Ожидает назначения</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
              <Users className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-200">Security Auditor</p>
              <p className="text-xs text-gray-500">Ожидает назначения</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ HELPER COMPONENTS ============

function MetricCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: string }) {
  const colorClasses: Record<string, string> = {
    purple: 'from-purple-600/20 to-purple-800/10 border-purple-500/30 text-purple-300',
    blue: 'from-blue-600/20 to-blue-800/10 border-blue-500/30 text-blue-300',
    green: 'from-green-600/20 to-green-800/10 border-green-500/30 text-green-300',
    orange: 'from-orange-600/20 to-orange-800/10 border-orange-500/30 text-orange-300',
  };
  
  return (
    <div className={`bg-gradient-to-br ${colorClasses[color]} border rounded-xl p-4`}>
      <Icon className="w-5 h-5 mb-2 opacity-70" />
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs opacity-70 mt-1">{label}</p>
    </div>
  );
}

function ContractCard({ number, title, description, icon: Icon, color }: { number: number; title: string; description: string; icon: any; color: string }) {
  const borderColors: Record<string, string> = {
    purple: 'border-purple-500/30 hover:border-purple-500/60',
    blue: 'border-blue-500/30 hover:border-blue-500/60',
    green: 'border-green-500/30 hover:border-green-500/60',
  };
  const iconColors: Record<string, string> = {
    purple: 'text-purple-400',
    blue: 'text-blue-400',
    green: 'text-green-400',
  };
  
  return (
    <div className={`bg-gray-900 rounded-xl border ${borderColors[color]} p-5 transition-colors`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-gray-500 font-mono">#{number}</span>
        <Icon className={`w-5 h-5 ${iconColors[color]}`} />
      </div>
      <h4 className="font-semibold text-gray-200">{title}</h4>
      <p className="text-xs text-gray-400 mt-2">{description}</p>
    </div>
  );
}

function FlowNode({ label, sublabel, color = 'gray' }: { label: string; sublabel: string; color?: string }) {
  const bgColors: Record<string, string> = {
    gray: 'bg-gray-800 border-gray-600',
    purple: 'bg-purple-900/50 border-purple-500/50',
    blue: 'bg-blue-900/50 border-blue-500/50',
    green: 'bg-green-900/50 border-green-500/50',
    orange: 'bg-orange-900/50 border-orange-500/50',
  };
  
  return (
    <div className={`${bgColors[color]} border rounded-lg px-4 py-3 text-center min-w-[120px]`}>
      <p className="text-sm font-medium text-gray-200">{label}</p>
      <p className="text-xs text-gray-400 mt-0.5">{sublabel}</p>
    </div>
  );
}

function FlowArrow() {
  return (
    <div className="flex items-center text-gray-500">
      <div className="w-8 h-0.5 bg-gray-600"></div>
      <div className="w-0 h-0 border-t-4 border-b-4 border-l-6 border-t-transparent border-b-transparent border-l-gray-600"></div>
    </div>
  );
}

// ============ CODE HIGHLIGHTING HELPERS ============

function getLineColor(line: string): string {
  const trimmed = line.trim();
  if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) return 'text-green-600';
  if (trimmed.startsWith('import') || trimmed.startsWith('pragma')) return 'text-gray-500';
  if (trimmed.startsWith('contract') || trimmed.startsWith('interface') || trimmed.startsWith('library')) return 'text-yellow-300';
  if (trimmed.startsWith('function') || trimmed.startsWith('modifier')) return 'text-blue-300';
  if (trimmed.startsWith('event') || trimmed.startsWith('emit')) return 'text-pink-300';
  if (trimmed.startsWith('mapping') || trimmed.startsWith('struct') || trimmed.startsWith('enum')) return 'text-cyan-300';
  if (trimmed.startsWith('require') || trimmed.startsWith('revert')) return 'text-red-300';
  if (trimmed.startsWith('@')) return 'text-purple-400';
  return 'text-gray-300';
}

function highlightSolidity(line: string): JSX.Element {
  // Simple keyword highlighting
  const keywords = ['function', 'returns', 'return', 'require', 'mapping', 'struct', 'event', 'emit', 'modifier', 'public', 'private', 'external', 'internal', 'view', 'pure', 'payable', 'memory', 'storage', 'calldata', 'if', 'else', 'for', 'while', 'contract', 'interface', 'is', 'import', 'pragma', 'solidity', 'uint256', 'address', 'bool', 'string', 'true', 'false', 'this', 'msg', 'block'];
  
  // Just return the line as-is with the color class applied
  // Full syntax highlighting would require a more complex implementation
  return <span>{line || ' '}</span>;
}

export default App;
