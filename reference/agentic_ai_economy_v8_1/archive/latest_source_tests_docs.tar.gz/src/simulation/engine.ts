// Simulation engine for Anti-Ponzi P2P System
// Models 2000 steps with 10 participants

export interface SimulationConfig {
  participants: number;
  stepsPerParticipant: number;
  entryCost: number; // in USD
  navPortion: number; // 0-1
  dividendPortion: number; // 0-1
  mintPerEntry: number; // tokens
  burnRate: number; // 0-1
  reinvestRate: number; // 0-1
  aaveAPY: number; // 0-1
  stepDurationSec: number;
  p2pCreditEvery: number; // steps
  p2pCreditAmount: number;
  p2pCreditAPY: number;
  p2pDepositEvery: number;
  p2pDepositAmount: number;
  p2pDepositAPY: number;
  p2pMarketEvery: number;
  p2pMarketAmount: number;
  p2pMarketCommission: number;
  seedNAV: number;
}

export interface StepResult {
  step: number;
  time: string;
  participant: number;
  nav: number;
  supply: number;
  tokenPrice: number;
  totalDividends: number;
  totalInvested: number;
  p2pIncome: number;
  cumulativeP2P: number;
  portfolios: number[]; // portfolio value per participant
  balances: number[]; // token balance per participant
  dividends: number[]; // dividend credit per participant
  invested: number[]; // total invested per participant
  pnl: number[]; // profit/loss per participant
}

export interface FinalResult {
  totalSteps: number;
  totalTime: string;
  totalDurationHours: number;
  finalNAV: number;
  finalSupply: number;
  finalTokenPrice: number;
  totalInvested: number;
  totalDividendsDistributed: number;
  totalDividendsWithdrawn: number;
  totalDividendsReinvested: number;
  totalP2PIncome: number;
  totalAaveYield: number;
  totalBurned: number;
  participantResults: {
    id: number;
    totalInvested: number;
    finalPortfolio: number;
    dividendsWithdrawn: number;
    dividendsReinvested: number;
    totalValue: number;
    pnl: number;
    roi: number;
  }[];
  systemPnL: number;
  systemROI: number;
  isPositiveSum: boolean;
}

export const defaultConfig: SimulationConfig = {
  participants: 10,
  stepsPerParticipant: 200,
  entryCost: 1, // $1
  navPortion: 0.80,
  dividendPortion: 0.20,
  mintPerEntry: 1,
  burnRate: 0.01,
  reinvestRate: 0.30,
  aaveAPY: 0.15,
  stepDurationSec: 12,
  p2pCreditEvery: 100,
  p2pCreditAmount: 20,
  p2pCreditAPY: 0.20,
  p2pDepositEvery: 150,
  p2pDepositAmount: 15,
  p2pDepositAPY: 0.15,
  p2pMarketEvery: 75,
  p2pMarketAmount: 1000,
  p2pMarketCommission: 0.01,
  seedNAV: 100,
};

export function runSimulation(config: SimulationConfig): { steps: StepResult[]; final: FinalResult } {
  const {
    participants, stepsPerParticipant, entryCost, navPortion, dividendPortion,
    mintPerEntry, burnRate, reinvestRate, aaveAPY, stepDurationSec,
    p2pCreditEvery, p2pCreditAmount, p2pCreditAPY,
    p2pDepositEvery, p2pDepositAmount, p2pDepositAPY,
    p2pMarketEvery, p2pMarketAmount, p2pMarketCommission, seedNAV
  } = config;

  const totalSteps = participants * stepsPerParticipant;
  const secondsPerYear = 365.25 * 24 * 3600;

  let nav = seedNAV;
  let supply = 0;
  let totalDividendsPool = 0;
  let totalDividendsDistributed = 0;
  let totalDividendsWithdrawn = 0;
  let totalDividendsReinvested = 0;
  let totalP2PIncome = 0;
  let totalAaveYield = 0;
  let totalBurned = 0;
  let currentParticipantIdx = 0;

  const balances: number[] = new Array(participants).fill(0);
  const dividendCredits: number[] = new Array(participants).fill(0);
  const invested: number[] = new Array(participants).fill(0);
  const dividendsWithdrawn: number[] = new Array(participants).fill(0);
  const dividendsReinvested: number[] = new Array(participants).fill(0);

  const steps: StepResult[] = [];
  const stepInterval = Math.max(1, Math.floor(totalSteps / 200)); // Sample every N steps

  for (let step = 1; step <= totalSteps; step++) {
    const pIdx = currentParticipantIdx;
    currentParticipantIdx = (currentParticipantIdx + 1) % participants;

    // === ENTRY ===
    const navAdd = entryCost * navPortion;
    const divAdd = entryCost * dividendPortion;
    
    nav += navAdd;
    totalDividendsPool += divAdd;
    invested[pIdx] += entryCost;

    // === MINT + BURN ===
    const minted = mintPerEntry;
    const burned = minted * burnRate;
    const netMinted = minted - burned;
    
    supply += netMinted;
    totalBurned += burned;
    balances[pIdx] += netMinted;

    // === AAVE YIELD (continuous) ===
    const stepDurationYears = stepDurationSec / secondsPerYear;
    const aaveYield = nav * aaveAPY * stepDurationYears;
    nav += aaveYield;
    totalAaveYield += aaveYield;

    // === P2P CREDIT INCOME ===
    if (step % p2pCreditEvery === 0) {
      const blocksInPeriod = p2pCreditEvery * stepDurationSec;
      const periodYears = blocksInPeriod / secondsPerYear;
      const creditInterest = p2pCreditAmount * p2pCreditAPY * periodYears;
      nav += creditInterest;
      totalP2PIncome += creditInterest;
    }

    // === P2P DEPOSIT INCOME ===
    if (step % p2pDepositEvery === 0) {
      const blocksInPeriod = p2pDepositEvery * stepDurationSec;
      const periodYears = blocksInPeriod / secondsPerYear;
      const depositInterest = p2pDepositAmount * p2pDepositAPY * periodYears;
      nav += depositInterest;
      totalP2PIncome += depositInterest;
    }

    // === P2P MARKET COMMISSION ===
    if (step % p2pMarketEvery === 0) {
      const commission = p2pMarketAmount * p2pMarketCommission;
      nav += commission;
      totalP2PIncome += commission;
    }

    // === DIVIDEND DISTRIBUTION (every 10 steps) ===
    if (step % 10 === 0 && totalDividendsPool > 0 && supply > 0) {
      const toDistribute = totalDividendsPool;
      totalDividendsPool = 0;
      totalDividendsDistributed += toDistribute;

      for (let i = 0; i < participants; i++) {
        const share = (toDistribute * balances[i]) / supply;
        dividendCredits[i] += share;
      }
    }

    // === CLAIM DIVIDENDS (each participant claims when it's their turn, every full round) ===
    if (step % participants === 0) {
      const claimingIdx = (step / participants - 1) % participants;
      const credit = dividendCredits[claimingIdx];
      if (credit > 0) {
        const reinvest = credit * reinvestRate;
        const withdraw = credit - reinvest;
        
        // Reinvest
        if (reinvest > 0) {
          nav += reinvest;
          const tokensFromReinvest = (reinvest / entryCost) * mintPerEntry;
          const burnedReinvest = tokensFromReinvest * burnRate;
          supply += tokensFromReinvest - burnedReinvest;
          balances[claimingIdx] += tokensFromReinvest - burnedReinvest;
          totalBurned += burnedReinvest;
          totalDividendsReinvested += reinvest;
          dividendsReinvested[claimingIdx] += reinvest;
        }
        
        // Withdraw
        if (withdraw > 0) {
          nav -= withdraw; // Money leaves the system
          dividendsWithdrawn[claimingIdx] += withdraw;
          totalDividendsWithdrawn += withdraw;
        }
        
        dividendCredits[claimingIdx] = 0;
      }
    }

    // === TOKEN PRICE ===
    const tokenPrice = supply > 0 ? nav / supply : entryCost / mintPerEntry;

    // === RECORD STEP ===
    if (step % stepInterval === 0 || step === 1 || step === totalSteps) {
      const totalSeconds = step * stepDurationSec;
      const hours = Math.floor(totalSeconds / 3600);
      const mins = Math.floor((totalSeconds % 3600) / 60);
      const secs = totalSeconds % 60;
      const timeStr = `${hours}h ${mins}m ${secs}s`;

      const portfolios = balances.map((b) => b * tokenPrice);
      const pnl = balances.map((b, i) => {
        const portfolioValue = b * tokenPrice;
        return portfolioValue + dividendsWithdrawn[i] - invested[i];
      });

      steps.push({
        step,
        time: timeStr,
        participant: pIdx + 1,
        nav,
        supply,
        tokenPrice,
        totalDividends: totalDividendsDistributed,
        totalInvested: invested.reduce((a, b) => a + b, 0),
        p2pIncome: totalP2PIncome,
        cumulativeP2P: totalP2PIncome,
        portfolios,
        balances: [...balances],
        dividends: [...dividendCredits],
        invested: [...invested],
        pnl,
      });
    }
  }

  // === FINAL RESULTS ===
  const finalTokenPrice = supply > 0 ? nav / supply : 0;
  const totalSeconds = totalSteps * stepDurationSec;
  const totalHours = totalSeconds / 3600;
  const hours = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);

  const participantResults = Array.from({ length: participants }, (_, i) => {
    const finalPortfolio = balances[i] * finalTokenPrice;
    const totalValue = finalPortfolio + dividendsWithdrawn[i];
    const pnl = totalValue - invested[i];
    const roi = invested[i] > 0 ? (pnl / invested[i]) * 100 : 0;

    return {
      id: i + 1,
      totalInvested: invested[i],
      finalPortfolio,
      dividendsWithdrawn: dividendsWithdrawn[i],
      dividendsReinvested: dividendsReinvested[i],
      totalValue,
      pnl,
      roi,
    };
  });

  const totalInvestedAll = invested.reduce((a, b) => a + b, 0);
  const totalValueAll = participantResults.reduce((a, p) => a + p.totalValue, 0);
  const systemPnL = totalValueAll - totalInvestedAll;
  const systemROI = totalInvestedAll > 0 ? (systemPnL / totalInvestedAll) * 100 : 0;

  const final: FinalResult = {
    totalSteps,
    totalTime: `${hours}h ${mins}m`,
    totalDurationHours: totalHours,
    finalNAV: nav,
    finalSupply: supply,
    finalTokenPrice,
    totalInvested: totalInvestedAll,
    totalDividendsDistributed,
    totalDividendsWithdrawn,
    totalDividendsReinvested,
    totalP2PIncome,
    totalAaveYield,
    totalBurned,
    participantResults,
    systemPnL,
    systemROI,
    isPositiveSum: systemPnL > 0,
  };

  return { steps, final };
}
