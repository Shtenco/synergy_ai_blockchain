import { useState, useMemo } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, BarChart, Bar, Legend, ReferenceLine
} from 'recharts';
import {
  TrendingUp, TrendingDown, DollarSign, Users, Activity,
  AlertTriangle, CheckCircle, XCircle, Zap, ArrowUpRight, ArrowDownRight,
  Play, RotateCcw, Settings
} from 'lucide-react';
import { runSimulation, defaultConfig, SimulationConfig } from '../simulation/engine';

export default function TestSection() {
  const [config, setConfig] = useState<SimulationConfig>(defaultConfig);
  const [showSettings, setShowSettings] = useState(false);
  const [runCount, setRunCount] = useState(0);

  const { steps, final } = useMemo(() => {
    return runSimulation(config);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config, runCount]);

  const chartData = useMemo(() => {
    return steps.map(s => ({
      step: s.step,
      nav: Math.round(s.nav * 100) / 100,
      tokenPrice: Math.round(s.tokenPrice * 10000) / 10000,
      supply: Math.round(s.supply * 10) / 10,
      invested: Math.round(s.totalInvested * 100) / 100,
      p2p: Math.round(s.cumulativeP2P * 10000) / 10000,
    }));
  }, [steps]);

  const portfolioData = useMemo(() => {
    if (steps.length === 0) return [];
    const lastStep = steps[steps.length - 1];
    return lastStep.pnl.map((pnl, i) => ({
      name: `P${i + 1}`,
      pnl: Math.round(pnl * 100) / 100,
      roi: lastStep.invested[i] > 0 ? Math.round((pnl / lastStep.invested[i]) * 10000) / 100 : 0,
      invested: Math.round(lastStep.invested[i] * 100) / 100,
      portfolio: Math.round(lastStep.portfolios[i] * 100) / 100,
    }));
  }, [steps]);

  const navVsInvestedData = useMemo(() => {
    return steps
      .filter((_, i) => i % Math.max(1, Math.floor(steps.length / 100)) === 0 || i === steps.length - 1)
      .map(s => ({
        step: s.step,
        nav: Math.round(s.nav * 100) / 100,
        invested: Math.round(s.totalInvested * 100) / 100,
        gap: Math.round((s.nav - s.totalInvested) * 100) / 100,
      }));
  }, [steps]);

  const participantsInProfit = final.participantResults.filter(p => p.pnl > 0).length;
  const participantsInLoss = final.participantResults.filter(p => p.pnl < 0).length;
  const avgROI = final.participantResults.reduce((a, p) => a + p.roi, 0) / final.participantResults.length;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Activity className="w-8 h-8 text-purple-400" />
          Тестирование системы
        </h2>
        <p className="text-gray-400 text-lg">Полная симуляция 2000 шагов • 10 участников • 12 сек/блок</p>
      </div>

      {/* Controls */}
      <div className="flex gap-3 flex-wrap">
        <button
          onClick={() => setRunCount(c => c + 1)}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm font-medium transition-colors"
        >
          <Play className="w-4 h-4" />
          Пересчитать
        </button>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors border border-gray-700"
        >
          <Settings className="w-4 h-4" />
          Параметры
        </button>
        <button
          onClick={() => { setConfig(defaultConfig); setRunCount(c => c + 1); }}
          className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors border border-gray-700"
        >
          <RotateCcw className="w-4 h-4" />
          Сброс
        </button>
      </div>

      {/* Settings panel */}
      {showSettings && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold mb-4">Параметры симуляции</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <SettingInput label="Участники" value={config.participants} onChange={v => setConfig(c => ({...c, participants: v}))} />
            <SettingInput label="Шагов на участника" value={config.stepsPerParticipant} onChange={v => setConfig(c => ({...c, stepsPerParticipant: v}))} />
            <SettingInput label="Вход ($)" value={config.entryCost} onChange={v => setConfig(c => ({...c, entryCost: v}))} step={0.1} />
            <SettingInput label="NAV portion (%)" value={config.navPortion * 100} onChange={v => setConfig(c => ({...c, navPortion: v / 100}))} step={5} />
            <SettingInput label="Dividend portion (%)" value={config.dividendPortion * 100} onChange={v => setConfig(c => ({...c, dividendPortion: v / 100}))} step={5} />
            <SettingInput label="Burn rate (%)" value={config.burnRate * 100} onChange={v => setConfig(c => ({...c, burnRate: v / 100}))} step={0.5} />
            <SettingInput label="Reinvest (%)" value={config.reinvestRate * 100} onChange={v => setConfig(c => ({...c, reinvestRate: v / 100}))} step={5} />
            <SettingInput label="Aave APY (%)" value={config.aaveAPY * 100} onChange={v => setConfig(c => ({...c, aaveAPY: v / 100}))} step={1} />
            <SettingInput label="P2P Market комиссия (%)" value={config.p2pMarketCommission * 100} onChange={v => setConfig(c => ({...c, p2pMarketCommission: v / 100}))} step={0.5} />
            <SettingInput label="P2P Market сумма ($)" value={config.p2pMarketAmount} onChange={v => setConfig(c => ({...c, p2pMarketAmount: v}))} step={100} />
            <SettingInput label="P2P Market каждые N шагов" value={config.p2pMarketEvery} onChange={v => setConfig(c => ({...c, p2pMarketEvery: v}))} />
            <SettingInput label="Seed NAV ($)" value={config.seedNAV} onChange={v => setConfig(c => ({...c, seedNAV: v}))} />
          </div>
          <button
            onClick={() => setRunCount(c => c + 1)}
            className="mt-4 px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm font-medium transition-colors"
          >
            Применить и пересчитать
          </button>
        </div>
      )}

      {/* VERDICT */}
      <VerdictCard final={final} participantsInProfit={participantsInProfit} participantsInLoss={participantsInLoss} avgROI={avgROI} />

      {/* Key metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <MiniMetric label="Финальный NAV" value={`$${final.finalNAV.toFixed(2)}`} trend="up" />
        <MiniMetric label="Вложено всего" value={`$${final.totalInvested.toFixed(2)}`} />
        <MiniMetric label="Системный P&L" value={`$${final.systemPnL.toFixed(2)}`} trend={final.systemPnL > 0 ? 'up' : 'down'} />
        <MiniMetric label="P2P доход" value={`$${final.totalP2PIncome.toFixed(4)}`} />
        <MiniMetric label="Aave yield" value={`$${final.totalAaveYield.toFixed(6)}`} />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* NAV vs Invested */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
          <h3 className="text-sm font-semibold text-gray-300 mb-4">NAV vs Вложено (динамика)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={navVsInvestedData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="step" stroke="#6b7280" fontSize={10} />
              <YAxis stroke="#6b7280" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
              <Legend />
              <Area type="monotone" dataKey="nav" stroke="#a855f7" fill="#a855f7" fillOpacity={0.1} name="NAV ($)" />
              <Area type="monotone" dataKey="invested" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} name="Вложено ($)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Token Price */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
          <h3 className="text-sm font-semibold text-gray-300 mb-4">Цена токена (NAV / Supply)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="step" stroke="#6b7280" fontSize={10} />
              <YAxis stroke="#6b7280" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
              <Line type="monotone" dataKey="tokenPrice" stroke="#22c55e" strokeWidth={2} dot={false} name="Цена ($)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Supply */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
          <h3 className="text-sm font-semibold text-gray-300 mb-4">Supply токенов (дефляция)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="step" stroke="#6b7280" fontSize={10} />
              <YAxis stroke="#6b7280" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
              <Area type="monotone" dataKey="supply" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.1} name="Supply" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* P2P Income */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
          <h3 className="text-sm font-semibold text-gray-300 mb-4">Накопленный P2P доход</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="step" stroke="#6b7280" fontSize={10} />
              <YAxis stroke="#6b7280" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
              <Area type="monotone" dataKey="p2p" stroke="#ec4899" fill="#ec4899" fillOpacity={0.1} name="P2P ($)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Per-participant P&L */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <h3 className="text-sm font-semibold text-gray-300 mb-4">P&L по участникам (финальное)</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={portfolioData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#6b7280" fontSize={11} />
            <YAxis stroke="#6b7280" fontSize={10} />
            <Tooltip
              contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
              formatter={(value: number) => [`$${value.toFixed(2)}`, '']}
            />
            <ReferenceLine y={0} stroke="#6b7280" />
            <Bar dataKey="pnl" name="P&L ($)" fill="#a855f7" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Detailed participant table */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="px-6 py-3 bg-gray-800/50 border-b border-gray-800">
          <h3 className="font-semibold text-sm text-gray-300">Детальная таблица по участникам</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-3 px-4 text-gray-500">#</th>
                <th className="text-right py-3 px-4 text-gray-500">Вложено</th>
                <th className="text-right py-3 px-4 text-gray-500">Портфель</th>
                <th className="text-right py-3 px-4 text-gray-500">Div выведено</th>
                <th className="text-right py-3 px-4 text-gray-500">Div реинвест</th>
                <th className="text-right py-3 px-4 text-gray-500">Итого</th>
                <th className="text-right py-3 px-4 text-gray-500">P&L</th>
                <th className="text-right py-3 px-4 text-gray-500">ROI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/50">
              {final.participantResults.map(p => (
                <tr key={p.id} className="hover:bg-gray-800/30">
                  <td className="py-3 px-4 font-medium text-gray-300">P{p.id}</td>
                  <td className="py-3 px-4 text-right text-gray-400">${p.totalInvested.toFixed(2)}</td>
                  <td className="py-3 px-4 text-right text-gray-300">${p.finalPortfolio.toFixed(2)}</td>
                  <td className="py-3 px-4 text-right text-gray-400">${p.dividendsWithdrawn.toFixed(2)}</td>
                  <td className="py-3 px-4 text-right text-gray-400">${p.dividendsReinvested.toFixed(2)}</td>
                  <td className="py-3 px-4 text-right font-medium text-gray-200">${p.totalValue.toFixed(2)}</td>
                  <td className={`py-3 px-4 text-right font-bold ${p.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {p.pnl >= 0 ? '+' : ''}{p.pnl.toFixed(2)}
                  </td>
                  <td className={`py-3 px-4 text-right font-bold ${p.roi >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {p.roi >= 0 ? '+' : ''}{p.roi.toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-gray-700 bg-gray-800/30">
                <td className="py-3 px-4 font-bold text-gray-200">ИТОГО</td>
                <td className="py-3 px-4 text-right font-bold text-gray-200">${final.totalInvested.toFixed(2)}</td>
                <td className="py-3 px-4 text-right font-bold text-gray-200">
                  ${final.participantResults.reduce((a, p) => a + p.finalPortfolio, 0).toFixed(2)}
                </td>
                <td className="py-3 px-4 text-right font-bold text-gray-200">${final.totalDividendsWithdrawn.toFixed(2)}</td>
                <td className="py-3 px-4 text-right font-bold text-gray-200">${final.totalDividendsReinvested.toFixed(2)}</td>
                <td className="py-3 px-4 text-right font-bold text-gray-200">
                  ${final.participantResults.reduce((a, p) => a + p.totalValue, 0).toFixed(2)}
                </td>
                <td className={`py-3 px-4 text-right font-bold ${final.systemPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {final.systemPnL >= 0 ? '+' : ''}{final.systemPnL.toFixed(2)}
                </td>
                <td className={`py-3 px-4 text-right font-bold ${final.systemROI >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {final.systemROI >= 0 ? '+' : ''}{final.systemROI.toFixed(2)}%
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Decomposition */}
      <DecompositionCard final={final} />

      {/* Final analysis */}
      <AnalysisCard final={final} />
    </div>
  );
}

// ============ SUB-COMPONENTS ============

function VerdictCard({ final, participantsInProfit, participantsInLoss, avgROI }: {
  final: any; participantsInProfit: number; participantsInLoss: number; avgROI: number;
}) {
  const isPositive = final.systemPnL > 0;

  return (
    <div className={`rounded-xl border p-6 ${
      isPositive
        ? 'bg-green-900/20 border-green-700/50'
        : 'bg-red-900/20 border-red-700/50'
    }`}>
      <div className="flex items-start gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
          isPositive ? 'bg-green-600/30' : 'bg-red-600/30'
        }`}>
          {isPositive ? (
            <CheckCircle className="w-6 h-6 text-green-400" />
          ) : (
            <XCircle className="w-6 h-6 text-red-400" />
          )}
        </div>
        <div className="flex-1">
          <h3 className={`text-xl font-bold ${isPositive ? 'text-green-300' : 'text-red-300'}`}>
            {isPositive ? '✅ СИСТЕМА В ПЛЮСЕ — ПОЛОЖИТЕЛЬНАЯ СУММА' : '❌ СИСТЕМА В МИНУСЕ — ОТРИЦАТЕЛЬНАЯ СУММА'}
          </h3>
          <p className="text-gray-400 mt-2 text-sm">
            {isPositive
              ? `Все 10 участников суммарно заработали +$${final.systemPnL.toFixed(2)} (${final.systemROI >= 0 ? '+' : ''}${final.systemROI.toFixed(2)}% ROI)`
              : `Все 10 участников суммарно потеряли -$${Math.abs(final.systemPnL).toFixed(2)} (${final.systemROI.toFixed(2)}% ROI)`
            }
          </p>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div>
              <p className="text-xs text-gray-500">Системный P&L</p>
              <p className={`text-lg font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                {final.systemPnL >= 0 ? '+' : ''}${final.systemPnL.toFixed(2)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500">В плюсе / в минусе</p>
              <p className="text-lg font-bold">
                <span className="text-green-400">{participantsInProfit}</span>
                <span className="text-gray-500"> / </span>
                <span className="text-red-400">{participantsInLoss}</span>
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Средний ROI</p>
              <p className={`text-lg font-bold ${avgROI >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {avgROI >= 0 ? '+' : ''}{avgROI.toFixed(2)}%
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MiniMetric({ label, value, trend }: { label: string; value: string; trend?: 'up' | 'down' }) {
  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
      <p className="text-xs text-gray-500">{label}</p>
      <div className="flex items-center gap-1 mt-1">
        {trend === 'up' && <ArrowUpRight className="w-3 h-3 text-green-400" />}
        {trend === 'down' && <ArrowDownRight className="w-3 h-3 text-red-400" />}
        <p className={`text-lg font-bold ${
          trend === 'up' ? 'text-green-400' : trend === 'down' ? 'text-red-400' : 'text-gray-200'
        }`}>{value}</p>
      </div>
    </div>
  );
}

function DecompositionCard({ final }: { final: any }) {
  const sources = [
    { name: 'Seed NAV', amount: 100, color: '#6b7280' },
    { name: 'Входы (80% × 2000)', amount: final.totalInvested * 0.8, color: '#a855f7' },
    { name: 'Aave Yield', amount: final.totalAaveYield, color: '#22c55e' },
    { name: 'P2P Credit Interest', amount: final.totalP2PIncome * 0.001, color: '#3b82f6' },
    { name: 'P2P Market Commissions', amount: final.totalP2PIncome * 0.999, color: '#ec4899' },
  ];

  const total = sources.reduce((a, s) => a + s.amount, 0);
  const withdrawn = final.totalDividendsWithdrawn;

  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
      <h3 className="text-lg font-semibold mb-4">Декомпозиция: откуда пришёл NAV</h3>
      <div className="space-y-3">
        {sources.map((s, i) => (
          <div key={i}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }}></div>
                <span className="text-sm text-gray-300">{s.name}</span>
              </div>
              <span className="text-sm text-gray-400 font-mono">${s.amount.toFixed(4)}</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: `${Math.min(100, (s.amount / total) * 100)}%`, backgroundColor: s.color }}
              ></div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-gray-800 grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-gray-500">Итого NAV (gross)</p>
          <p className="text-lg font-bold text-purple-300">${total.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Выведено дивидендов</p>
          <p className="text-lg font-bold text-orange-300">-${withdrawn.toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
}

function AnalysisCard({ final }: { final: any }) {
  const totalIn = final.totalInvested;
  const totalOut = final.participantResults.reduce((a: number, p: { totalValue: number }) => a + p.totalValue, 0);
  const leak = totalIn - totalOut; // positive = money left in system

  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Zap className="w-5 h-5 text-yellow-400" />
        Ключевой анализ: почему система в {final.systemPnL > 0 ? 'плюсе' : 'минусе'}
      </h3>
      
      <div className="space-y-4">
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-300 font-medium mb-2">💰 Денежный баланс:</p>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-gray-500">Внесено</p>
              <p className="text-gray-200 font-mono">${totalIn.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-gray-500">Выведено</p>
              <p className="text-gray-200 font-mono">${totalOut.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-gray-500">Остаток в системе</p>
              <p className="text-purple-300 font-mono">${leak.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-300 font-medium mb-2">📊 Источники роста NAV:</p>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex justify-between">
              <span>• Seed NAV (начальный)</span>
              <span className="text-gray-300 font-mono">$100.00</span>
            </li>
            <li className="flex justify-between">
              <span>• Входы участников (80% × 2000)</span>
              <span className="text-gray-300 font-mono">$1,600.00</span>
            </li>
            <li className="flex justify-between">
              <span>• Aave yield (15% APY за 6.7 часов)</span>
              <span className="text-green-300 font-mono">${final.totalAaveYield.toFixed(6)}</span>
            </li>
            <li className="flex justify-between">
              <span>• P2P Market комиссии (1%)</span>
              <span className="text-pink-300 font-mono">${(final.totalP2PIncome * 0.999).toFixed(2)}</span>
            </li>
            <li className="flex justify-between">
              <span>• P2P Credit/Deposit interest</span>
              <span className="text-blue-300 font-mono">${(final.totalP2PIncome * 0.001).toFixed(6)}</span>
            </li>
          </ul>
        </div>

        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-300 font-medium mb-2">🔻 Утечки из системы:</p>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex justify-between">
              <span>• Дивиденды выведены (70% от 20%)</span>
              <span className="text-orange-300 font-mono">-${final.totalDividendsWithdrawn.toFixed(2)}</span>
            </li>
            <li className="flex justify-between">
              <span>• Дивиденды реинвестированы (30% от 20%)</span>
              <span className="text-gray-300 font-mono">$0 (остаются)</span>
            </li>
          </ul>
        </div>

        <div className={`rounded-lg p-4 border ${
          final.systemPnL > 0
            ? 'bg-green-900/10 border-green-700/30'
            : 'bg-red-900/10 border-red-700/30'
        }`}>
          <p className="text-sm text-gray-300 font-medium mb-2">
            {final.systemPnL > 0 ? '✅' : '❌'} Вердикт:
          </p>
          <p className="text-sm text-gray-400">
            {final.systemPnL > 0 ? (
              <>
                Система генерирует <span className="text-green-300 font-medium">положительную сумму</span>. 
                P2P Market комиссии (${(final.totalP2PIncome * 0.999).toFixed(2)}) + Seed NAV ($100) 
                превышают утечку дивидендов (${final.totalDividendsWithdrawn.toFixed(2)}). 
                Все участники в совокупности заработали <span className="text-green-300 font-medium">+${final.systemPnL.toFixed(2)}</span>.
              </>
            ) : (
              <>
                Система в <span className="text-red-300 font-medium">отрицательной сумме</span>. 
                Утечка дивидендов (${final.totalDividendsWithdrawn.toFixed(2)}) превышает 
                доход от P2P и yield (${(final.totalP2PIncome + final.totalAaveYield + 100).toFixed(2)}). 
                Участники суммарно потеряли <span className="text-red-300 font-medium">-${Math.abs(final.systemPnL).toFixed(2)}</span>.
                Для исправления: увеличьте P2P комиссии или уменьшите dividend portion.
              </>
            )}
          </p>
        </div>

        <div className="bg-yellow-900/10 border border-yellow-700/30 rounded-lg p-4">
          <div className="flex gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400 shrink-0" />
            <div>
              <p className="text-sm text-yellow-200 font-medium">Важное замечание</p>
              <p className="text-xs text-yellow-300/70 mt-1">
                При 12-секундных блоках Aave yield практически нулевой ($0.000001 за 6.7 часов). 
                Основной доход системы — это P2P Market комиссии. Если убрать P2P рынок, 
                система становится <span className="font-medium text-yellow-200">отрицательной суммой</span> — 
                классическая модель с перераспределением, где поздние участники теряют.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SettingInput({ label, value, onChange, step = 1 }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <div>
      <label className="text-xs text-gray-500 block mb-1">{label}</label>
      <input
        type="number"
        value={value}
        step={step}
        onChange={e => onChange(parseFloat(e.target.value) || 0)}
        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-200 focus:outline-none focus:border-purple-500"
      />
    </div>
  );
}
