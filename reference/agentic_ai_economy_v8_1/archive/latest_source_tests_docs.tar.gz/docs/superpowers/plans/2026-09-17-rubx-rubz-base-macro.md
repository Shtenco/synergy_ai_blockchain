# RUBX–RUBZ–Base Macro Economy Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and test the RUBX–RUBZ–USDC macroeconomic core with ten Base internal/external markets over 500 12-second blocks.

**Architecture:** A deterministic Python market simulator adds a protocol-owned monetary triangle, ten protocol-owned asset/USDC AMMs, stochastic external reference markets, heterogeneous market agents, a controller, strict real-asset HardNAV accounting, Founder fee attribution, and HODL benchmarking. It lives beside Agent Economy v2 and imports no new runtime dependencies.

**Tech Stack:** Python 3.11 standard library for the engine/tests; matplotlib only for report rendering.

**Spec:** `docs/superpowers/specs/2026-09-17-rubx-rubz-base-macro-design.md`

## Global Constraints

- Exactly 500 blocks in the reference run.
- Exactly 12 seconds per block.
- RUBX/RUBZ minting and internal transfers never increase HardNAV by themselves.
- Founder external revenue can only be attributed to outside taker activity or explicit external yield.
- No live keys or live order submission.
- Deterministic under a fixed random seed.

---

### Task 1: Market primitives and HardNAV
**Files:** Create `macro_economy/amm.py`, `macro_economy/assets.py`; Test `tests/test_macro_amm.py`.
- [ ] RED: tests for CPMM conservation, fee behavior and deterministic asset prices.
- [ ] GREEN: implement fixed-fee CPMM and asset specifications/reference prices.
- [ ] Verify focused tests.

### Task 2: RUBX–RUBZ–USDC monetary triangle
**Files:** Create `macro_economy/triangle.py`; Test `tests/test_macro_triangle.py`.
- [ ] RED: mint/internal rebalance cannot create HardNAV; RUBX liability and coverage are explicit.
- [ ] GREEN: implement triangle, treasury, issuance/burn controller and valuation.
- [ ] Verify focused tests.

### Task 3: Ten Base markets and agents
**Files:** Create `macro_economy/markets.py`, `macro_economy/agents.py`; Test `tests/test_macro_markets.py`.
- [ ] RED: external/internal prices, outside taker flows, agent portfolio valuation and bounded trades.
- [ ] GREEN: implement ten asset/USDC markets and heterogeneous agents.
- [ ] Verify focused tests.

### Task 4: 500-block orchestrator and accounting
**Files:** Create `macro_economy/engine.py`, `macro_economy/report.py`, `macro_economy/__init__.py`, `run_macro_economy.py`; Test `tests/test_macro_engine.py`.
- [ ] RED: exact 500 snapshots, 6000 seconds elapsed, deterministic run, HODL benchmark and no artificial mint alpha.
- [ ] GREEN: implement orchestration, fee attribution and report generation.
- [ ] Verify focused and full tests.

### Task 5: Reference run and visualization
**Files:** Create `reports/macro_500_blocks_seed77.json`, `reports/macro_500_blocks_seed77.csv`, `reports/macro_500_blocks_seed77.html`, `reports/charts/*.png`, `scripts/render_macro_report.py`; Modify `README.md`.
- [ ] Run the exact 500-block reference scenario.
- [ ] Render wealth, triangle, external assets, deviations, fees, coverage, drawdown, volume and attribution charts.
- [ ] Summarize whether wealth rose in absolute terms and relative to HODL.
- [ ] Run all tests and package verified release.
