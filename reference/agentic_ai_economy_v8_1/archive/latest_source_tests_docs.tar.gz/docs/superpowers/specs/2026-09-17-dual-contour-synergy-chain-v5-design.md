# SYNERGY Dual Contour v5 — Design

## Goal

Extend the verified v4 agent capital markets with a two-contour architecture:
1. a real-asset contour whose HardNAV is USDC + real Base inventory;
2. a non-redeemable SYNERGY CHAIN shadow contour where mirrored assets may be minted/burned to manage liquidity and controlled spreads.

## Hard accounting invariants

- Shadow minting and burning have zero direct HardNAV effect.
- Shadow fees remain synthetic and are not external profit.
- Real bridge inventory is counted exactly once in system wealth.
- External capital flow is separated from profit.
- Only real external execution PnL/fees or other external revenue can increase HardNAV beyond market marking.
- Shadow-to-external redemption is disabled.
- Production policy synthetic leverage is capped by marked real bridge inventory.

## SYNERGY CHAIN

The v5 runtime models a deterministic Base/OP-Stack-style internal chain with its own chain id, 12-second block clock, linked block hashes and ordered transactions. It mirrors 13 assets: RUBX, RUBZ, USDC and the ten Base assets from v4. This is a chain simulation layer, not a claim that an OP Stack node has been deployed.

## Inventory bridge

The bridge is a warehouse rather than a per-trade teleport pipe. A configurable portion of protocol-owned real Base AMM inventory is moved proportionally into bridge custody, preserving aggregate real wealth. Shadow supply can scale against this inventory subject to a leverage ceiling, but cannot redeem through the bridge.

## AI market maker

The market maker has two independent controls.

### Internal spread controller

It chooses an adaptive target spread based on volatility, inventory skew, recent reward and external momentum. Positive momentum lowers the internal target spread and induces mint/sell pressure; negative momentum raises support and induces buyback/burn. Exact CPMM trade sizing moves each shadow pool to the target rather than using a fixed notional.

### External delta controller

Real bridge inventory is separately risk-managed. Strength reduces target real-asset delta; weakness/drawdown restores inventory. This is the only part of the v5 MM that can affect external HardNAV through actual real-asset execution.

## Reference evaluation

Every release must run:
- 500 blocks × 12 seconds;
- v4 matched baseline;
- v5 with shadow MM but external delta disabled;
- full v5;
- 20 deterministic seeds;
- 5× volatility stress;
- legacy DQN invariant suite.

Primary success criteria are lower capital-adjusted drawdown and block-to-block NAV volatility without counting synthetic issuance as profit. Alpha may fall because risk reduction is allowed to have an opportunity cost.
