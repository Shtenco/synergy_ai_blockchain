# SYNERGY Agent Macro Economy v3 — Design

## Goal

Make RUBX–RUBZ–USDC the monetary/capital core of the autonomous agent economy and connect it to ten major liquid Base Mainnet assets through protocol-owned internal markets and external reference markets. Evaluate a deterministic 500-block / 12-second simulation without treating minting or internal transfers as profit.

## Monetary triangle

- **USDC** is settlement cash and the unit of account.
- **RUBX** is the low-risk reserve/debt instrument, analogous to a treasury instrument. It targets $1, has senior redemption/coupon semantics, and creates a real protocol liability at face value.
- **RUBZ** is the residual equity/risk instrument, analogous to an equity index. It is not a hard liability; its economic fair value is derived from residual protocol equity after the RUBX senior claim.
- Three protocol-owned CPMM pools provide RUBX/USDC, RUBZ/USDC and RUBX/RUBZ price discovery.
- Mint/burn, internal swaps, treasury-to-pool transfers and triangle arbitrage do not count as external profit.

## Real assets and external markets

Ten Base assets are modeled with external reference markets and protocol-owned internal asset/USDC pools:
WETH, cbBTC, VVV, VIRTUAL, AERO, cbETH, USDe, cbXRP, TOSHI, MORPHO.

External prices follow a deterministic correlated stochastic path seeded from recent public market observations. The 500-block test is a scenario simulation, not a historical replay or a prediction.

## Economic actors and flows

- Outside takers trade against protocol-owned internal markets and can transfer real marked value into or out of the system.
- Internal agents hold USDC and external assets, trade, and rebalance according to heterogeneous momentum/mean-reversion/risk profiles.
- A controller keeps RUBX close to its $1 monetary target, uses only available reserves, and treats RUBZ as residual risk capital.
- Founder Treasury receives only a bounded share of fees attributable to external taker activity; internal agent fees are not counted as external founder revenue.

## Accounting

Primary metrics:
- Protocol HardNAV = USDC + external Base assets at external marks across treasury and protocol-owned pools; RUBX/RUBZ excluded.
- RUBX senior liability = face-value supply outstanding.
- Protocol residual equity = HardNAV - RUBX senior liability.
- RUBX coverage ratio = HardNAV / RUBX liability.
- Gross TVL = marked value of all internal pools, including RUBX/RUBZ at market marks.
- Agent wealth = agent cash + external assets at external marks + RUBX/RUBZ positions.
- System wealth = protocol HardNAV + agent wealth + Founder Treasury (avoiding double count).
- HODL benchmark = value of initial real-asset inventory at current external marks with no active market making.
- Economic alpha = actual wealth minus HODL benchmark; minting cannot increase it.

## Safety and validity rules

- No live private keys or live trading.
- No guaranteed-profit assumptions.
- External fees, slippage, adverse selection and stochastic market moves are explicit.
- The test must include drawdown and can finish below its opening or benchmark wealth.
- The run uses exactly 500 blocks and 12 seconds per block.

## Deliverables

- `macro_economy/` Python standard-library simulation package.
- `run_macro_economy.py` CLI.
- Unit and integration tests.
- JSON/CSV 500-block report.
- Multiple PNG charts and a self-contained HTML report.
- Updated README and reproducibility commands.
