# SYNERGY Agent Capital Markets v4 Design

## Goal
Extend the verified v3 RUBX-RUBZ-USDC macro economy into an endogenous agent capital market where autonomous agents allocate across cash, RUBX, RUBZ and ten Base assets; agent companies issue equity and bonds; portfolios secure loans; and a market-driven SYNERGY yield curve prices internal credit without creating external income from internal transfers.

## Economic invariants
- System real wealth counts only USDC and externally priced Base assets. RUBX, RUBZ, equities, bonds and loan claims are internal claims and are not double-counted.
- Primary equity and bond subscriptions move existing USDC inside the system and never count as external revenue.
- Borrowing moves existing USDC from a funded credit reserve or lender to borrowers; principal is not income.
- Interest, coupons and dividends are internal transfers unless paid from an explicitly external income source.
- Founder revenue is limited to explicit transaction/origination/execution fees paid out of existing real balances or captured external fee value.
- No loan, dividend, coupon, redemption or liquidation may print missing cash.
- The 12-second block clock remains literal; annualized rates accrue with ACT/365 time fractions.

## Architecture
### Portfolio allocator
Each `MarketAgent` gets an adaptive portfolio policy. The allocator computes target weights for USDC, RUBX, RUBZ and the ten Base assets from agent risk, trend, mean-reversion, current price momentum, protocol/internal mispricing, RUBX yield and RUBZ valuation gap. Rebalancing is bounded per block and routes through existing internal/external markets.

### SYNERGY yield curve
A `SynergyYieldCurve` publishes annualized 1D, 7D, 30D, 90D and 365D rates. The policy anchor responds to RUBX coverage, observed Base volatility, credit utilization and loan losses. Term premia generate a curve rather than a single rate. Curve updates are deterministic for a deterministic market path.

### Agent companies and equities
A subset of agents can form `AgentCompany` entities. Formation transfers USDC from founders into company treasury. Companies issue primary equity at NAV/share; subscribers transfer USDC to the company and receive internal shares. Equity fair value is company marked NAV divided by shares. Companies deploy only real cash into the same Base asset universe. Dividends can only be paid from available company cash.

### Corporate bonds
Companies can issue fixed-coupon notes with maturity expressed in literal block timestamps and annualized coupon rates. Bond pricing discounts future principal/coupon using the SYNERGY yield curve plus issuer spread. Primary subscriptions transfer agent cash to company cash. Matured obligations pay only up to available company cash; unpaid amounts become defaults/losses.

### Portfolio-backed credit
A protocol credit facility is seeded by transferring USDC out of the general Base/protocol treasury, preserving aggregate HardNAV while leaving the canonical RUBX–RUBZ monetary reserve untouched. Borrowing capacity is based on marked collateral using haircuts: USDC, RUBX, RUBZ and Base assets receive different collateral factors; corporate equity is more heavily discounted. Loans accrue using actual elapsed seconds. LTV breaches trigger margin calls and deterministic liquidation of collateral into USDC through existing markets. Residual unpaid amounts become bad debt.

### Orchestration
`MacroEconomy` gains a `CapitalMarketsEngine` that performs, in order: price update, existing market flows, portfolio allocation/rebalancing, company issuance/deployment, bond issuance/trading/settlement, portfolio-credit checks, yield-curve update, existing triangle controller, and snapshot. All new internal securities remain excluded from aggregate real wealth.

## Reporting
The 500-block report adds allocation concentration, average agent risk allocation, yield curve start/end, outstanding corporate bonds, equity market cap, company NAV, credit reserve/utilization, portfolio debt, margin calls, liquidations, bad debt, and issuance/fee statistics. New charts visualize yield-curve evolution, asset allocation, capital formation, credit utilization/LTV, equity NAV/share and wealth/alpha.

## Success criteria
- Existing 59 tests remain green.
- New tests prove internal financing cannot create real wealth.
- 500 blocks x 12 seconds still produce exactly 6000 seconds.
- Deterministic seed reproduces identical v4 metrics.
- At least one company, equity issue, bond issue and portfolio-backed loan occur in the reference run.
- Stress path can create margin calls/defaults without violating accounting conservation.
- Report distinguishes raw wealth, capital-adjusted wealth and HODL alpha as before.
