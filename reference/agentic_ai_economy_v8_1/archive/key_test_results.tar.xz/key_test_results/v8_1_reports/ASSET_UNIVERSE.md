# Base asset universe used by SYNERGY Macro Economy v3

Snapshot context: 2026-09-17. The simulation uses ten economically distinct, large/liquid Base assets while excluding USDC because USDC is already the settlement leg of the RUBX–RUBZ–USDC core and excluding near-duplicate lending-wrapper assets from the market basket.

| Asset | Starting mark used in scenario | Role |
|---|---:|---|
| WETH | 2403.78 | ETH / core collateral |
| cbBTC | 76141.13 | BTC collateral |
| VVV | 21.32 | Base-native / AI risk asset |
| VIRTUAL | 0.585223 | AI-agent ecosystem risk asset |
| AERO | 0.525202 | Base DEX/liquidity asset |
| cbETH | 2732.23 | staked ETH collateral |
| USDe | 0.9992 | dollar-like yield/stable asset |
| cbXRP | 1.42 | wrapped XRP exposure |
| TOSHI | 0.00010725 | high-beta Base-native asset |
| MORPHO | 2.08 | lending/credit market asset |

The starting marks are fixed inputs for reproducibility, based on public market observations around 2026-09-15/16. They are not live oracle calls. Per-block volatility parameters are explicit simulation assumptions rather than forecasts.

The public Base/DefiLlama market snapshot used to choose the universe shows USDC, cbBTC, WETH, VVV, VIRTUAL, AERO, cbETH and USDe among the largest Base-linked assets by bridged value. The v3 basket then de-duplicates wrapper variants and uses cbXRP/TOSHI/MORPHO to cover additional distinct Base risk/credit segments.
