from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .markets import ProtocolMarkets

D = Decimal
MONEY_Q = D("0.000000000001")


@dataclass
class MarketAgent:
    agent_id: str
    cash_usdc: Decimal
    risk: float
    trend: float
    mean_reversion: float
    holdings: dict[str, Decimal] = field(default_factory=dict)
    rubx: Decimal = D("0")
    rubz: Decimal = D("0")
    realized_external_fees: Decimal = D("0")

    def real_wealth(self, prices: dict[str, Decimal]) -> Decimal:
        total = self.cash_usdc + sum(self.holdings.get(s, D("0")) * D(p) for s, p in prices.items())
        return total.quantize(MONEY_Q)

    def gross_wealth(self, prices: dict[str, Decimal], rubx_price: Decimal, rubz_price: Decimal) -> Decimal:
        total = self.real_wealth(prices) + self.rubx * D(rubx_price) + self.rubz * D(rubz_price)
        return total.quantize(MONEY_Q)

    def buy_internal(self, markets: ProtocolMarkets, symbol: str, amount_usdc: Decimal) -> Decimal:
        amount = D(amount_usdc)
        if amount <= 0 or amount > self.cash_usdc:
            raise ValueError("insufficient agent cash")
        swap = markets.pools[symbol].swap_b_for_a(amount)
        self.cash_usdc -= amount
        self.holdings[symbol] = self.holdings.get(symbol, D("0")) + swap.amount_out
        return swap.amount_out

    def sell_internal(self, markets: ProtocolMarkets, symbol: str, token_amount: Decimal) -> Decimal:
        amount = D(token_amount)
        held = self.holdings.get(symbol, D("0"))
        if amount <= 0 or amount > held:
            raise ValueError("insufficient agent token")
        swap = markets.pools[symbol].swap_a_for_b(amount)
        self.holdings[symbol] = held - amount
        self.cash_usdc += swap.amount_out
        return swap.amount_out

    def buy_external(self, symbol: str, notional_usdc: Decimal, price: Decimal, *, fee_bps: int = 10) -> Decimal:
        notional = D(notional_usdc)
        p = D(price)
        fee = notional * D(fee_bps) / D("10000")
        cost = notional + fee
        if notional <= 0 or cost > self.cash_usdc:
            raise ValueError("insufficient agent cash")
        self.cash_usdc -= cost
        self.holdings[symbol] = self.holdings.get(symbol, D("0")) + notional / p
        self.realized_external_fees += fee
        return fee

    def sell_external(self, symbol: str, token_amount: Decimal, price: Decimal, *, fee_bps: int = 10) -> Decimal:
        amount = D(token_amount)
        p = D(price)
        held = self.holdings.get(symbol, D("0"))
        if amount <= 0 or amount > held:
            raise ValueError("insufficient agent token")
        gross = amount * p
        fee = gross * D(fee_bps) / D("10000")
        self.holdings[symbol] = held - amount
        self.cash_usdc += gross - fee
        self.realized_external_fees += fee
        return fee
