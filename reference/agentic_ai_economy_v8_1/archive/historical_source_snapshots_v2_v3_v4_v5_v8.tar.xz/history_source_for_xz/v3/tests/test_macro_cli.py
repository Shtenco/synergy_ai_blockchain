import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class MacroCLITests(unittest.TestCase):
    def test_cli_writes_500_block_json_and_csv(self):
        with tempfile.TemporaryDirectory() as td:
            json_path = Path(td) / "report.json"
            csv_path = Path(td) / "report.csv"
            proc = subprocess.run(
                [
                    sys.executable,
                    "run_macro_economy.py",
                    "--seed", "77",
                    "--json", str(json_path),
                    "--csv", str(csv_path),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue(json_path.exists())
            self.assertTrue(csv_path.exists())
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["blocks"], 500)
            self.assertEqual(payload["elapsed_seconds"], 6000)
            self.assertEqual(len(payload["snapshots"]), 500)


if __name__ == "__main__":
    unittest.main()
