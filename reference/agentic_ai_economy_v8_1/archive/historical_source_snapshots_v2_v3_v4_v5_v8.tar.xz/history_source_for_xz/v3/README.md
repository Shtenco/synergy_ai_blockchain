# SYNERGY Autonomous Agent Economy v3

v3 extends the verified v2 autonomous-agent economy with a macro-financial core built around **RUBX–RUBZ–USDC** plus ten Base Mainnet asset markets.

The central accounting rule remains unchanged: **internal money movement is not profit**. Minting RUBX/RUBZ, moving reserves between protocol-owned pools, internal agent trading, ADDLP-style liquidity changes and triangular arbitrage cannot create HardNAV by themselves.

## The monetary triangle

- **USDC** — settlement cash and unit of account.
- **RUBX** — senior reserve/debt instrument, analogous to a treasury instrument. It targets 1 USDC and its face-value supply is an explicit senior liability.
- **RUBZ** — residual equity/risk instrument, analogous to an equity index. Its fair value is derived from residual protocol equity after the RUBX senior claim.
- Protocol-owned CPMMs: `RUBX/USDC`, `RUBZ/USDC`, `RUBX/RUBZ`.
- The controller can issue/sell or buy/burn RUBX/RUBZ and can run both triangular routes, but these actions are HardNAV-neutral by construction.

The original Solidity release is preserved unchanged under `legacy/RUBX_RUBZ_RELEASE/`.

## Ten Base markets

The macro layer models internal protocol-owned asset/USDC AMMs plus external reference markets for:

`WETH, cbBTC, VVV, VIRTUAL, AERO, cbETH, USDe, cbXRP, TOSHI, MORPHO`

USDC is not counted again because it is already the settlement asset of the core triangle. Near-duplicate wrapper assets are intentionally de-duplicated. See `reports/ASSET_UNIVERSE.md` for the fixed reproducible starting marks and selection notes.

External prices follow a deterministic correlated stochastic process. It is a scenario engine, not a historical replay or a price prediction.

## Honest prosperity accounting

v3 reports several different concepts instead of calling all TVL “profit”:

- **Protocol HardNAV**: USDC + real Base assets across protocol treasury and protocol-owned pools. RUBX/RUBZ are excluded.
- **RUBX liability**: face-value senior claim.
- **Residual equity**: HardNAV minus RUBX liability.
- **System real wealth**: all real USDC/Base assets held by the protocol, internal agents and Founder Treasury. Internal RUBX/RUBZ claims are not double-counted.
- **Net external capital flow**: subscriptions/redemptions when outside users buy/sell RUBX/RUBZ. New capital is not classified as profit.
- **Capital-adjusted wealth**: real wealth minus net external capital flow.
- **HODL benchmark**: value of the original real-asset inventory if it had simply been held.
- **Alpha vs HODL**: capital-adjusted actual wealth minus that passive benchmark.

Outside Base-market takers are split between noise flow and informed/arbitrage flow. Noise traders can provide fee income; informed flow creates adverse selection/LVR. This means profitability is not hard-coded as “every trade makes money.”

## Reference test: 500 Base-style blocks

Exact run:

```bash
python run_macro_economy.py \
  --blocks 500 \
  --block-seconds 12 \
  --seed 77 \
  --json reports/macro_500_blocks_seed77.json \
  --csv reports/macro_500_blocks_seed77.csv
```

That is exactly **500 × 12 seconds = 6000 seconds = 100 minutes**.

Final verified reference result:

| Metric | Result |
|---|---:|
| Opening system real wealth | $8,700.000000 |
| Closing system real wealth | $8,753.713153 |
| Raw wealth change | +$53.713153 |
| Net external RUBX/RUBZ capital flow | +$18.017485 |
| Capital-adjusted closing wealth | $8,735.695668 |
| Capital-adjusted wealth change | **+$35.695668** |
| Closing passive HODL benchmark | $8,713.819304 |
| **Alpha vs HODL** | **+$21.876363** |
| Founder externally attributed revenue | **+$3.566637** |
| Captured external fee value | $21.399820 |
| Base outside volume | $7,032.843007 |
| Triangle outside volume | $182.539126 |
| RUBX price | $1.000000 → $1.004964 |
| RUBZ price | $1.000000 → $1.010795 |
| RUBZ ending fair equity value | $1.004455 |
| RUBX coverage | 2.000000× → 1.999579× |
| Max capital-adjusted drawdown | 0.337333% |

### Answer to “does system prosperity grow?”

For the exact reference path, **yes** under all three relevant lenses:

1. raw real wealth rises;
2. wealth still rises after new outside capital is removed;
3. the active economy finishes above passive HODL, so the result is not explained only by Base asset appreciation.

This is a simulation result, not a guarantee of live profitability.

## 20-seed robustness check

`reports/robustness_20_seeds.csv` repeats the same 500-block model for seeds 1–20.

- Alpha vs HODL: positive in **20/20** paths.
- Alpha range: **+$16.43 to +$24.83**.
- Mean alpha: **+$20.12**.
- Absolute capital-adjusted wealth increased in **15/20** paths and decreased in **5/20** paths because market marks can fall even when the strategy beats HODL.
- Worst observed capital-adjusted change in this small sample: **−$27.44**.

This distinction is intentional: positive strategy alpha does not eliminate market risk.

## Charts and HTML report

Generate the self-contained report:

```bash
python scripts/render_macro_report.py \
  reports/macro_500_blocks_seed77.json \
  reports/macro_500_blocks_seed77 \
  --robustness-csv reports/robustness_20_seeds.csv
```

It renders 15 standalone PNG charts covering:

- raw/capital-adjusted/HODL wealth;
- protocol HardNAV;
- Founder Treasury;
- RUBX/RUBZ/fair-equity prices;
- RUBX coverage;
- Gross TVL;
- all ten Base asset price paths normalized to 100;
- internal-vs-external AMM deviation;
- fee capture;
- alpha vs HODL;
- adjusted drawdown;
- per-asset external volume;
- final Base asset returns;
- 20-seed alpha distribution;
- 20-seed capital-adjusted wealth changes.

The HTML report embeds the images directly and can be opened as one file.

## Package map

```text
agent_economy/          v2 labor/credit/deposit/investment/insurance economy
macro_economy/
  amm.py                constant-product market primitive
  assets.py             ten Base asset specs + deterministic external market
  triangle.py           RUBX/RUBZ/USDC debt-equity monetary triangle
  markets.py            protocol-owned Base AMMs + external taker accounting
  agents.py             heterogeneous market-agent portfolios/trading
  engine.py             500-block macro orchestrator + prosperity accounting
scripts/
  render_macro_report.py
legacy/
  RUBX_RUBZ_RELEASE/    unchanged canonical Solidity release
reports/
  macro_500_blocks_seed77.json
  macro_500_blocks_seed77.csv
  robustness_20_seeds.csv
  macro_500_blocks_seed77/
tests/
```

## Verification

Run all Python tests:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
```

Legacy v2 DQN/Base invariant suite:

```bash
MODE=unit SCALE=1 python experiments/dqn_cb_market/experiment_syna.py
```

No live private keys, live swaps or autonomous live-money execution are enabled in v3. The code is simulation/shadow infrastructure for validating the economic design before any live connector is considered.
