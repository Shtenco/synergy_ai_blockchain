from __future__ import annotations

from decimal import Decimal
import math
import random

from .agents import MarketAgent
from .markets import ProtocolMarkets
from .portfolio import PortfolioAllocator
from .portfolio_credit import PortfolioCreditFacility
from .securities import SecuritiesMarket
from .triangle import TriangleEconomy
from .yield_curve import SynergyYieldCurve

D = Decimal
Q = D('0.000000000001')


def q(value: Decimal) -> Decimal:
    return D(value).quantize(Q)


class CapitalMarketsEngine:
    """Endogenous allocation, securities, credit and term-structure engine."""

    def __init__(
        self,
        *,
        agents: list[MarketAgent],
        triangle: TriangleEconomy,
        markets: ProtocolMarkets,
        seed: int,
        block_seconds: int,
        credit_reserve_usdc: Decimal = D('150'),
        company_count: int = 4,
        rebalance_interval: int = 12,
        credit_principal_fraction: Decimal = D('0.25'),
        credit_max_loan_usdc: Decimal = D('5'),
        credit_max_capacity_fraction: Decimal = D('0.90'),
    ) -> None:
        self.agents = agents
        self.triangle = triangle
        self.markets = markets
        self.rng = random.Random(seed + 404)
        self.block_seconds = int(block_seconds)
        self.rebalance_interval = max(1, int(rebalance_interval))
        self.credit_principal_fraction = D(credit_principal_fraction)
        self.credit_max_loan_usdc = D(credit_max_loan_usdc)
        self.allocator = PortfolioAllocator(tuple(markets.pools))
        self.yield_curve = SynergyYieldCurve(policy_rate=D('0.045'))
        self.securities = SecuritiesMarket(block_seconds=block_seconds)

        reserve = D(credit_reserve_usdc)
        available = max(D('0'), markets.treasury_usdc)
        reserve = min(reserve, available)
        markets.treasury_usdc -= reserve
        self.credit = PortfolioCreditFacility(
            reserve_usdc=reserve,
            block_seconds=block_seconds,
            max_capacity_fraction=D(credit_max_capacity_fraction),
        )

        self._form_initial_companies(company_count)
        self.yield_curve_start = self.yield_curve.update(
            triangle.coverage_ratio(), D('0.04'), self.credit.utilization(), self.credit.bad_debt_ratio()
        )
        self.current_block = 0
        self.equity_issue_count = 0
        self.bond_issue_count = 0
        self.loan_issue_count = 0
        self.company_trade_volume_usdc = D('0')

    def _form_initial_companies(self, count: int) -> None:
        for founder in self.agents[: max(0, min(int(count), len(self.agents)))]:
            contribution = min(D('8'), founder.cash_usdc * D('0.20'))
            if contribution >= D('1'):
                self.securities.form_company(founder, contribution_usdc=contribution, initial_shares=contribution)

    def company_real_wealth(self, prices: dict[str, Decimal]) -> Decimal:
        return q(sum((c.real_nav(prices) for c in self.securities.companies.values()), D('0')))

    def protocol_credit_real_wealth(self, prices: dict[str, Decimal]) -> Decimal:
        return q(self.credit.facility_real_wealth(prices))

    def agent_financial_claims_value(self, prices: dict[str, Decimal], current_block: int | None = None) -> Decimal:
        block = self.current_block if current_block is None else int(current_block)
        total = D('0')
        for company in self.securities.companies.values():
            px = company.equity_price(prices)
            for agent in self.agents:
                total += company.shareholders.get(agent.agent_id, D('0')) * px
        for bond in self.securities.bonds.values():
            if bond.status != 'active':
                continue
            remaining_seconds = max(0, bond.maturity_block - block) * self.block_seconds
            days = max(1, math.ceil(remaining_seconds / 86400))
            total += self.securities.mark_bond(
                bond.bond_id,
                current_block=block,
                annual_yield=self.yield_curve.rate_for_days(days),
            )
        return q(total)

    def outstanding_bond_face(self) -> Decimal:
        return q(sum((b.face_value for b in self.securities.active_bonds()), D('0')))

    def portfolio_debt(self, current_block: int | None = None) -> Decimal:
        block = self.current_block if current_block is None else int(current_block)
        return q(sum((l.amount_due(block) for l in self.credit.loans.values() if l.status == 'active'), D('0')))

    def allocation_snapshot(self, prices: dict[str, Decimal]) -> dict[str, Decimal]:
        values: dict[str, Decimal] = {'USDC': D('0'), 'RUBX': D('0'), 'RUBZ': D('0')}
        values.update({s: D('0') for s in self.markets.pools})
        for agent in self.agents:
            values['USDC'] += agent.cash_usdc
            values['RUBX'] += agent.rubx * self.triangle.rubx_price()
            values['RUBZ'] += agent.rubz * self.triangle.rubz_price()
            for symbol, qty in agent.holdings.items():
                if symbol in prices:
                    values[symbol] += qty * D(prices[symbol])
        total = sum(values.values(), D('0'))
        if total <= 0:
            return {k: D('0') for k in values}
        result = {k: (v / total).quantize(Q) for k, v in values.items()}
        residual = D('1') - sum(result.values(), D('0'))
        result['USDC'] += residual
        return result

    def _realized_vol(self, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> Decimal:
        if not prices:
            return D('0')
        moves = []
        for symbol, price in prices.items():
            prev = max(D('0.000000000001'), D(prev_prices[symbol]))
            moves.append(abs(D(price) / prev - D('1')))
        mean_abs = sum(moves, D('0')) / D(len(moves))
        # Scale one 12-second absolute move to a daily-like risk signal.
        scale = D(str(math.sqrt(86400 / self.block_seconds)))
        return min(D('1.5'), mean_abs * scale)

    def _update_curve(self, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> None:
        self.yield_curve.update(
            self.triangle.coverage_ratio(),
            self._realized_vol(prices, prev_prices),
            self.credit.utilization(),
            self.credit.bad_debt_ratio(),
        )

    def _current_liquid_values(self, agent: MarketAgent, prices: dict[str, Decimal]) -> dict[str, Decimal]:
        values: dict[str, Decimal] = {
            'USDC': agent.cash_usdc,
            'RUBX': agent.rubx * self.triangle.rubx_price(),
            'RUBZ': agent.rubz * self.triangle.rubz_price(),
        }
        for symbol in self.markets.pools:
            values[symbol] = agent.holdings.get(symbol, D('0')) * D(prices[symbol])
        return values

    def _sell_asset(self, agent: MarketAgent, asset: str, value_usdc: Decimal, prices: dict[str, Decimal]) -> Decimal:
        target = max(D('0'), D(value_usdc))
        if target <= D('0.01'):
            return D('0')
        if asset == 'RUBX' and agent.rubx > 0:
            qty = min(agent.rubx, target / max(self.triangle.rubx_price(), D('0.000001')))
            out = self.triangle.xu.swap_a_for_b(qty).amount_out
            agent.rubx -= qty
            agent.cash_usdc += out
            return out
        if asset == 'RUBZ' and agent.rubz > 0:
            qty = min(agent.rubz, target / max(self.triangle.rubz_price(), D('0.000001')))
            out = self.triangle.zu.swap_a_for_b(qty).amount_out
            agent.rubz -= qty
            agent.cash_usdc += out
            return out
        if asset in self.markets.pools:
            held = agent.holdings.get(asset, D('0'))
            if held <= 0:
                return D('0')
            qty = min(held, target / max(D(prices[asset]), D('0.000001')))
            out = self.markets.pools[asset].swap_a_for_b(qty).amount_out
            agent.holdings[asset] = held - qty
            agent.cash_usdc += out
            return out
        return D('0')

    def _buy_asset(self, agent: MarketAgent, asset: str, value_usdc: Decimal) -> Decimal:
        spend = min(max(D('0'), D(value_usdc)), agent.cash_usdc)
        if spend <= D('0.01') or asset == 'USDC':
            return D('0')
        if asset == 'RUBX':
            qty = self.triangle.xu.swap_b_for_a(spend).amount_out
            agent.cash_usdc -= spend
            agent.rubx += qty
            return spend
        if asset == 'RUBZ':
            qty = self.triangle.zu.swap_b_for_a(spend).amount_out
            agent.cash_usdc -= spend
            agent.rubz += qty
            return spend
        if asset in self.markets.pools:
            qty = self.markets.pools[asset].swap_b_for_a(spend).amount_out
            agent.cash_usdc -= spend
            agent.holdings[asset] = agent.holdings.get(asset, D('0')) + qty
            return spend
        return D('0')

    def _rebalance_agent(self, agent: MarketAgent, block: int, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> None:
        internal = {s: self.markets.internal_price(s) for s in self.markets.pools}
        weights = self.allocator.target_weights(
            agent,
            prices=prices,
            prev_prices=prev_prices,
            internal_prices=internal,
            rubx_price=self.triangle.rubx_price(),
            rubz_price=self.triangle.rubz_price(),
            rubz_fair_value=max(D('0.000001'), self.triangle.rubz_fair_value()),
            curve=self.yield_curve,
        )
        agent.target_weights = weights
        values = self._current_liquid_values(agent, prices)
        total = sum(values.values(), D('0'))
        if total <= D('1'):
            return
        gaps = {asset: values.get(asset, D('0')) - total * weight for asset, weight in weights.items()}
        overweight = max(gaps, key=lambda a: gaps[a])
        underweight = min(gaps, key=lambda a: gaps[a])
        turnover_limit = min(D('3'), total * D('0.04'))
        sold = D('0')
        if overweight != 'USDC' and gaps[overweight] > D('0.10'):
            sold = self._sell_asset(agent, overweight, min(gaps[overweight], turnover_limit), prices)
        buy_budget = min(turnover_limit, max(D('0'), -gaps[underweight]), agent.cash_usdc * D('0.35'))
        bought = self._buy_asset(agent, underweight, buy_budget)
        agent.portfolio_turnover_usdc += sold + bought
        agent.last_rebalance_block = block

    def _rebalance_agents(self, block: int, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> None:
        if block % self.rebalance_interval != 0:
            return
        cohort = (block // self.rebalance_interval) % 3
        for idx, agent in enumerate(self.agents):
            if idx % 3 == cohort:
                self._rebalance_agent(agent, block, prices, prev_prices)

    def _company_deployment(self, block: int, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> None:
        if block % 15 != 0:
            return
        ranked = sorted(
            self.markets.pools,
            key=lambda s: D(prices[s]) / max(D('0.0000001'), D(prev_prices[s])) - D('1'),
            reverse=True,
        )
        best = ranked[0]
        worst = ranked[-1]
        worst_ret = D(prices[worst]) / max(D('0.0000001'), D(prev_prices[worst])) - D('1')
        for company in self.securities.companies.values():
            spend = min(D('1.5'), company.cash_usdc * D('0.05'))
            if spend > D('0.10'):
                qty = self.markets.pools[best].swap_b_for_a(spend).amount_out
                company.cash_usdc -= spend
                company.holdings[best] = company.holdings.get(best, D('0')) + qty
                self.company_trade_volume_usdc += spend
            if worst_ret < D('-0.001') and company.holdings.get(worst, D('0')) > 0:
                qty = company.holdings[worst] * D('0.10')
                out = self.markets.pools[worst].swap_a_for_b(qty).amount_out
                company.holdings[worst] -= qty
                company.cash_usdc += out
                self.company_trade_volume_usdc += out

    def _equity_activity(self, block: int, prices: dict[str, Decimal]) -> None:
        if block < 10 or block % 60 != 10 or not self.securities.companies:
            return
        companies = list(self.securities.companies.values())
        company = companies[(block // 60) % len(companies)]
        investor = self.agents[(block // 10 + 5) % len(self.agents)]
        invest = min(D('2.5'), investor.cash_usdc * D('0.08'))
        if invest <= D('0.25'):
            return
        try:
            self.securities.subscribe_equity(company.company_id, investor, invest, prices=prices)
            self.equity_issue_count += 1
        except ValueError:
            return

    def _bond_activity(self, block: int) -> None:
        # Settle matured bonds first.
        for bond in list(self.securities.active_bonds()):
            if block >= bond.maturity_block:
                investor = next((a for a in self.agents if a.agent_id == bond.investor_id), None)
                if investor is not None:
                    self.securities.settle_bond(bond.bond_id, investor, current_block=block)

        if block < 25 or block % 90 != 25 or not self.securities.companies:
            return
        companies = list(self.securities.companies.values())
        company = companies[(block // 90) % len(companies)]
        investor = self.agents[(block // 25 + 9) % len(self.agents)]
        face = min(D('6'), investor.cash_usdc * D('0.15'))
        if face <= D('1'):
            return
        spread = D('0.015') + D(str(self.rng.uniform(0.005, 0.04)))
        coupon = self.yield_curve.rate_for_days(30) + spread
        try:
            self.securities.issue_bond(
                company.company_id,
                investor,
                face_value=face,
                coupon_rate=coupon,
                current_block=block,
                maturity_block=block + 120,
                curve=self.yield_curve,
                issuer_spread=spread,
            )
            self.bond_issue_count += 1
        except ValueError:
            return

    def _manage_credit(self, block: int, prices: dict[str, Decimal]) -> None:
        for loan in list(self.credit.loans.values()):
            if loan.status != 'active':
                continue
            borrower = next((a for a in self.agents if a.agent_id == loan.borrower_id), None)
            if borrower is None:
                continue
            if block >= loan.maturity_block:
                self.credit.repay(loan.loan_id, borrower, current_block=block)
                if loan.status == 'active':
                    self.credit.liquidate(
                        loan.loan_id,
                        borrower,
                        current_block=block,
                        prices=prices,
                        rubx_price=self.triangle.rubx_price(),
                        rubz_price=self.triangle.rubz_price(),
                        securities=self.securities,
                    )
                continue
            if self.credit.needs_margin_call(
                loan.loan_id,
                borrower,
                current_block=block,
                prices=prices,
                rubx_price=self.triangle.rubx_price(),
                rubz_price=self.triangle.rubz_price(),
                securities=self.securities,
            ):
                self.credit.record_margin_call(loan.loan_id)
                if loan.margin_calls >= 2:
                    self.credit.liquidate(
                        loan.loan_id,
                        borrower,
                        current_block=block,
                        prices=prices,
                        rubx_price=self.triangle.rubx_price(),
                        rubz_price=self.triangle.rubz_price(),
                        securities=self.securities,
                    )

    def _originate_credit(self, block: int, prices: dict[str, Decimal]) -> None:
        if block < 35 or block % 70 != 35 or self.credit.reserve_usdc <= D('2'):
            return
        candidates = sorted(self.agents, key=lambda a: a.risk, reverse=True)
        for borrower in candidates:
            capacity = self.credit.available_capacity(
                borrower,
                prices=prices,
                rubx_price=self.triangle.rubx_price(),
                rubz_price=self.triangle.rubz_price(),
                securities=self.securities,
                current_block=block,
            )
            principal = min(self.credit_max_loan_usdc, capacity * self.credit_principal_fraction, self.credit.reserve_usdc * D('0.08'))
            if principal <= D('0.75'):
                continue
            rate = self.yield_curve.rate_for_days(30) + D(str(borrower.risk)) * D('0.08')
            try:
                self.credit.originate(
                    borrower,
                    principal=principal,
                    annual_rate=rate,
                    current_block=block,
                    maturity_block=block + 140,
                    prices=prices,
                    rubx_price=self.triangle.rubx_price(),
                    rubz_price=self.triangle.rubz_price(),
                    securities=self.securities,
                )
                self.loan_issue_count += 1
                return
            except ValueError:
                continue

    def _dividend_activity(self, block: int) -> None:
        if block < 150 or block % 150 != 0:
            return
        for company in self.securities.companies.values():
            if company.cash_usdc > D('6'):
                self.securities.pay_dividend(company.company_id, min(D('0.5'), company.cash_usdc * D('0.02')))

    def step(self, *, block: int, prices: dict[str, Decimal], prev_prices: dict[str, Decimal]) -> None:
        self.current_block = int(block)
        self._update_curve(prices, prev_prices)
        self._rebalance_agents(block, prices, prev_prices)
        self._company_deployment(block, prices, prev_prices)
        self._equity_activity(block, prices)
        self._bond_activity(block)
        self._manage_credit(block, prices)
        self._originate_credit(block, prices)
        self._dividend_activity(block)
        # Credit utilization changed after origination/settlement; publish the end-of-block curve.
        self._update_curve(prices, prev_prices)
