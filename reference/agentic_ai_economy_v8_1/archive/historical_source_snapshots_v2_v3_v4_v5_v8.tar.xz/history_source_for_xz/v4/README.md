# SYNERGY Agent Capital Markets v4

v4 turns the verified RUBX–RUBZ–USDC macro economy into an endogenous agent capital market.

The core remains:

- **USDC** — settlement cash and unit of account.
- **RUBX** — senior reserve/debt instrument, analogous to treasury paper.
- **RUBZ** — residual equity/risk instrument, analogous to broad equity capital.
- Ten internal/external Base markets: `WETH, cbBTC, VVV, VIRTUAL, AERO, cbETH, USDe, cbXRP, TOSHI, MORPHO`.

v4 adds autonomous portfolio allocation, agent companies, equity issuance, corporate bonds, portfolio-backed credit, margin/liquidation and a full SYNERGY term structure.

## Accounting rule

Internal claims never create wealth by accounting convention.

Equity, bonds, RUBX/RUBZ and loan receivables are claims on real assets. Aggregate system real wealth is counted from real USDC/Base assets only. Capital subscriptions are tracked as external capital flow rather than profit. Minting, lending, issuing securities, internal arbitrage and moving reserves between modules cannot by themselves increase HardNAV.

## Capital markets

### Autonomous allocation

Every agent receives a target allocation across:

`USDC + RUBX + RUBZ + 10 Base assets`

The allocator responds to agent risk appetite, trend/mean-reversion traits, internal/external price deviation, RUBZ fair value and the current SYNERGY yield curve. Conservative agents structurally prefer USDC/RUBX; risk-seeking agents structurally allocate more to RUBZ/Base risk assets.

### Agent companies

Agents can form companies with a separate balance sheet. Companies can:

- receive founder capital;
- issue new equity;
- deploy real USDC into Base assets;
- pay dividends only from available cash;
- issue bonds to other agents;
- default on a bond if cash is insufficient at maturity.

Primary issuance transfers existing cash from investor to company and therefore does not create system wealth.

### SYNERGY yield curve

The system publishes annualized tenors:

`1D, 7D, 30D, 90D, 365D`

The curve responds to RUBX coverage, realized market volatility, credit utilization and bad debt. Bonds and portfolio loans are priced off this curve plus issuer/borrower risk spread.

### Portfolio-backed credit

A real USDC credit reserve is transferred from the general Base/protocol treasury. The canonical RUBX/RUBZ monetary reserve is left intact.

Borrowing capacity is calculated from marked collateral with haircuts for Base assets, RUBX, RUBZ and company equity. Loans accrue interest using literal elapsed seconds. Falling collateral value triggers margin calls; repeated breach triggers deterministic liquidation. Missing cash is never minted. Any uncovered remainder would become bad debt.

## Reference run — 500 Base-style blocks

Command:

```bash
python run_macro_economy.py \
  --blocks 500 \
  --block-seconds 12 \
  --seed 77 \
  --json reports/v4_seed77/report.json \
  --csv reports/v4_seed77/blocks.csv
```

This is exactly **500 × 12 seconds = 6000 seconds = 100 minutes**.

| Metric | v4 reference result |
|---|---:|
| Opening system real wealth | $8,700.000000 |
| Closing system real wealth | $8,759.073811 |
| Net external capital flow | +$24.133817 |
| Capital-adjusted closing wealth | $8,734.939994 |
| Capital-adjusted wealth change | **+$34.939994** |
| Passive HODL benchmark | $8,713.819304 |
| **Alpha vs HODL** | **+$21.120690** |
| Founder externally attributable revenue | **+$3.627785** |
| RUBX coverage | 2.000000× → 1.955264× |
| Max adjusted drawdown | 0.339125% |
| Equity issuance | $18.821803 |
| Bond issuance | $27.315390 |
| Portfolio loans originated | 7 |
| Ending credit utilization | 5.502796% |
| Ending portfolio bad debt | $0 |
| Ending 1D SYNERGY yield | 4.901859% |
| Ending 365D SYNERGY yield | 5.621841% |

The reference path remains profitable after removing new outside capital and still beats passive HODL. New securities and loans do not mechanically increase that result.

## Comparison with v3

On the same deterministic seeds 1–20, v4 keeps alpha positive in **20/20** paths but has a small complexity cost versus v3.

- v4 mean alpha vs HODL: **+$18.992945**.
- v4 alpha range: **+$14.543606 to +$24.250110**.
- capital-adjusted real wealth rises in **15/20** paths.
- mean v4 minus v3 alpha: **−$1.123556** per 100-minute scenario.
- v4 underperforms v3 alpha on all 20 of these specific paths, because company deployment, rebalancing and financing alter exposure and incur opportunity/adverse-selection costs.

This is intentional evidence that capital-market complexity is not treated as free profit.

## High-LTV credit stress

`reports/v4_credit_stress_seed77.json` uses 7× reference volatility and an effective high-LTV profile.

Result:

- **14 margin calls**;
- **7 liquidations**;
- **$0 uncovered bad debt** on this path because liquidated collateral plus borrower liquidity fully covered obligations;
- accounting remains conserved.

The stress case therefore demonstrates forced deleveraging without requiring artificial money creation or an intentionally undercollateralized default.

## Charts

The report renderer produces **25 standalone PNG charts** plus a self-contained HTML report. They include:

- real wealth / capital-adjusted wealth / HODL;
- protocol HardNAV and Founder Treasury;
- RUBX/RUBZ/fair-equity prices and RUBX coverage;
- all ten normalized Base prices;
- AMM deviation/LVR proxies and fee capture;
- alpha and drawdown;
- external volume and asset returns;
- full 1D–365D yield-curve evolution;
- core agent allocation and Base-basket allocation;
- company NAV/equity market cap;
- outstanding bond face and financial claims;
- credit reserve/debt/utilization;
- cumulative margin calls/liquidations;
- equity/bond issuance;
- company deployment volume;
- opening vs closing yield curve;
- 20-seed alpha and wealth robustness.

Generate:

```bash
python scripts/render_macro_report.py \
  reports/v4_seed77/report.json \
  reports/v4_seed77/rendered \
  --robustness-csv reports/v4_robustness_20_seeds.csv
```

## Package map

```text
agent_economy/              v2 labor/credit/deposit/investment/insurance economy
macro_economy/
  amm.py                    constant-product market primitive
  assets.py                 ten Base asset specs + deterministic reference market
  triangle.py               RUBX/RUBZ/USDC monetary debt-equity core
  markets.py                Base protocol-owned AMMs + external-flow accounting
  agents.py                 heterogeneous market agents
  portfolio.py              autonomous multi-asset allocation policy
  yield_curve.py            1D/7D/30D/90D/365D SYNERGY curve
  securities.py             agent companies, shares and corporate bonds
  portfolio_credit.py       collateral, margin, liquidation and bad debt
  capital_markets.py        integrated capital-markets engine
  engine.py                 500-block macro orchestrator and prosperity accounting
scripts/
  render_macro_report.py
legacy/
  RUBX_RUBZ_RELEASE/        preserved canonical Solidity release
reports/
  v4_seed77/
  v4_robustness_20_seeds.csv
  v4_vs_v3_seeds_1_20.csv
  v4_credit_stress_seed77.json
tests/
```

## Verification

Full Python suite:

```bash
python -m unittest discover -s tests -v
```

Legacy DQN/Base invariant suite:

```bash
MODE=unit python experiments/dqn_cb_market/experiment_syna.py
```

The verified development tree passes **82/82 Python tests** and the legacy invariant suite reports **UNIT PASS**.

This project remains simulation/shadow infrastructure. No private keys, autonomous live-money permissions or live Base execution are enabled.
