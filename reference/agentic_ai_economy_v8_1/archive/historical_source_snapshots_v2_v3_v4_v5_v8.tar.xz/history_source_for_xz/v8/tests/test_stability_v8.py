from decimal import Decimal as D

import pytest

from macro_economy.banking_risk import BankingRiskEngine, CollateralTier
from macro_economy.stability_engine import StabilityConfig, StabilityFund, StabilityEconomyV8


def test_tier_haircuts_are_ordered_and_stress_sensitive():
    eng = BankingRiskEngine()
    calm = eng.haircuts(volatility=D('0.01'), leverage=D('1.0'), liquidity_stress=D('0'))
    stress = eng.haircuts(volatility=D('0.08'), leverage=D('3.0'), liquidity_stress=D('0.5'))
    assert calm[CollateralTier.T0] < calm[CollateralTier.T1] < calm[CollateralTier.T2] < calm[CollateralTier.T3] < calm[CollateralTier.T4]
    assert all(stress[t] >= calm[t] for t in CollateralTier)


def test_banking_metrics_cap_rehypothecation_depth_under_stress():
    eng = BankingRiskEngine()
    healthy = eng.metrics(
        hard_nav=D('1000'), liquid_assets=D('650'), secured_liabilities=D('300'),
        internal_claims=D('400'), volatility=D('0.01'), leverage=D('1.2'), liquidity_stress=D('0.05')
    )
    stressed = eng.metrics(
        hard_nav=D('1000'), liquid_assets=D('180'), secured_liabilities=D('900'),
        internal_claims=D('1600'), volatility=D('0.10'), leverage=D('4.0'), liquidity_stress=D('0.8')
    )
    assert healthy.allowed_depth > stressed.allowed_depth
    assert healthy.ccr > stressed.ccr
    assert healthy.lcr > stressed.lcr


def test_stability_fund_starts_at_exactly_half_of_world_wealth_without_creating_nav():
    fund = StabilityFund(opening_world_wealth=D('8700'), initial_fraction=D('0.50'))
    assert fund.allocated_capital == D('4350')
    assert fund.world_wealth_effect == D('0')
    assert fund.target_fraction == D('0.50')


def test_protected_wealth_ratchet_is_monotone():
    fund = StabilityFund(opening_world_wealth=D('1000'), initial_fraction=D('0.50'))
    p0 = fund.protected_wealth
    fund.observe_wealth(D('1010'))
    p1 = fund.protected_wealth
    fund.observe_wealth(D('990'))
    assert fund.protected_wealth == p1
    assert p1 >= p0


def test_risk_regime_increases_protection_near_floor():
    fund = StabilityFund(opening_world_wealth=D('1000'), initial_fraction=D('0.50'))
    green = fund.policy_for(wealth=D('1000'), volatility=D('0.005'), ccr=D('2'), lcr=D('2'))
    red = fund.policy_for(wealth=D('985'), volatility=D('0.10'), ccr=D('0.8'), lcr=D('0.7'))
    assert green.regime == 'GREEN'
    assert red.regime == 'RED'
    assert red.hedge_ratio > green.hedge_ratio
    assert D('0.35') <= red.fund_fraction <= D('0.80')
    assert red.credit_multiplier < green.credit_multiplier


def test_v8_disabled_reproduces_v5_key_metrics():
    cfg = StabilityConfig(blocks=40, seed=77, enable_stability_fund=False)
    report = StabilityEconomyV8(cfg).run()
    assert report.v8_enabled is False
    assert report.stability_hedge_pnl == D('0')
    assert report.stability_hedge_fees == D('0')
    assert report.closing_system_real_wealth == report.v5_closing_system_real_wealth


def test_internal_claims_do_not_increase_economic_net_worth():
    cfg = StabilityConfig(blocks=25, seed=4, enable_stability_fund=True)
    report = StabilityEconomyV8(cfg).run()
    last = report.snapshots[-1]
    assert last['gross_tvl'] >= last['collateral_nav'] >= last['economic_net_worth']
    assert last['economic_net_worth'] == pytest.approx(last['capital_adjusted_wealth'])


def test_reference_run_tracks_floor_and_fund_metrics():
    cfg = StabilityConfig(blocks=60, seed=77, enable_stability_fund=True)
    report = StabilityEconomyV8(cfg).run()
    assert report.stability_fund_initial_allocation == D('4350.000000000000')
    assert report.floor_breaches >= 0
    assert report.max_adjusted_drawdown_pct >= 0
    assert report.snapshots[-1]['protected_wealth'] <= report.snapshots[-1]['economic_net_worth']
    assert report.snapshots[-1]['wealth_floor'] <= report.snapshots[-1]['high_water_mark']
