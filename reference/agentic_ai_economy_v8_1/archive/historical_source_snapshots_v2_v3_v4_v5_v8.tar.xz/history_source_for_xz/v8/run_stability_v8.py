from __future__ import annotations

import argparse
import json
from decimal import Decimal
from pathlib import Path

from macro_economy.stability_engine import StabilityConfig, StabilityEconomyV8

D = Decimal


def main() -> int:
    p = argparse.ArgumentParser(description='Run SYNERGY Global Stability Fund v8')
    p.add_argument('--blocks', type=int, default=500)
    p.add_argument('--seed', type=int, default=77)
    p.add_argument('--reference-vol-multiplier', type=str, default='1')
    p.add_argument('--disable-stability-fund', action='store_true')
    p.add_argument('--output', required=True)
    args = p.parse_args()

    cfg = StabilityConfig(
        blocks=args.blocks,
        seed=args.seed,
        reference_vol_multiplier=D(args.reference_vol_multiplier),
        enable_stability_fund=not args.disable_stability_fund,
    )
    report = StabilityEconomyV8(cfg).run()
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({
        'output': str(out),
        'alpha_vs_hodl': str(report.system_alpha_vs_hodl),
        'max_drawdown_pct': str(report.max_adjusted_drawdown_pct),
        'floor_breaches': report.floor_breaches,
        'stability_fund_nav_end': str(report.stability_fund_nav_end),
    }))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
