# SYNERGY Autonomous Agent Economy v2

This repository now contains two economic layers:

1. the original React/TypeScript prototype and Base/DQN experiments under `experiments/`;
2. a new auditable autonomous agent economy under `agent_economy/`.

The v2 engine is designed around one rule: **an internal transfer is not profit**. Loans, deposits, investment principal, collateral and agent-to-agent payments redistribute existing capital. New system wealth appears only when the ledger records an explicit external inflow; losses to the outside world are explicit external outflows.

## What agents can do

Agents are heterogeneous. Each has a profession, skills, reputation and a genome containing risk appetite, curiosity, policy-research curiosity, entrepreneurship, trust, patience, leverage tolerance and liquidity preference.

The current engine supports:

- externally funded work orders;
- agent-to-agent work orders;
- bidding and escrow;
- an awarded agent subcontracting another agent;
- companies with founders, employees and treasury accounts;
- P2P lending with risk-priced rates;
- collateral lock, release and liquidation;
- real credit defaults and lender losses;
- P2P term deposits and deposit defaults;
- company investments and revenue-share distributions;
- credit insurance with risk-priced premiums and insurer-default handling;
- bankruptcy detection without automatic bailouts or money creation;
- adaptive agent strategies that react to profit, defaults, work outcomes and research;
- Founder Treasury fees;
- explicit attribution of Founder revenue to external economic activity versus internal fee circulation;
- neutral protocol/economic-policy research by policy-curious agents;
- simulation and shadow execution mandates;
- intent-only interoperability envelopes for agent identity/tasks, bounded payment mandates and machine-payment requests;
- accounting conservation checks on every complete scenario.

Real-money execution is deliberately not enabled in v2. No private keys are stored and the engine rejects `live` execution mode. The protocol envelopes are compatibility boundaries and do **not** claim wire-level conformance with any external protocol. A later connector can put real agent/task/payment infrastructure behind explicit spending mandates rather than silently giving agents unrestricted wallets.

## Quick start

The new engine uses only the Python standard library.

```bash
python run_agent_economy.py --agents 24 --steps 365 --seed 42
```

Write a machine-readable report:

```bash
python run_agent_economy.py --agents 24 --steps 365 --seed 42 --json reports/my_run.json
```

Run all v2 tests:

```bash
python -m unittest discover -s tests -p 'test_agent_economy_*.py' -v
```

Run the legacy DQN/Base economic invariant suite:

```bash
MODE=unit SCALE=1 python experiments/dqn_cb_market/experiment_syna.py
```

## Default 365-step reference run

The checked-in `reports/default_24_agents_365_steps.json` is generated from the default deterministic configuration (`seed=42`). It demonstrates external demand, inter-agent hiring, credit, deposits, investment and policy research in one run.

The important metrics are not only Founder cash. Inspect together:

- `opening_capital`
- `external_income`
- `external_expense`
- `closing_system_cash`
- `founder_total_revenue`
- `founder_external_attributed_revenue`
- `founder_internal_fee_revenue`
- `bad_debt_loss`
- `insurance_claims_paid`
- `bankruptcy_cases`
- `strategy_updates`
- `conservation_gap`

A healthy report satisfies:

`closing_system_cash = opening_capital + external_income - external_expense`

Internal credit expansion cannot change that identity.

## Stress testing

`agent_economy.scenario.stress_credit_config(seed=3)` creates a deliberately thin-liquidity economy with frequent lending and deposits. Its checked-in result is `reports/stress_credit_seed3.json`.

```python
from agent_economy.engine import AgentEconomy
from agent_economy.scenario import stress_credit_config

report = AgentEconomy(stress_credit_config(seed=3)).run()
print(report.loans_defaulted, report.bad_debt_loss, report.conservation_gap)
```

The stress profile is expected to produce genuine defaults. Missing repayment money is never manufactured to make the system look solvent.

## Package map

```text
agent_economy/
  ledger.py        immutable cash-flow ledger and conservation accounting
  models.py        agent genome, memory, company and execution mandate models
  reputation.py    transparent reputation and credit scoring
  labor.py         jobs, bidding, escrow, awards and subcontracting
  credit.py        loans, collateral, default, deposits and maturity settlement
  capital.py       companies, investment principal and distributions
  founder.py       Founder Treasury revenue attribution
  policy_lab.py    neutral economic/protocol-policy scenario research
  risk.py          credit insurance, insurer failure and bankruptcy handling
  evolution.py     adaptive strategies driven by observed economic outcomes
  protocols.py     identity/task/payment compatibility envelopes without secrets
  engine.py        multi-market autonomous economy orchestrator
  scenario.py      default/internal-finance/credit-stress presets
```

## Economic interpretation

The Founder can earn platform revenue from real activity, but the simulator does not promise that a deployed system will be profitable. `founder_total_revenue` is a cash-flow metric. `founder_external_attributed_revenue` is the more important metric when asking whether the ecosystem is capturing value from outside itself rather than merely charging its own agents.

The next production step would be to connect external opportunity sources and payment rails behind the existing mandate boundary, then run the same accounting rules in shadow mode before any live capital is allowed.
